#
#  Original code (C) Copyright EdgeCortix, Inc. 2026
#  Modified Portion (C) Copyright Renesas Electronics Corporation 2026
#
import onnx
import onnxoptimizer
import math
from onnx import helper, numpy_helper, TensorProto, shape_inference
from onnx.onnx_ml_pb2 import ModelProto
import numpy as np

from .common import get_shape, get_param, get_lmem_size

def MatMul_DivCore(model: ModelProto) -> ModelProto:
    """
    Convert MatMul(w/o head) to Split/Slice + MatMul + Concat
    """
    print("[Check MatMul(w/o head) to Split/Slice + MatMul + Concat]")
    graph = model.graph
    MAX_Space = 2048
    TMP_Space = 128
    for node in model.graph.node:
        if node.op_type == 'MatMul':
            # Check MatMul_FxF
            if get_param(model, node.input[0]) is None and get_param(model, node.input[1]) is None:
                Div_Head    = 1
                Div_Height  = 1
                Div_Och     = 1
                # param of original node
                node_idx    = list(graph.node).index(node)
                node_name   = node.name
                node_ifm_a  = get_shape(model, node.input[0])
                node_ifm_b  = get_shape(model, node.input[1])
                node_ofm_y  = get_shape(model, node.output[0])
                node_dims   = len(node_ofm_y)
                # CH=Channel, HT=Height, HD=Head
                CHA = node_ifm_a[node_dims-1]
                CHB = node_ifm_b[node_dims-1]
                CHY = node_ofm_y[node_dims-1]
                HTA = node_ifm_a[node_dims-2]
                HTB = node_ifm_b[node_dims-2]
                HTY = node_ofm_y[node_dims-2]
                HDA = 1
                HDB = 1
                HDY = 1
                for d in range(0, node_dims-2, 1):
                    HDA *= node_ifm_a[d]
                    HDB *= node_ifm_b[d]
                    HDY *= node_ofm_y[d]
                # can be stored to local memory ?
                HDA_Space = get_lmem_size(model, CHA, 1, HTA*HDA)
                HDB_Space = get_lmem_size(model, CHB, 1, HTB*HDB)
                HDY_Space = get_lmem_size(model, CHY, 1, HTY*HDY)
                HD_Space  = (HDA_Space + HDB_Space + HDY_Space) 
                if CHB>256:
                    TMP_Space = get_lmem_size(model, HTB, 256, 1)
                else:
                    TMP_Space = get_lmem_size(model, HTB, CHB, 1)
                if HTB%2 == 1 and TMP_Space <= 512:
                    TMP_Space *= 2
                elif TMP_Space > 1024:
                    TMP_Space = 1024
                # Need Div?
                if HD_Space > (MAX_Space - TMP_Space):
                    if HDA != 1 or HDB != 1 or HDY !=1:
                        print("Please execute Head-Division first.(id=",node_idx,",name=",node_name)
                        continue
                    else:
                        tgt_shape_a = node_ifm_a.copy()
                        tgt_shape_b = node_ifm_b.copy()
                        tgt_shape_y = node_ofm_y.copy()
                        MTA_Space = get_lmem_size(model, CHA, 1, HTA)
                        MTB_Space = get_lmem_size(model, CHB, 1, HTB)
                        MTY_Space = get_lmem_size(model, CHY, 1, HTY)
                        MT_Space  = MTA_Space + MTB_Space + MTY_Space
                        if CHB>256:
                            TMP_Space = get_lmem_size(model, HTB, 256, 1)
                        else:
                            TMP_Space = get_lmem_size(model, HTB, CHB, 1)
                        if HTB%2 == 1 and TMP_Space <= 512:
                            TMP_Space *= 2
                        elif TMP_Space > 1024:
                            TMP_Space = 1024

                        # Priority of divider
                        while MT_Space > (MAX_Space - TMP_Space):
                            if MTA_Space >= MTB_Space:
                              Div_Height += 1
                              MTA_Space = get_lmem_size(model, CHA, 1, HTA//Div_Height)
                              MTY_Space = get_lmem_size(model, CHY, 1, HTY//Div_Height)
                            else:
                              Div_Och += 1
                              MTB_Space = get_lmem_size(model, CHB//Div_Och, 1, HTB)
                              MTY_Space = get_lmem_size(model, CHY//Div_Och, 1, HTY)
                            MT_Space  = MTA_Space + MTB_Space + MTY_Space
                        # Align after division
                        ht_flat = math.ceil(HTA/Div_Height)
                        oc_flat = math.ceil(CHB/Div_Och)
                        ht_algn = ((ht_flat+31)//32)*32
                        oc_algn = ((oc_flat+31)//32)*32
                        ht_nslp = math.ceil(HTA/(Div_Height-1)) if Div_Height > 1 else ht_flat
                        oc_nslp = math.ceil(CHB/(Div_Och-1))    if Div_Och > 1    else oc_flat
                        ht      = ht_algn if ht_algn < ht_nslp else ht_flat
                        oc      = oc_algn if oc_algn < oc_nslp else oc_flat

                        # Attribute
                        if Div_Height > 1:
                            slice_start_list_a = []
                            slice_end_list_a   = []
                            for i in range(0, Div_Height, 1):
                                slice_start_a = np.array([ht*i]  , dtype=np.int64)
                                slice_end_a   = np.array([ht*(i+1)], dtype=np.int64) if i!=(Div_Height-1) else np.array([HTA], dtype=np.int64) 
                                slice_start_list_a.append(slice_start_a.copy())
                                slice_end_list_a.append(slice_end_a.copy())
                            slice_axes_a    = np.array([node_dims-2], dtype=np.int64) # div height
                            slice_step_a    = np.array([1], dtype=np.int64) # shared value
    
                        if Div_Och > 1:
                            slice_start_list_b = []
                            slice_end_list_b   = []
                            for i in range(0, Div_Och, 1):
                                slice_start_b = np.array([oc*i]  , dtype=np.int64)
                                slice_end_b   = np.array([oc*(i+1)], dtype=np.int64) if i!=(Div_Och-1) else np.array([CHB], dtype=np.int64) 
                                slice_start_list_b.append(slice_start_b.copy())
                                slice_end_list_b.append(slice_end_b.copy())
                            slice_axes_b    = np.array([node_dims-1], dtype=np.int64) # div och
                            slice_step_b    = np.array([1], dtype=np.int64) # shared value
    
                        # Add to Initializer
                        if Div_Height > 1:
                            for i in range(0, Div_Height, 1):
                                CUT_START = numpy_helper.from_array(slice_start_list_a[i],name=node_name+f"_slice_start_a{i}")
                                CUT_END   = numpy_helper.from_array(slice_end_list_a[i],  name=node_name+f"_slice_end_a{i}")
                                graph.initializer.extend([CUT_START, CUT_END])
    
                            CUT_AXES  = numpy_helper.from_array(slice_axes_a, name=node_name+"_slice_axes_a")
                            CUT_STEP  = numpy_helper.from_array(slice_step_a, name=node_name+"_slice_step_a")
                            graph.initializer.extend([CUT_AXES, CUT_STEP])
    
                        if Div_Och > 1:
                            for i in range(0, Div_Och, 1):
                                CUT_START = numpy_helper.from_array(slice_start_list_b[i],name=node_name+f"_slice_start_b{i}")
                                CUT_END   = numpy_helper.from_array(slice_end_list_b[i],  name=node_name+f"_slice_end_b{i}")
                                graph.initializer.extend([CUT_START, CUT_END])  #並列パラメータを一旦登録
    
                            CUT_AXES  = numpy_helper.from_array(slice_axes_b, name=node_name+"_slice_axes_b")
                            CUT_STEP  = numpy_helper.from_array(slice_step_b, name=node_name+"_slice_step_b")
                            graph.initializer.extend([CUT_AXES, CUT_STEP])
    
                        if Div_Height > 1:
                            div_ina_node_out_info_list = []
                            for i in range(0, Div_Height, 1):
                                tgt_shape_a[node_dims-2] = ht if i!=(Div_Height-1) else HTA-ht*(Div_Height-1)
                                div_ina_node_out      = node_name + f"_div_ina_node_out{i}"
                                div_ina_node_out_info = helper.make_tensor_value_info(
                                    div_ina_node_out,
                                    TensorProto.FLOAT, 
                                    tgt_shape_a,
                                )
                                div_ina_node_out_info_list.append(div_ina_node_out_info)
    
                        if Div_Och > 1:
                            div_inb_node_out_info_list = []
                            for i in range(0, Div_Och, 1):
                                tgt_shape_b[node_dims-1] = oc if i!=(Div_Och-1) else CHB-oc*(Div_Och-1)
                                div_inb_node_out      = node_name + f"_div_inb_node_out{i}"
                                div_inb_node_out_info = helper.make_tensor_value_info(
                                    div_inb_node_out,
                                    TensorProto.FLOAT, 
                                    tgt_shape_b,
                                )
                                div_inb_node_out_info_list.append(div_inb_node_out_info)
    
                        matmul_node_out_info_list = []
                        for j in range(0, Div_Och, 1):
                            for i in range(0, Div_Height, 1):
                                tgt_shape_y[node_dims-2] = ht if i != (Div_Height-1 ) else HTY-ht*(Div_Height-1)
                                tgt_shape_y[node_dims-1] = oc if j != (Div_Och-1    ) else CHY-oc*(Div_Och-1)
                                matmul_node_out       = node_name + f"_matmul_node_out_c{j}_h{i}"
                                matmul_node_out_info  = helper.make_tensor_value_info(
                                    matmul_node_out,
                                    TensorProto.FLOAT,
                                    tgt_shape_y,
                                )
                                matmul_node_out_info_list.append(matmul_node_out_info)
    
                        if Div_Height > 1 and Div_Och > 1:
                            matmul_node_out_info_list2 = []
                            for i in range(0, Div_Och, 1):
                                tgt_shape_y[node_dims-2] = HTY
                                tgt_shape_y[node_dims-1] = oc if i != (Div_Och-1 ) else CHY-oc*(Div_Och-1)
                                matmul_node_out       = node_name + f"_matmul_node_out_c{i}"
                                matmul_node_out_info  = helper.make_tensor_value_info(
                                    matmul_node_out,
                                    TensorProto.FLOAT,
                                    tgt_shape_y,
                                )
                                matmul_node_out_info_list2.append(matmul_node_out_info)
    
                        if Div_Height > 1:
                            for i in range(0, Div_Height, 1):
                                graph.value_info.append(div_ina_node_out_info_list[i])
                        if Div_Och > 1:
                            for i in range(0, Div_Och, 1):
                                graph.value_info.append(div_inb_node_out_info_list[i])
                        for i in range(0, Div_Height*Div_Och, 1):
                            graph.value_info.append(matmul_node_out_info_list[i])
                        if Div_Height > 1 and Div_Och > 1:
                            for i in range(0, Div_Och, 1):
                                graph.value_info.append(matmul_node_out_info_list2[i])
    
                        # Insert/Delete nodes
                        idx_offset = 0
                        # Division of input-A
                        if Div_Height > 1:
                            for i in range(0, Div_Height, 1):
                                slice_ina_node = helper.make_node(
                                    "Slice",
                                    inputs  = [node.input[0], 
                                               node_name+f"_slice_start_a{i}",
                                               node_name+f"_slice_end_a{i}",
                                               node_name+"_slice_axes_a",
                                               node_name+"_slice_step_a",
                                              ],
                                    outputs = [div_ina_node_out_info_list[i].name],
                                    name    = node_name + f"_div_ina{i}"
                                )
                                graph.node.insert(node_idx+idx_offset+i, slice_ina_node)
    
                            idx_offset += Div_Height
                        # Division of input-A
                        if Div_Och > 1:
                            for i in range(0, Div_Och, 1):
                                slice_inb_node = helper.make_node(
                                    "Slice",
                                    inputs  = [node.input[1], 
                                               node_name+f"_slice_start_b{i}",
                                               node_name+f"_slice_end_b{i}",
                                               node_name+"_slice_axes_b",
                                               node_name+"_slice_step_b",
                                              ],
                                    outputs = [div_inb_node_out_info_list[i].name],
                                    name    = node_name + f"_div_inb{i}"
                                )
                                graph.node.insert(node_idx+idx_offset+i, slice_inb_node)
    
                            idx_offset += Div_Och
                        # Height Division Only
                        if Div_Height > 1 and Div_Och == 1:
                            for i in range(0, Div_Height, 1):
                                matmul_node = helper.make_node(
                                    "MatMul",
                                    inputs  = [div_ina_node_out_info_list[i].name,
                                               node.input[1]],
                                    outputs = [matmul_node_out_info_list[i].name],
                                    name    = node_name + f"_div_matmul_h{i}"
                                )
                                graph.node.insert(node_idx+idx_offset+i, matmul_node)
    
                            concat_node = helper.make_node(
                                "Concat",
                                inputs  = [ i.name for i in matmul_node_out_info_list],
                                outputs = [node.output[0]],
                                axis    = node_dims -2,
                                name    = node_name + "_concat_h"
                            )
                            graph.node.insert(node_idx+idx_offset+Div_Height+1, concat_node)
                        # Output Channel Division Only
                        elif Div_Height == 1 and Div_Och > 1:
                            for i in range(0, Div_Och, 1):
                                matmul_node = helper.make_node(
                                    "MatMul",
                                    inputs  = [node.input[0], 
                                               div_inb_node_out_info_list[i].name],
                                    outputs = [matmul_node_out_info_list[i].name],
                                    name    = node_name + f"_div_matmul_c{i}"
                                )
                                graph.node.insert(node_idx+idx_offset+i, matmul_node)
    
                            concat_node = helper.make_node(
                                "Concat",
                                inputs  = [ i.name for i in matmul_node_out_info_list],
                                outputs = [node.output[0]],
                                axis    = node_dims -1,
                                name    = node_name + "_concat_c"
                            )
                            graph.node.insert(node_idx+idx_offset+Div_Och+1, concat_node)
                        # Height and Output Channel Division
                        else:
                            for j in range(0, Div_Och, 1):
                                for i in range(0, Div_Height, 1):
                                    matmul_node = helper.make_node(
                                        "MatMul",
                                        inputs  = [div_ina_node_out_info_list[i].name, 
                                                   div_inb_node_out_info_list[j].name],
                                        outputs = [matmul_node_out_info_list[Div_Height*j+i].name],
                                        name    = node_name + f"_div_matmul_c{j}_h{i}"
                                    )
                                    graph.node.insert(node_idx+idx_offset+i, matmul_node)
    
                                # concat per height
                                concat_node = helper.make_node(
                                    "Concat",
                                    inputs  = [ i.name for i in matmul_node_out_info_list[(Div_Height*j):(Div_Height*(j+1))]],
                                    outputs = [matmul_node_out_info_list2[j].name],
                                    axis    = node_dims -2,
                                    name    = node_name + f"_concat_c{j}_h"
                                )
                                graph.node.insert(node_idx+idx_offset+Div_Height, concat_node)
                                idx_offset += (Div_Height+1)
    
                            # concat per och
                            concat_node = helper.make_node(
                                "Concat",
                                inputs  = [ i.name for i in matmul_node_out_info_list2],
                                outputs = [node.output[0]],
                                axis    = node_dims -1,
                                name    = node_name + "_concat_c"
                            )
                            graph.node.insert(node_idx+idx_offset, concat_node)
    
                        # Shared func.
                        graph.node.remove(node)
                        inferred = shape_inference.infer_shapes(model)
                        print(f"    > convert: {node.name}")
    
    onnx.checker.check_model(model)
    model = onnxoptimizer.optimize(model,["eliminate_unused_initializer"])
    return model
