#
#  Original code (C) Copyright EdgeCortix, Inc. 2026
#  Modified Portion (C) Copyright Renesas Electronics Corporation 2026
#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

import argparse
import onnx
import onnxruntime as ort
import numpy as np
from onnx import helper, numpy_helper, TensorProto, shape_inference
from onnxsim import simplify

from .ConvTranspose2ConvDepthToSpace import ConvTranspose2Conv
from .Conv3D2Conv2D import Conv3D2Conv2D
from .MatMul_DivHead import MatMul_DivHead
from .MatMul_DivCore import MatMul_DivCore

def check_ort(model_org, model_val) -> bool:
    """
    Compare inference result by onnxruntime
    """
    # Load original model and create inference session
    sess = ort.InferenceSession(model_org)
    # Set input data
    input_dict = dict()
    input_s_list = list()
    # Generate random input data for original model
    for idx, node in enumerate(sess.get_inputs()):
        input_s_list.append(node.shape)
        print("   Din shape {0} : {1}".format(idx,node.shape))
        _data = np.random.random((node.shape))
        input_dict[node.name] = _data.astype(np.float32)
    # Run inference on original model
    pred_onx = sess.run(None, input_dict)

    # Load variant model and create inference session
    sess2 = ort.InferenceSession(model_val)
    # Use same input data for variant model
    for idx, node in enumerate(sess2.get_inputs()):
        input_s_list.append(node.shape)
    # Run inference on variant model
    pred_onx2 = sess2.run(None, input_dict)

    # Compare outputs between original and variant models
    output_len = len(pred_onx)
    for idx in range(output_len):
        print(f"   Output shape {idx}: {pred_onx2[idx].shape}")
        # Calculate difference between outputs
        diff = pred_onx[idx] - pred_onx2[idx]
        # Check maximum difference threshold
        print("     diff max  : ",diff.max())
        if(diff.max()>0.1):return False
        # Check minimum difference threshold
        print("     diff min  : ",diff.min())
        if(diff.min()<-0.1):return False
        # Check mean difference threshold
        print("     diff meam : ",diff.mean())
        if(abs(diff.mean())>0.05): return False

    return True

def variant_converter(onnx_model: any, out_model_path: str):
    """
    Execute convert functions
    """
    # 0. Run onnxsim 
    print("[Run onnxsim]")
    model_simp, check = simplify(onnx_model)
    assert check, "Simplified ONNX model could not be validated"
    # 1. ConvTranspose --> Conv + DepthToSpace
    variant_model_1 = ConvTranspose2Conv(model_simp)
    # 2. Conv3D --> Conv2D + other operators
    variant_model = Conv3D2Conv2D(variant_model_1)
    #variant_model_2 = Conv3D2Conv2D(variant_model_1)
    ## 3. MatMul(N-head) --> Slice/Split + MatMul + Concat
    #variant_model_3 = MatMul_DivHead(variant_model_2)
    ## 4. MatMul(head=1) --> Slice/Split + MatMul + Concat
    #variant_model   = MatMul_DivCore(variant_model_3)

    return variant_model

def run_onnx_converter(onnx_path : str, out_path: str):
    """
    Run variant model converter
    """
    print("[Start to generate variant model]")
    onnx_model = onnx.load(onnx_path)
    v_model = variant_converter(onnx_model, out_path)
    onnx.save(v_model,out_path)
    print("[SAVE] :", out_path)
    print("[Inference check]")
    res = check_ort(onnx_path,out_path)
    if(res):
        print("[Finish] Variant model generation was success")
    else:
        print("[WARNING] Converted ONNX shows a large error compared with input ONNX.")
        print("          Please check converted ONNX")
    return 0
