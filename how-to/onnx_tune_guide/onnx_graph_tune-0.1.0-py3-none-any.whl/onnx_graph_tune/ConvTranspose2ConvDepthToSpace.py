#
#  Original code (C) Copyright EdgeCortix, Inc. 2026
#  Modified Portion (C) Copyright Renesas Electronics Corporation 2026
#
import onnx
import onnxoptimizer
from onnx import helper, numpy_helper, TensorProto
from onnx.onnx_ml_pb2 import ModelProto
import numpy as np

from .common import get_shape, get_param

def ConvTranspose2Conv(model: ModelProto) -> ModelProto:
    """
    Convert ConvTranspose nodes in an ONNX model into an equivalent
    Conv + DepthToSpace operation sequence.
    """
    print("[Check: ConvTranspose to Conv2D + DepthToSpace]")
    graph = model.graph
    for node in model.graph.node:
        if node.op_type == 'ConvTranspose':
            node_idx    = list(graph.node).index(node)
            node_name   = node.name
            node_ifm    = get_shape(model,node.input[0])
            node_ofm    = get_shape(model,node.output[0])
            wt          = get_param(model,node.input[1])
            wt_shape    = wt.shape
            bias_en     = 1 if len(node.input)>2 else 0
            if bias_en == 1:
                bias        = get_param(model,node.input[2])
                bias_shape  = bias.shape
            if len(wt_shape) != 4:
                print("SKIP: NOT convtranspose(2d)")
                print(f"    > NOT convert: {node.name}")
                continue

            # Check ConvTranspose attributre
            err   = 0
            dil   = [1,1]     # default value
            grp   = 1         # default value
            st    = [1,1]     # default value
            pads  = [0,0,0,0] # default value
            opad  = [0,0]     # default value
            for attr in node.attribute:
                if attr.name == "dilations":
                    dil  = attr.ints
                    if dil != [1,1]:
                        print("SKIP: dilations is NOT [1,1]")
                        err=1
                        break
                elif attr.name == "group":
                    grp  = attr.i
                    if grp != 1:
                        print("SKIP: group is NOT 1")
                        err=1
                        break
                elif attr.name == "auto_pad":
                    autopad = attr.s.decode('utf-8')
                    if autopad != "NOTSET":
                        print("SKIP: auto_pad is NOT NOTSET")
                        err=1
                        break
                elif attr.name == 'strides':
                    st   = attr.ints
                    if st[0] != st[1]:
                        print("SKIP: asynmetric stride")
                        err=1
                        break
                    elif st[0] == 1:
                        print("SKIP: stride is [1,1]")
                        err=1
                        break
                elif attr.name == 'output_padding':
                    opad = attr.ints
                    if opad[0] != opad[1]:
                        print("SKIP: asynmetric output_padding")
                        err=1
                        break
                elif attr.name == 'pads':
                    pads = attr.ints
                    for pos in range(1, 4, 1):
                        if pads[0] != pads[pos]:
                            print("SKIP: asynmetric padding")
                            err=1
                            break
            if wt_shape[2] != wt_shape[3]:
                print("SKIP: asynmetric kernel")
                err=1
            else:
                ker = wt_shape[3]
                if ker == st[0]:
                    if pads[0] != 0 or opad[0] != 0:
                        if err==0:  print("SKIP: unsupported padding at (ker==st)")
                        err=1
                else:
                    if pads[0] != ker // 2 or opad[0] != st[0] - 1:
                        if err==0:  print("SKIP: unsupported padding at (ker!=st)")
                        err=1

            # Reduce Exe Cycle (Rough Estimation)
            if err != 1:
                speedup_rate  = (st[0]**4)//2 if node_ofm[1]*(st[0]**2) <= 64 else st[0]**3
                exe_time      = (ker**2)*(node_ifm[1]*node_ofm[2]*node_ofm[3])//64
                mac_speedup   = (exe_time * (speedup_rate-1)) // speedup_rate
                add_mem_time  = ((node_ofm[1]*node_ofm[2]*node_ofm[3])*50)//32
                if mac_speedup < add_mem_time:
                    print("SKIP: expected to increase execution time.")
                    err=1

            if err == 1:
                print(f"    > NOT convert: {node.name}")
            else:
                # Convert to variant graph: ConvTranspose --> Conv > DepthToSpace
                convtr_och  = node_ofm[1]
                convtr_oh   = node_ofm[2]
                convtr_ow   = node_ofm[3]
                convtr_ich  = node_ifm[1]
                convtr_ih   = node_ifm[2]
                convtr_iw   = node_ifm[3]
                convtr_ker  = ker
                convtr_st   = st[0]
                convtr_pad  = pads[0]
                convtr_opad = opad[0]

                conv2d_och  = convtr_och * convtr_st * convtr_st
                conv2d_oh   = convtr_ih # conv2dではih=oh
                conv2d_ow   = convtr_iw # conv2dではiw=ow
                conv2d_ich  = convtr_ich * convtr_st * convtr_st
                conv2d_ih   = convtr_ih
                conv2d_iw   = convtr_iw
                conv2d_ker  = ((convtr_ker + convtr_st -1) -1) // convtr_st +1 if convtr_ker != convtr_st else 1
                conv2d_st   = 1
                conv2d_pad  = conv2d_ker // 2 if convtr_ker != convtr_st else 0
                pad_u_l     = conv2d_pad if conv2d_ker % 2 == 1 else conv2d_pad -1
                pad_d_r     = conv2d_pad
                asym_pad    = pad_d_r - pad_u_l

                if convtr_ker == convtr_st:
                    conv2d_wt = np.zeros((convtr_och, convtr_ich, convtr_ker, convtr_ker), dtype='float32')  #float
                    conv2d_wt = wt.transpose(1,0,2,3)[:,:,::-1,::-1].copy()
                else:
                    conv2d_wt = np.zeros((convtr_och, convtr_ich, (conv2d_ker * convtr_st), (conv2d_ker * convtr_st)), dtype='float32')  #float
                    conv2d_wt[:,:,(convtr_st-1-asym_pad):(convtr_st-1-asym_pad)+convtr_ker,(convtr_st-1-asym_pad):(convtr_st-1-asym_pad)+convtr_ker] = wt.transpose(1,0,2,3)[:,:,::-1,::-1].copy()
                conv2d_wt = conv2d_wt.reshape([convtr_och, convtr_ich, conv2d_ker, convtr_st, conv2d_ker, convtr_st])
                conv2d_wt = conv2d_wt[:,:,:,::-1,:,::-1]
                conv2d_wt = conv2d_wt.transpose(3,5,0,1,2,4).reshape([conv2d_och, convtr_ich, conv2d_ker, conv2d_ker])
                if bias_en == 1:
                    conv2d_bias = np.tile(bias, convtr_st * convtr_st)

                W = numpy_helper.from_array(conv2d_wt, name=node_name+"_W")
                if bias_en == 1:
                    B = numpy_helper.from_array(conv2d_bias, name=node_name+"_B")
                    graph.initializer.extend([W, B])
                else:
                    graph.initializer.extend([W])
                new_path = node_name + "conv_to_d2s"
                new_path_info = helper.make_tensor_value_info(
                new_path, TensorProto.FLOAT, [1, conv2d_och, conv2d_oh, conv2d_ow]
                )
                graph.value_info.append(new_path_info)

                if bias_en == 1:
                    conv_node = helper.make_node(
                        "Conv",
                        inputs       = [node.input[0], node_name+"_W", node_name+"_B"],
                        outputs      = [new_path],
                        kernel_shape = [conv2d_ker, conv2d_ker],
                        strides      = [conv2d_st, conv2d_st],
                        pads         = [pad_u_l, pad_u_l, pad_d_r, pad_d_r], #H,L,D,R
                        name         = node_name + "_Conv"
                )
                else:
                    conv_node = helper.make_node(
                        "Conv",
                        inputs       = [node.input[0], node_name+"_W"],
                        outputs      = [new_path],
                        kernel_shape = [conv2d_ker, conv2d_ker],
                        strides      = [conv2d_st, conv2d_st],
                        pads         = [pad_u_l, pad_u_l, pad_d_r, pad_d_r], #H,L,D,R
                        name         = node_name + "_Conv"
                )

                if(convtr_och==1):
                    _mode = "CRD"
                else:
                    _mode = "DCR"
                d2s_node = helper.make_node(
                    "DepthToSpace",
                    inputs    = [new_path],
                    outputs   = [node.output[0]],
                    blocksize = convtr_st,
                    mode      = _mode,
                    name      = node_name + "_DepthToSpace"
                )

                graph.node.insert(node_idx,   conv_node)
                graph.node.insert(node_idx+1, d2s_node)
                graph.node.remove(node)
                print(f"    > convert: {node.name}")


    onnx.checker.check_model(model)
    model = onnxoptimizer.optimize(model,["eliminate_unused_initializer"])
    return model
