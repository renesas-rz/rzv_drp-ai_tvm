#
#  Original code (C) Copyright EdgeCortix, Inc. 2026
#  Modified Portion (C) Copyright Renesas Electronics Corporation 2026
#

from onnx import numpy_helper, shape_inference

def get_shape(model: any, name: str):
    """
    Retrieve the tensor shape of a specified input, output, or intermediate value
    in the given ONNX model.
    """
    inferred   = shape_inference.infer_shapes(model)

    for obj in model.graph.input:
      if name == obj.name:
        return [d.dim_value for d in obj.type.tensor_type.shape.dim]

    for obj in model.graph.output:
      if name == obj.name:
        return [d.dim_value for d in obj.type.tensor_type.shape.dim]

    for val_info in inferred.graph.value_info:
      if val_info.name == name:
        return [d.dim_value for d in val_info.type.tensor_type.shape.dim]

    return None

def get_param(model: any, name: str):
    """
    Retrieve a parameter tensor (initializer) from the ONNX model by name.
    """
    param = {}
    for initializer in model.graph.initializer:
      if initializer.name == name:
        param[name] = numpy_helper.to_array(initializer)
        return  param.get(name)
    return None

def chk_ref_nodes(model: any, node_out: str, start_id: int):
    """
    Retrieve the number of nodes referenced as input and their max id.
    """
    hit_num = 0
    hit_id  = 0
    for idx in range(start_id+1, len(model.graph.node), 1):
        if model.graph.node[idx].op_type == 'Constant':
            continue
        if node_out == model.graph.node[idx].input[0]:
            hit_num += 1
            hit_id   = idx
    return  hit_num, hit_id

def get_lmem_size(model: any, ch: int, width: int, height: int):
    """
    Retrieve the estimated local memory usege.
    """
    word      = (ch+31)//32
    line      = word * width
    pair_size = line+1 if (line%2)==1 else line
    space     = pair_size * ((height+31)//32)
    return  space
