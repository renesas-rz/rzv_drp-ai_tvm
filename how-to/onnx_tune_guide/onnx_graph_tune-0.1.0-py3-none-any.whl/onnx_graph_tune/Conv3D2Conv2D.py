#
#  Original code (C) Copyright EdgeCortix, Inc. 2026
#  Modified Portion (C) Copyright Renesas Electronics Corporation 2026
#
import onnx
import onnxoptimizer
from onnx import helper, numpy_helper, TensorProto
from onnx.onnx_ml_pb2 import ModelProto
import numpy as np

from .common import get_shape, get_param, chk_ref_nodes

def Conv3D2Conv2D(model: ModelProto) -> ModelProto:
    """
    Convert Conv3D to Conv2D.
    """
    print("[Check: Conv3D to Conv2D]")
    graph = model.graph
    for node in model.graph.node:
        if node.op_type == 'Conv':
            wt          = get_param(model,node.input[1])
            wt_shape    = wt.shape
            ker_depth   = len(wt_shape) - 4 #2d=4

            if ker_depth == 1:
                node_idx    = list(graph.node).index(node)
                node_name   = node.name
                node_ifm    = get_shape(model,node.input[0])
                node_ofm    = get_shape(model,node.output[0])
                bias_en     = 1 if len(node.input)>2 else 0
                if bias_en == 1:
                    bias        = get_param(model,node.input[2])
                    bias_shape  = bias.shape
                activate_on = 0
                clip_en     = 0
                min_val     = None
                max_val     = None
                alpha_en    = 0
                alpha_val   = None
                beta_en     = 0
                beta_val    = None
                gamma_en    = 0
                gamma_val   = None

                # Check if activation function follows conv (~opset17, w/o prelu)
                hit_info = chk_ref_nodes(model, node.output[0], node_idx)
                if hit_info[0] == 1:
                    pair_node = model.graph.node[hit_info[1]]
                    # Not support 2 input type.(PRelu)
                    if pair_node.op_type in ["Relu", "Sigmoid", "Tanh", "Softplus", "HardSwish"]:
                        activate_on = 1
                    elif pair_node.op_type in ["LeakyRelu", "ThresholdRelu", "Celu", "Elu"]:
                        activate_on = 1
                        alpha_en    = 1
                        for attr in pair_node.attribute:
                            if attr.name == "alpha":
                                alpha_val = attr.f
                    elif pair_node.op_type in ["HardSigmoid"]:
                        activate_on = 1
                        alpha_en    = 1
                        beta_en     = 1
                        for attr in pair_node.attribute:
                            if attr.name == "alpha":
                                alpha_val = attr.f
                            elif attr.name == "beta":
                                beta_val  = attr.f
                    elif pair_node.op_type in ["Selu"]:
                        activate_on = 1
                        alpha_en    = 1
                        gamma_en    = 1
                        for attr in pair_node.attribute:
                            if attr.name == "alpha":
                                alpha_val = attr.f
                            elif attr.name == "gamma":
                                gamma_val = attr.f
                    elif pair_node.op_type in ["Clip"]:
                        activate_on = 1
                        clip_en     = 1
                        old_clip_op = 1 if len(pair_node.input)==1 else 0
                        if old_clip_op == 1:
                            for attr in pair_node.attribute:
                                if attr.name == "min":
                                    min_val = attr.f
                                elif attr.name == "max":
                                    max_val = attr.f

                # Check Attribute
                err   = 0
                dil   = [1,1,1]       # default value
                grp   = 1             # default value
                st    = [1,1,1]       # default value
                pads  = [0,0,0,0,0,0] # default value
 
                for attr in node.attribute:
                    if attr.name == "dilations":
                        dil  = attr.ints
                        if dil != [1,1,1]:
                            print("SKIP: dilations is NOT [1,1,1]")
                            err=1
                            break
                    elif attr.name == "group":
                        grp  = attr.i
                        if grp != 1:
                            print("SKIP: group is NOT 1")
                            err=1
                            break
                    elif attr.name == "auto_pad":
                        autopad = attr.s.decode('utf-8')
                        if autopad != "NOTSET":
                            print("SKIP: auto_pad is NOT NOTSET")
                            err=1
                            break
                    elif attr.name == 'strides':
                        st   = attr.ints
                        if st[0] > 2:
                            print("SKIP: stride(depth) > 2")
                            err=1
                            break
                        if st[1] != st[2]:
                            print("SKIP: asynmetric stride(height,width)")
                            err=1
                            break
                    elif attr.name == 'pads':
                        pads = attr.ints
        
                ker = [wt_shape[2], wt_shape[3], wt_shape[4]]
                if st[0]==2:
                    if ker[0]==1:
                        if pads[0]!=0 or pads[3]!=0:
                            print("SKIP: stride_depth=2 and kernel_depth=1, but pad!=0")
                            err = 1
                    elif ker[0]==3:
                        if pads[0]!=1 or pads[3]!=1:
                            print("SKIP: stride_depth=2 and kernel_depth=3, but pad!=1")
                            err = 1
                    else:
                        print("SKIP: stride_depth=2, but kernel_size!=[1,3]")
                        err = 1

                if err == 1:
                    print(f"    > NOT convert: {node.name}")
                else:
                    # Gen new Conv2D graph
                    conv3d_ker = ker
                    conv3d_st  = st
                    conv3d_och = wt_shape[0]
                    conv3d_ich = wt_shape[1]
                    conv3d_kD  = wt_shape[2]
                    conv3d_kH  = wt_shape[3]
                    conv3d_kW  = wt_shape[4]
                    conv3d_dpt = node_ifm[2]
                    conv2d_ker = [conv3d_ker[1], conv3d_ker[2]]
                    conv2d_st  = [conv3d_st[1], conv3d_st[2]]
                    conv2d_pad = [pads[1], pads[2], pads[4], pads[5]]
                    conv2d_och = conv3d_och * conv3d_dpt // conv3d_st[0]
                    conv2d_ich = (conv3d_dpt + pads[0] + pads[3]) * conv3d_ich
                    conv2d_kH  = conv3d_kH
                    conv2d_kW  = conv3d_kW
                    active_ch  = conv3d_ich * conv3d_kD

                    add_pads  = np.array([0, 0, pads[0], 0, 0, 0, 0, pads[3], 0, 0], dtype=np.int64)
                    ifm_rsp   = np.array([1, conv2d_ich, node_ifm[3], node_ifm[4]], dtype=np.int64)
                    ofm_rsp   = np.array([1, node_ofm[1], node_ofm[2], node_ofm[3], node_ofm[4]], dtype=np.int64)

                    conv2d_wt = np.zeros((conv2d_och, conv2d_ich, conv2d_kH, conv2d_kW), dtype='float32')  #float
                    wt = wt.transpose(0,2,1,3,4)
                    wt = wt.reshape(wt_shape[0], wt_shape[1]*wt_shape[2], wt_shape[3], wt_shape[4]) #[128][192][3][3]
                    for och_id in range(0, conv3d_och, 1):  #for(0~128)
                        for dpt_id in range(0, conv3d_dpt, conv3d_st[0]): #for(0~16)/2
                            conv2d_wt[och_id*conv3d_dpt//conv3d_st[0] + dpt_id//conv3d_st[0], (dpt_id*conv3d_ich):(dpt_id*conv3d_ich)+active_ch, :, :] = wt[och_id, :, :, :].copy()

                    if bias_en == 1:
                        conv2d_bias = np.tile(bias, conv3d_dpt//conv3d_st[0]).reshape(conv3d_dpt//conv3d_st[0], conv3d_och).transpose(1,0).reshape(conv3d_dpt//conv3d_st[0]*conv3d_och)
        
                    P     = numpy_helper.from_array(add_pads,   name=node_name+"_AddPad")
                    IRSP  = numpy_helper.from_array(ifm_rsp,    name=node_name+"_ifm_shape")
                    ORSP  = numpy_helper.from_array(ofm_rsp,    name=node_name+"_ofm_shape")
                    W     = numpy_helper.from_array(conv2d_wt,  name=node_name+"_W")
                    if bias_en == 1:
                        B = numpy_helper.from_array(conv2d_bias, name=node_name+"_B")
                        graph.initializer.extend([W, B, P, IRSP, ORSP])
                    else:
                        graph.initializer.extend([W, P, IRSP, ORSP])
        
                    pad_node_out      = node_name + "pad_node_out"
                    pad_node_out_info = helper.make_tensor_value_info(
                        pad_node_out, 
                        TensorProto.FLOAT, 
                        [node_ifm[0], node_ifm[1], (node_ifm[2]+pads[0]+pads[3]), node_ifm[3], node_ifm[4]]
                    )

                    ifm_tr_node_out      = node_name + "ifm_tr_node_out"
                    ifm_tr_node_out_info = helper.make_tensor_value_info(
                        ifm_tr_node_out, 
                        TensorProto.FLOAT, 
                        [node_ifm[0], (node_ifm[2]+pads[0]+pads[3]), node_ifm[1], node_ifm[3], node_ifm[4]]
                    )

                    ifm_rsp_node_out      = node_name + "ifm_rsp_node_out"
                    ifm_rsp_node_out_info = helper.make_tensor_value_info(
                        ifm_rsp_node_out, 
                        TensorProto.FLOAT, 
                        [node_ifm[0], (node_ifm[2]+pads[0]+pads[3])*node_ifm[1], node_ifm[3], node_ifm[4]]
                    )

                    conv2d_node_out       = node_name + "conv2d_node_out"
                    conv2d_node_out_info  = helper.make_tensor_value_info(
                        conv2d_node_out,
                        TensorProto.FLOAT, 
                        [node_ofm[0], (node_ofm[1]*node_ofm[2]), node_ofm[3], node_ofm[4]]
                    )

                    if activate_on == 1:
                        act_node_out        = pair_node.name + "2d_out"
                        act_node_out_info   = helper.make_tensor_value_info(
                            act_node_out,
                            TensorProto.FLOAT,
                            [node_ofm[0], (node_ofm[1]*node_ofm[2]), node_ofm[3], node_ofm[4]]
                        )
                        graph.value_info.extend([pad_node_out_info, ifm_tr_node_out_info, ifm_rsp_node_out_info, conv2d_node_out_info, act_node_out_info])
                    else:
                        graph.value_info.extend([pad_node_out_info, ifm_tr_node_out_info, ifm_rsp_node_out_info, conv2d_node_out_info])

                    pad_node = helper.make_node(
                        "Pad",
                        inputs  = [node.input[0], node_name+"_AddPad"],
                        outputs = [pad_node_out],
                        name    = node_name + "_ifm_pad"
                    )
                    ifm_tr_node = helper.make_node(
                        "Transpose",
                        inputs  = [pad_node_out],
                        outputs = [ifm_tr_node_out],
                        perm    = (0, 2, 1, 3, 4), #swap ich and depth
                        name    = node_name + "_ifm_transpose"
                    )
                    ifm_rsp_node = helper.make_node(
                        "Reshape",
                        inputs  = [ifm_tr_node_out, node_name+"_ifm_shape"],
                        outputs = [ifm_rsp_node_out],
                        name    = node_name + "_ifm_reshape"
                    )
                    if bias_en == 1:
                        conv_node = helper.make_node(
                            "Conv",
                            inputs       = [ifm_rsp_node_out, node_name+"_W", node_name+"_B"],
                            outputs      = [conv2d_node_out],
                            kernel_shape = conv2d_ker,
                            strides      = conv2d_st,
                            pads         = conv2d_pad,
                            name         = node_name + "_Conv"
                        )
                    else:
                        conv_node = helper.make_node(
                            "Conv",
                            inputs       = [ifm_rsp_node_out, node_name+"_W"],
                            outputs      = [conv2d_node_out],
                            kernel_shape = conv2d_ker,
                            strides      = conv2d_st,
                            pads         = conv2d_pad,
                            name         = node_name + "_Conv"
                        )

                    # Convert shape from [OxD][H][W] to [O][D][H][W]
                    if activate_on == 1 and clip_en == 1:
                        if old_clip_op == 1:
                            act_node  = helper.make_node(
                                pair_node.op_type,
                                inputs  = [conv2d_node_out],
                                outputs = [act_node_out],
                                min     = min_val,
                                max     = max_val,
                                name    = pair_node.name + "_2d"
                            )
                        elif len(pair_node.input)==2:
                            act_node  = helper.make_node(
                                pair_node.op_type,
                                inputs  = [conv2d_node_out, pair_node.input[1]],
                                outputs = [act_node_out],
                                name    = pair_node.name + "_2d"
                            )
                        else:
                            act_node  = helper.make_node(
                                pair_node.op_type,
                                inputs  = [conv2d_node_out, pair_node.input[1], pair_node.input[2]],
                                outputs = [act_node_out],
                                name    = pair_node.name + "_2d"
                            )
                        ofm_rsp_node = helper.make_node(
                            "Reshape",
                            inputs  = [act_node_out, node_name+"_ofm_shape"],
                            outputs = [pair_node.output[0]],
                            name    = node_name + "_ofm_reshape"
                        )
                    elif activate_on == 1 and alpha_en == 0 and beta_en == 0 and gamma_en == 0:
                        act_node  = helper.make_node(
                            pair_node.op_type,
                            inputs  = [conv2d_node_out],
                            outputs = [act_node_out],
                            name    = pair_node.name + "_2d"
                        )
                        ofm_rsp_node = helper.make_node(
                            "Reshape",
                            inputs  = [act_node_out, node_name+"_ofm_shape"],
                            outputs = [pair_node.output[0]],
                            name    = node_name + "_ofm_reshape"
                        )
                    elif activate_on == 1 and alpha_en == 1 and beta_en == 0 and gamma_en == 0:
                        act_node  = helper.make_node(
                            pair_node.op_type,
                            inputs  = [conv2d_node_out],
                            outputs = [act_node_out],
                            alpha   = alpha_val,
                            name    = pair_node.name + "_2d"
                        )
                        ofm_rsp_node = helper.make_node(
                            "Reshape",
                            inputs  = [act_node_out, node_name+"_ofm_shape"],
                            outputs = [pair_node.output[0]],
                            name    = node_name + "_ofm_reshape"
                        )
                    elif activate_on == 1 and alpha_en == 1 and beta_en == 1 and gamma_en == 0:
                        act_node  = helper.make_node(
                            pair_node.op_type,
                            inputs  = [conv2d_node_out],
                            outputs = [act_node_out],
                            alpha   = alpha_val,
                            beta    = beta_val,
                            name    = pair_node.name + "_2d"
                        )
                        ofm_rsp_node = helper.make_node(
                            "Reshape",
                            inputs  = [act_node_out, node_name+"_ofm_shape"],
                            outputs = [pair_node.output[0]],
                            name    = node_name + "_ofm_reshape"
                        )
                    elif activate_on == 1 and alpha_en == 1 and beta_en == 0 and gamma_en == 1:
                        act_node  = helper.make_node(
                            pair_node.op_type,
                            inputs  = [conv2d_node_out],
                            outputs = [act_node_out],
                            alpha   = alpha_val,
                            gamma   = gamma_val,
                            name    = pair_node.name + "_2d"
                        )
                        ofm_rsp_node = helper.make_node(
                            "Reshape",
                            inputs  = [act_node_out, node_name+"_ofm_shape"],
                            outputs = [pair_node.output[0]],
                            name    = node_name + "_ofm_reshape"
                        )
                    else:
                        ofm_rsp_node = helper.make_node(
                            "Reshape",
                            inputs  = [conv2d_node_out, node_name+"_ofm_shape"],
                            outputs = [node.output[0]],
                            name    = node_name + "_ofm_reshape"
                        )
                    if activate_on == 1:
                        graph.node.insert(node_idx,   pad_node)
                        graph.node.insert(node_idx+1, ifm_tr_node)
                        graph.node.insert(node_idx+2, ifm_rsp_node)
                        graph.node.insert(node_idx+3, conv_node)
                        graph.node.insert(node_idx+4, act_node)
                        graph.node.insert(node_idx+5, ofm_rsp_node)
                        graph.node.remove(node)
                        graph.node.remove(pair_node)
                    else:
                        graph.node.insert(node_idx,   pad_node)
                        graph.node.insert(node_idx+1, ifm_tr_node)
                        graph.node.insert(node_idx+2, ifm_rsp_node)
                        graph.node.insert(node_idx+3, conv_node)
                        graph.node.insert(node_idx+4, ofm_rsp_node)
                        graph.node.remove(node)
                    print(f"    > convert: {node.name}")

    onnx.checker.check_model(model)
    model = onnxoptimizer.optimize(model,["eliminate_unused_initializer"])
    return model
