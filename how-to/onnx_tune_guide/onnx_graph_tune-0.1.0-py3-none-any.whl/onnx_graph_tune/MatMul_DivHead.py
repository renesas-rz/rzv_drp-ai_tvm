#
#  Original code (C) Copyright EdgeCortix, Inc. 2026
#  Modified Portion (C) Copyright Renesas Electronics Corporation 2026
#
import onnx
import onnxoptimizer
import math
from onnx import helper, numpy_helper, TensorProto, shape_inference
from onnx.onnx_ml_pb2 import ModelProto
import numpy as np

from .common import get_shape, get_param, get_lmem_size

def MatMul_DivHead(model: ModelProto) -> ModelProto:
    """
    Convert MatMul(multi-head) to Split/Slice + MatMul + Concat
    """
    print("[Check MatMul(multi-head) to Split/Slice + MatMul + Concat]")
    graph = model.graph
    MAX_Space = 2048
    TMP_Space = 128
    for node in model.graph.node:
        if node.op_type == 'MatMul':
            # Check MatMul_FxF
            if get_param(model, node.input[0]) is None and get_param(model, node.input[1]) is None:
                Div_Head    = 1
                Div_Height  = 1
                Div_Och     = 1
                # param of original node
                node_idx    = list(graph.node).index(node)
                node_name   = node.name
                node_ifm_a  = get_shape(model, node.input[0])
                node_ifm_b  = get_shape(model, node.input[1])
                node_ofm_y  = get_shape(model, node.output[0])
                node_dims   = len(node_ofm_y)
                # CH=Channel, HT=Height, HD=Head
                CHA = node_ifm_a[node_dims-1]
                CHB = node_ifm_b[node_dims-1]
                CHY = node_ofm_y[node_dims-1]
                HTA = node_ifm_a[node_dims-2]
                HTB = node_ifm_b[node_dims-2]
                HTY = node_ofm_y[node_dims-2]
                HDA = 1
                HDB = 1
                HDY = 1
                for d in range(0, node_dims-2, 1):
                    HDA *= node_ifm_a[d]
                    HDB *= node_ifm_b[d]
                    HDY *= node_ofm_y[d]
                # can be stored to local memory ?
                HDA_Space = get_lmem_size(model, CHA, 1, HTA*HDA)
                HDB_Space = get_lmem_size(model, CHB, 1, HTB*HDB)
                HDY_Space = get_lmem_size(model, CHY, 1, HTY*HDY)
                HD_Space  = (HDA_Space + HDB_Space + HDY_Space) 
                if CHB>256:
                    TMP_Space = get_lmem_size(model, HTB, 256, 1)
                else:
                    TMP_Space = get_lmem_size(model, HTB, CHB, 1)
                if HTB%2 == 1 and TMP_Space <= 512:
                    TMP_Space *= 2
                elif TMP_Space > 1024:
                    TMP_Space = 1024
                # Div Head
                if HD_Space > (MAX_Space - TMP_Space):
                    tgt_shape_a = node_ifm_a.copy()
                    tgt_shape_b = node_ifm_b.copy()
                    tgt_shape_y = node_ofm_y.copy()
                    for d in range(0, node_dims-2, 1):
                        num_head  = node_ofm_y[d]
                        if num_head == 1:
                            if d==(node_dims-3): print(f"    > info: head-divide has reached its litmt. {node.name}")
                            continue
                        # Div by slice or split
                        use_slice = 1 if num_head>8 else 0
                        tgt_shape_a[d] = 1
                        tgt_shape_b[d] = 1
                        tgt_shape_y[d] = 1
                        concat_axis    = d
                        if use_slice == 1:
                            slice_start_list = []
                            slice_end_list   = []
                            for i in range(0, num_head, 1):
                                slice_start = np.array([i]  , dtype=np.int64)
                                slice_end   = np.array([i+1], dtype=np.int64)
                                slice_start_list.append(slice_start.copy())
                                slice_end_list.append(slice_end.copy())
                            slice_axes    = np.array([d], dtype=np.int64) # shared value
                            slice_step    = np.array([1], dtype=np.int64) # shared value
                        else:
                            split_axis    = d
                        # Add to Initializer
                        if use_slice == 1:
                            for i in range(0, num_head, 1):
                                CUT_START = numpy_helper.from_array(slice_start_list[i],name=node_name+f"_slice_start{i}")
                                CUT_END   = numpy_helper.from_array(slice_end_list[i],  name=node_name+f"_slice_end{i}")
                                graph.initializer.extend([CUT_START, CUT_END]) 
    
                            CUT_AXES  = numpy_helper.from_array(slice_axes, name=node_name+"_slice_axes")
                            CUT_STEP  = numpy_helper.from_array(slice_step, name=node_name+"_slice_step")
                            graph.initializer.extend([CUT_AXES, CUT_STEP])
                        # Tensor Info b/w Split(Slice) and MatMul
                        div_ina_node_out_info_list = []
                        div_inb_node_out_info_list = []
                        for i in range(0, num_head, 1):
                            div_ina_node_out      = node_name + f"_div_ina_node_out{i}"
                            div_inb_node_out      = node_name + f"_div_inb_node_out{i}"
                            div_ina_node_out_info = helper.make_tensor_value_info(
                                div_ina_node_out,
                                TensorProto.FLOAT, 
                                tgt_shape_a,
                            )
                            div_inb_node_out_info = helper.make_tensor_value_info(
                                div_inb_node_out,
                                TensorProto.FLOAT, 
                                tgt_shape_b,
                            )
                            div_ina_node_out_info_list.append(div_ina_node_out_info)
                            div_inb_node_out_info_list.append(div_inb_node_out_info)
                        # Tensor Info b/w Matmul and Concat
                        matmul_node_out_info_list = []
                        for i in range(0, num_head, 1):
                            matmul_node_out       = node_name + f"_matmul_node_out{i}"
                            matmul_node_out_info  = helper.make_tensor_value_info(
                                matmul_node_out,
                                TensorProto.FLOAT,
                                tgt_shape_y,
                            )
                            matmul_node_out_info_list.append(matmul_node_out_info)
                        for i in range(0, num_head, 1):
                            graph.value_info.extend([div_ina_node_out_info_list[i], div_inb_node_out_info_list[i], matmul_node_out_info_list[i]])

                        # Slice-->MatMul-->Concat
                        if use_slice == 1:
                            # Slice,MatMul(N nodes)
                            for i in range(0, num_head, 1):
                                slice_ina_node = helper.make_node(
                                    "Slice",
                                    inputs  = [node.input[0], 
                                               node_name+f"_slice_start{i}",
                                               node_name+f"_slice_end{i}",
                                               node_name+"_slice_axes",
                                               node_name+"_slice_step",
                                              ],
                                    outputs = [div_ina_node_out_info_list[i].name],
                                    name    = node_name + f"_div_ina{i}"
                                )
                                slice_inb_node = helper.make_node(
                                    "Slice",
                                    inputs  = [node.input[1], 
                                               node_name+f"_slice_start{i}",
                                               node_name+f"_slice_end{i}",
                                               node_name+"_slice_axes",
                                               node_name+"_slice_step",
                                              ],
                                    outputs = [div_inb_node_out_info_list[i].name],
                                    name    = node_name + f"_div_inb{i}"
                                )
                                matmul_node = helper.make_node(
                                    "MatMul",
                                    inputs  = [div_ina_node_out_info_list[i].name, 
                                               div_inb_node_out_info_list[i].name ],
                                    outputs = [matmul_node_out_info_list[i].name],
                                    name    = node_name + f"_div_head{i}"
                                )
                                graph.node.insert(node_idx+i*3,   slice_ina_node)
                                graph.node.insert(node_idx+i*3+1, slice_inb_node)
                                graph.node.insert(node_idx+i*3+2, matmul_node)
                            # Concat(1 node)
                            concat_node = helper.make_node(
                                "Concat",
                                inputs  = [ i.name for i in matmul_node_out_info_list],
                                outputs = [node.output[0]],
                                axis    = concat_axis,
                                name    = node_name + "_concat"
                            )
                            graph.node.insert(node_idx+num_head*3, concat_node)
    
                        # Split-->MatMul-->Concat
                        else:
                            # Split(1 node / input)
                            split_ina_node  = helper.make_node(
                                "Split",
                                inputs      = [node.input[0]],
                                outputs     = [i.name for i in div_ina_node_out_info_list],
                                axis        = split_axis,
                                name        = node_name + f"_div_ina"
                            )
    
                            split_inb_node  = helper.make_node(
                                "Split",
                                inputs      = [node.input[1]],
                                outputs     = [i.name for i in div_inb_node_out_info_list],
                                axis        = split_axis,
                                name        = node_name + f"_div_inb"
                            )
                            graph.node.insert(node_idx,   split_ina_node)
                            graph.node.insert(node_idx+1, split_inb_node)
                            # MatMul(N nodes)
                            for i in range(0, num_head, 1):
                                matmul_node = helper.make_node(
                                    "MatMul",
                                    inputs  = [div_ina_node_out_info_list[i].name, 
                                               div_inb_node_out_info_list[i].name ],
                                    outputs = [matmul_node_out_info_list[i].name],
                                    name    = node_name + f"_div_head{i}"
                                )
                                graph.node.insert(node_idx+i+2, matmul_node)
                            # Concat(1 node)
                            concat_node = helper.make_node(
                                "Concat",
                                inputs  = [ i.name for i in matmul_node_out_info_list],
                                outputs = [node.output[0]],
                                axis    = concat_axis,
                                name    = node_name + "_concat"
                            )
                            graph.node.insert(node_idx+num_head+2, concat_node)
    
                        graph.node.remove(node)
                        inferred = shape_inference.infer_shapes(model)
                        print(f"    > convert: {node.name}")
                        break # NOT delete
      
    onnx.checker.check_model(model)
    model = onnxoptimizer.optimize(model,["eliminate_unused_initializer"])
    return model
