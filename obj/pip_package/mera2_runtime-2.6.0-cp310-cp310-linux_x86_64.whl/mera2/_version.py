# ~~ This file is auto-generated. Please do not touch. ~~
__version__ = "2.6.0"
__githash__ = "0841c03"
