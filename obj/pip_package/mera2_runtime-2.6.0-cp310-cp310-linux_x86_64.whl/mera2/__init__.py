import os
from pathlib import Path

_pkg_dir = Path(__file__).resolve().parent
_ld = os.environ.get("LD_LIBRARY_PATH")
if not _ld:
  os.environ["LD_LIBRARY_PATH"] = str(_pkg_dir)
