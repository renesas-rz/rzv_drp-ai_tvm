#
# (C) Copyright EdgeCortix, Inc. 2021
#
import os

from .... import get_global_func
from .... import tir
from .... import IRModule
from ... import transform
from .... import relay
from ...function import Function
from ...param_dict import save_param_dict
from ...op.contrib.register import get_pattern_table
from ...build_module import bind_params_by_name
from ...build_module import build as _build
from ...expr import Tuple, GlobalVar, bind
from ...expr_functor import ExprMutator, ExprVisitor
from ....ir.transform import Sequential, PassContext
from ....contrib import cc
import numpy as np
from ...dataflow_pattern import *

class IsComputeIntensiveGraph(ExprVisitor):
    """Visit the graph recursively and check if it contains compute heavy ops."""

    def __init__(self):
        ExprVisitor.__init__(self)
        self.is_compute_intensive = False

    def visit_call(self, call):
        compute_intensive_ops = set(
            [
                # "clip",
                "add",
                "nn.conv2d",
                "nn.conv2d_transpose",
                "nn.dense",
                "nn.batch_matmul",
                "nn.max_pool2d",
                "nn.avg_pool2d",
                "nn.global_avg_pool2d",
                "nn.adaptive_avg_pool2d",
            ]
        )
        if isinstance(call.op, tir.op.Op):
            if str(call.op) in compute_intensive_ops:
                self.is_compute_intensive = True
        return super().visit_call(call)

    def is_compute_intensive_graph(self, subgraph) -> bool:
        self.visit(subgraph)
        return self.is_compute_intensive

class InvalidConcatChecker(ExprVisitor):
    """Visit the subgraph recursively and check if it has concat whose inputs are from outside the subgraph."""

    def __init__(self):
        ExprVisitor.__init__(self)
        self.has_invalid_concat = False

    def visit_call(self, call):
        if isinstance(call.op, Function):
            func = call.op
            if hasattr(func.body, "op") and func.body.op.name == "concatenate":
                for arg in call.args:
                    if arg in self.input_args:
                        self.has_invalid_concat = True
        return super().visit_call(call)

    def check(self, subgraph, input_args) -> bool:
        self.input_args = input_args
        self.visit(subgraph)
        return self.has_invalid_concat

class SubgraphRemover(ExprMutator):
    def __init__(self, subgraphs_to_remove, mod):
        ExprMutator.__init__(self)
        self.subgraphs_to_remove = subgraphs_to_remove
        self.mod = mod

    def visit_call(self, call):
        if isinstance(call.op, GlobalVar):
            name = call.op.name_hint
            if name in self.subgraphs_to_remove:
                # "Inline" the subgraph back into new main function
                func = self.mod[name]
                var_map = {}
                for arg, param in zip(call.args, func.params):
                    var_map[param] = super().visit(arg)
                new_body = bind(func.body, var_map)
                return new_body
            if name != "main":
                args = []
                for arg in call.args:
                    args.append(super().visit(arg))
                return call.op(*args)
        return super().visit_call(call)


class InlineFunction(ExprMutator):
    def __init__(self):
        ExprMutator.__init__(self)

    def visit_call(self, call):
        if isinstance(call.op, Function):
            func = call.op
            var_map = {}
            for arg, param in zip(call.args, func.params):
                var_map[param] = super().visit(arg)
            new_body = bind(func.body, var_map)
            return new_body
        return super().visit_call(call)


def prune_no_mac_subgraphs(mod, is_drpai_fp16):
    """Remove subgraphs that have no multiply-accumulates."""
    subgraphs_to_remove = []
    for subgraph in mod.get_global_vars():
        name = subgraph.name_hint
        if not mod[name].attrs or "Compiler" not in mod[name].attrs or mod[name].attrs["Compiler"] != "mera_drp":
            continue
        if not IsComputeIntensiveGraph().is_compute_intensive_graph(mod[name].body):
            subgraphs_to_remove.append(name)
        if is_drpai_fp16 and InvalidConcatChecker().check(mod[name].body, mod[name].params):
            subgraphs_to_remove.append(name)

    # Create new pruned module
    new_mod = IRModule(mod.functions, mod.type_definitions)
    new_mod["main"] = SubgraphRemover(subgraphs_to_remove, mod).visit(mod["main"])
    new_mod["main"] = InlineFunction().visit(new_mod["main"])
    new_mod = transform.RemoveUnusedFunctions()(new_mod)
    return new_mod

class NHWCAddRewriter(DFPatternCallback):
    def __init__(self):
        super().__init__(require_type=True)
        # Pattern: x -> layout_transform(NCHW→NHWC) -> add(const, ...) -> layout_transform(NHWC→NCHW)
        self.x = wildcard()
        self.lt1 = is_op("layout_transform")(self.x)
        self.const = is_constant()
        self.add = is_op("add")(self.const, self.lt1) | is_op("add")(self.lt1, self.const)
        self.lt2 = is_op("layout_transform")(self.add)
        self.pattern = self.lt2
    def callback(self, pre, post, node_map):
        const = node_map[self.const][0]
        x = node_map[self.x][0]
        # Convert constant NHWC -> NCHW
        arr = const.data.asnumpy()
        if len(arr.shape) == 4:
            arr = np.transpose(arr, (0, 3, 1, 2))
        const_nchw = relay.const(arr, dtype=const.data.dtype)
        return relay.op.add(x, const_nchw)
@relay.transform.function_pass(opt_level=1)
class ConvertAddConstToNCHW:
    """Relay pass: convert add(const, x) in NHWC to add(const_NCHW, x) in NCHW"""
    def transform_function(self, func, mod, ctx):
        return rewrite(NHWCAddRewriter(), func)

class SoftmaxNCHWRewriter(DFPatternCallback):
    """
    Match:
        x -> transpose(x, [0,3,1,2]) -> softmax -> layout_transform(NHWC->NCHW)
    Rewrite to:
        nn.softmax(x, axis=1)
    """
    def __init__(self):
        super().__init__(require_type=True)
        self.x = wildcard()
        self.tr = is_op("transpose")(self.x)
        self.sm = is_op("nn.softmax")(self.tr)
        self.lt = is_op("layout_transform")(self.sm)
        self.pattern = self.lt

    def callback(self, pre, post, node_map):
        x  = node_map[self.x][0]
        tr = node_map[self.tr][0]
        sm = node_map[self.sm][0]
        lt = node_map[self.lt][0]
        # Check transpose axes [0,3,1,2]
        if list(tr.attrs.axes) != [0,2,3,1]:
            return post
        # Check layout_transform is NHWC->NCHW
        if lt.attrs.src_layout != "NHWC" or lt.attrs.dst_layout != "NCHW":
            return post
        # Replace with NCHW softmax (axis=1)
        return relay.nn.softmax(x, axis=1)

@relay.transform.function_pass(opt_level=1)
class ConvertSoftmaxToNCHW:
    def transform_function(self, func, mod, ctx):
        return rewrite(SoftmaxNCHWRewriter(), func)

class PreluNCHWRewrite(DFPatternCallback):
    def __init__(self):
        super(PreluNCHWRewrite, self).__init__(require_type=True)
        self.x = wildcard()
        self.alpha = wildcard()
        self.l2n = is_op("layout_transform")(self.x).has_attr({"src_layout": "NCHW", "dst_layout": "NHWC"})
        self.prelu = is_op("nn.prelu")(self.l2n, self.alpha).has_attr({"axis": 3})
        self.n2l = is_op("layout_transform")(self.prelu).has_attr({"src_layout": "NHWC", "dst_layout": "NCHW"})
        self.tr = is_op("transpose")(self.prelu)
        self.pattern = self.n2l | self.tr

    def callback(self, pre, post, node_map):
        # Check transpose axes [0,3,1,2]
        if pre.op.name == "transpose" and list(pre.attrs.axes) != [0,3,1,2]:
            return post
        prelu_call = pre.args[0]  # nn.prelu(...)
        x = prelu_call.args[0].args[0]   # original NCHW input
        alpha = prelu_call.args[1]       # slope constant
        # Rebuild prelu directly in NCHW
        return relay.nn.prelu(x, alpha, axis=1)

@relay.transform.function_pass(opt_level=1)
class ConvertPreluToNCHW:
    def transform_function(self, func, mod, ctx):
        return rewrite(PreluNCHWRewrite(), func)

class ConcatNCHWRewrite(DFPatternCallback):
    def __init__(self):
        super().__init__(require_type=False)
        # Match any number of transpose ops
        trans = is_op("transpose")(wildcard()) | is_op("layout_transform")(wildcard())
        tup = is_tuple(None)   # tuple of N transposes
        concat = is_op("concatenate")(tup)
        self.pattern = is_op("layout_transform")(concat)

    def callback(self, pre, post, node_map):
        concat_call = pre.args[0]
        if concat_call.attrs.axis != 3:
            return post
        # Extract inputs to concat before transpose
        new_inputs = []
        for t in concat_call.args[0].fields:
            if not isinstance(t, relay.Call) or not isinstance(t.op, tvm.ir.Op):
                return post
            if not ((t.op.name == "transpose" and list(t.attrs.axes) == [0,2,3,1]) or (t.op.name == "layout_transform")):
                return post
            new_inputs.append(t.args[0])
        return relay.concatenate(new_inputs, axis=1)

@relay.transform.function_pass(opt_level=1)
class ConvertConcatToNCHW:
    def transform_function(self, func, mod, ctx):
        return rewrite(ConcatNCHWRewrite(), func)


class RemoveNoOpReshape(DFPatternCallback):
    def __init__(self):
        super(RemoveNoOpReshape, self).__init__(require_type=True)
        self.x = wildcard()
        self.reshape = is_op("reshape")(self.x)
        self.pattern = self.reshape

    def callback(self, pre, post, node_map):
        # Get the inferred type of input and output
        in_ty = node_map[self.x][0].checked_type
        out_ty = post.checked_type
        # Check if both are TensorType and have the same static shape
        if (
            isinstance(in_ty, relay.ty.TensorType)
            and isinstance(out_ty, relay.ty.TensorType)
            and list(in_ty.shape) == list(out_ty.shape)
        ):
            # Replace reshape with its input directly
            return node_map[self.x][0]

        # Keep original if shape differs
        return post


@relay.transform.function_pass(opt_level=1)
class RemoveNoOpReshapePass:
    """Relay pass to remove redundant reshape ops that don't change shape"""
    def transform_function(self, func, mod, ctx):
        return relay.dataflow_pattern.rewrite(RemoveNoOpReshape(), func)

def build(mod, params, host_arch, drp_config, output_dir, disable_concat=False, cpu_data_type="float16", cpu_only_mode=False, output_dtype=None):
    if params:
        mod["main"] = bind_params_by_name(mod["main"], params)
    if host_arch == "x86":
        target = "llvm -mcpu=core-avx2"
        fcompile = cc.create_shared
    else:
        assert host_arch == "arm"
        target = "llvm -device=arm_cpu -mtriple=aarch64-linux-gnu -mattr=+neon -mcpu=cortex-a53"
        key_skd_root = "sdk_root"
        assert key_skd_root in drp_config
        fcompile = cc.cross_compiler("{sdk_root}/sysroots/x86_64-pokysdk-linux/usr/bin/aarch64-poky-linux/aarch64-poky-linux-g++".format(sdk_root = drp_config[key_skd_root]),
                                     ["--sysroot={sdk_root}/sysroots/aarch64-poky-linux".format(sdk_root = drp_config[key_skd_root]), "-march=armv8-a", "-mtune=cortex-a53"])

    if cpu_only_mode:
        with PassContext(opt_level=3):
            pass_list = [
                transform.SimplifyInference(),
                transform.FoldConstant(),
                transform.FoldExplicitPadding(),
                transform.BackwardFoldScaleAxis(),
                transform.ForwardFoldScaleAxis(),
                transform.FoldConstant(),
                transform.DynamicToStatic(),
            ]
            if cpu_data_type == "float16":
                pass_list += [
                    transform.ToMixedPrecision("float16"),
                    transform.FoldConstant(),
                ]
            pass_list += [
                transform.RemoveUnusedFunctions(),
            ]

        simplify = Sequential(pass_list)
        mod = simplify(mod)

        with PassContext(opt_level=3):
            json, lib, all_params = _build(mod, target=target, target_host=target, params=params)

    else:
        key_runtime_target = "target"
        assert key_runtime_target in drp_config
        runtime_target = drp_config[key_runtime_target]
        # convert layout to NCHW
        # if the original layout is NCHW, it has no effect
        desired_layouts = {
            'nn.conv2d': ['NCHW', 'default'],
            'nn.conv2d_transpose' : ['NCHW', 'default'],
            'image.resize2d': ['NCHW'],
            'nn.max_pool2d': ['NCHW'],
            'nn.avg_pool2d': ['NCHW'],
            'nn.global_avg_pool2d': ['NCHW']
        }
        seq = Sequential([transform.FoldExplicitPadding(),
                          transform.RemoveUnusedFunctions(),
                          transform.ConvertLayout(desired_layouts),
                          ConvertAddConstToNCHW(),
                          ConvertSoftmaxToNCHW(),
                          ConvertPreluToNCHW(),
                          ConvertConcatToNCHW(),
                          RemoveNoOpReshapePass()])
        with PassContext(opt_level=3):
            mod = seq(mod)

        target_name = "mera_drp"
        # assert get_global_func("relay.ext." + target_name)
        pattern_table = get_pattern_table(target_name)

        with PassContext(opt_level=3):
            pass_list = [
                transform.SimplifyInference(simplify_batchnorm=False),
                transform.FoldConstant(),
                transform.SimplifyExpr(),
                transform.FoldConstant(),
                transform.RemoveUselessPadding(),
                transform.FoldExplicitPadding(),
                transform.BackwardFoldScaleAxis(),
                transform.ForwardFoldScaleAxis(),
                transform.FoldConstant(),
                transform.DynamicToStatic(),
                transform.FoldMulAddToBN(),
                transform.ConvertMulAddToBN(),
                transform.FoldConstant()
            ]
            if cpu_data_type == "float16":
                pass_list += [transform.ToMixedPrecision("float16")]
            pass_list += [transform.FoldConstant()]

        simplify = Sequential(pass_list)
        mod = simplify(mod)

        if cpu_data_type == "float16" and output_dtype == "float32":
            func = mod["main"]
            if isinstance(func.body, relay.Tuple):
                new_fields = [relay.cast(field, "float32") for field in func.body.fields]
                new_body = relay.Tuple(new_fields)
            else:
                new_body = relay.cast(func.body, "float32")
            mod["main"] = relay.Function(func.params, new_body)

        with PassContext(opt_level=3):
            is_drpai_fp16 = runtime_target == "DrpAi" or runtime_target == "Interpreter"
            if is_drpai_fp16:
                pattern_name = "mera_drp_fp16_no_concat" if cpu_data_type == "float16" else "mera_drp_fp32_no_concat"
            else: # For quantizer: DrpAiQuant, InterpreterQuant, Fp32DataRecorder
                drpai_quant_ver = "_ver" + drp_config["drp_compiler_version"]
                type = "_fp16" if cpu_data_type == "float16" else "_fp32"
                pattern_name = "mera_drp_quant" + drpai_quant_ver + type
            pass_list = [transform.MergeComposite(get_pattern_table(pattern_name))]
            if not disable_concat and is_drpai_fp16:
                pass_list += [transform.MergeComposite(get_pattern_table("mera_drp_only_concat"))]
            pass_list += [
                transform.AnnotateTarget(target_name),
                transform.MergeCompilerRegions(),
                transform.PartitionGraph(),
                transform.SimplifyInference(simplify_batchnorm=True),
                transform.FoldConstant(),
                transform.RemoveUnusedFunctions(),
            ]
            partitioned = Sequential(pass_list)(mod)
            pruned = prune_no_mac_subgraphs(partitioned, is_drpai_fp16)
            # re-match operators that are removed together with invalid concat
            pass_list = [
                transform.InferType(),
                transform.MergeComposite(get_pattern_table(pattern_name)),
                transform.AnnotateTarget(target_name),
                transform.MergeCompilerRegions(),
                transform.PartitionGraph(),
            ]
            pruned = Sequential(pass_list)(pruned)
            pruned = prune_no_mac_subgraphs(pruned, is_drpai_fp16)

        set_drp_addr_map = get_global_func("relay.ext.drp.set_addr_map_start")
        set_drp_toolchain = get_global_func("relay.ext.drp.set_toolchain")
        set_runtime_target = get_global_func("relay.ext.drp.set_runtime_target")
        set_calibration_data_record_dir = get_global_func("relay.ext.drp.set_calibration_data_record_dir")
        set_quantization_tool = get_global_func("relay.ext.drp.set_quantization_tool")
        set_quantization_option = get_global_func("relay.ext.drp.set_quantization_option")
        set_calibration_data = get_global_func("relay.ext.drp.set_calibration_data")
        set_cpu_data_type = get_global_func("relay.ext.drp.set_cpu_data_type")
        key_addr_map_start = "addr_map_start"
        key_toolchain = "toolchain_dir"
        key_record_dir = "record_dir"
        key_quantization_tool = "quantization_tool"
        key_quantization_option = "quantization_option"
        key_calibration_data = "calibration_data"
        assert set_drp_addr_map
        assert set_drp_toolchain
        assert set_runtime_target
        assert set_calibration_data_record_dir
        assert set_quantization_tool
        assert set_quantization_option
        assert set_calibration_data

        # Reset the runtime target
        set_runtime_target(drp_config[key_runtime_target])
        if drp_config[key_runtime_target] == "DrpAi" or drp_config[key_runtime_target] == "DrpAiQuant":
            assert key_toolchain in drp_config
            # Reset the DRP-AI address map start address
            if key_addr_map_start in drp_config:
                set_drp_addr_map(drp_config[key_addr_map_start])
            # Reset the DRP-AI toolchain directory
            set_drp_toolchain(drp_config[key_toolchain])
        if drp_config[key_runtime_target] == "Fp32DataRecorder":
            assert key_record_dir in drp_config
            # Reset the Calibration data record directory
            set_calibration_data_record_dir(drp_config[key_record_dir])
        if drp_config[key_runtime_target] == "InterpreterQuant" or drp_config[key_runtime_target] == "DrpAiQuant":
            assert key_quantization_tool in drp_config
            assert key_calibration_data in drp_config
            set_quantization_tool(drp_config[key_quantization_tool])
            set_quantization_option(drp_config[key_quantization_option])
            set_calibration_data(drp_config[key_calibration_data])

        # Set data type the part run on CPU
        set_cpu_data_type(cpu_data_type)

        with PassContext(opt_level=3):
            json, lib, all_params = _build(pruned, target=target, target_host=target, params=params)
        print(pruned)

    # remove constants that are embedded in DRP
    params = {}
    for k, v in all_params.items():
        if not str(k).startswith("tvmgen"):
            params[k] = v

    os.makedirs(output_dir, exist_ok=True)
    lib_path = os.path.join(output_dir, "deploy.so")
    lib.export_library(lib_path, fcompile=fcompile)
    with open(os.path.join(output_dir, "deploy.json"), "w") as f:
        f.write(json)
    with open(os.path.join(output_dir, "deploy.params"), "wb") as f:
        f.write(save_param_dict(params))

    return json, params, lib_path
