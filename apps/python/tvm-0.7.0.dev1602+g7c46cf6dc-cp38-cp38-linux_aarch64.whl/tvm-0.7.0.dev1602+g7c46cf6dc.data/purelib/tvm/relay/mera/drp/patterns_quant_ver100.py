from .patterns_quant_ver091 import *
from .patterns import check_batch_norm, space2depth_pattern, check_space2depth, clip_pattern, add_pattern

def softmax_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    out = is_op("nn.softmax")(data)
    return out

def check_softmax(dtype):
    def _check_softmax(expr):
        attrs, args = expr.attrs, expr.args
        data_type = args[0].checked_type
        if len(data_type.shape) != 2 and len(data_type.shape) != 4:
            return False
        if len(data_type.shape) == 4 and attrs.axis != 1:
            return False
        ch = data_type.shape[1]
        if ch < 1 or ch > 16384:
            return False
        return True
    return _check_softmax

def batch_matmul_pattern(dtype):
    input_a = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    input_b = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    out = is_op("nn.batch_matmul")(input_a, input_b)
    return out

def check_batch_matmul(dtype):
    def can_support_matmul_fxf(lst_shape_in, lst_shape_w):
        """Judge the MatMul FxF is supported or not.
        Parameters
        ----------
        lst_shape_in : list[int]
            onnx input shape 1
        lst_shape_w : list[int]
            onnx input shape 2
        Returns
        -------
        can_support : bool
        Example
        -------
        Below is a sample operation.
            y = MatMul(x0, x1)
                x0.shape = [1, 12, 197,  64]
                x1.shape = [1, 12,  64, 197]
            lst_shape_in = [1, 12, 197,  64]
            lst_shape_w  = [1, 12,  64, 197]
        """
        # Shape dimension check
        import math
        len_diff = len(lst_shape_in) - len(lst_shape_w)
        if (len_diff > 0):
            lst_shape_w = [1] * len_diff + lst_shape_w
        elif (len_diff < 0):
            lst_shape_in = [1] * len_diff + lst_shape_in
        if (len(lst_shape_in) != len(lst_shape_w)):
            return False
        if (len(lst_shape_in) < 2):
            return False
        for dim0, dim1 in zip(lst_shape_in[:-2], lst_shape_w[:-2]):
            if (dim0 != dim1):
                return False
        if (lst_shape_in[-1] != lst_shape_w[-2]):
            return False
        height, ich = lst_shape_in[-2:]
        och = lst_shape_w[-1]
        och_div = min(och, 256)
        LIMIT1 = 1024
        LIMIT2 = LIMIT1// 8 // 64
        ram_pair = math.ceil(
            2 ** (
                1 + math.log2(
                    math.ceil(och_div / 64))))
        depth = 16 // ram_pair
        ich_max = LIMIT1 * depth * LIMIT2
        if (ich > ich_max):
            return False
        FMBUF_NUM_BANK = 32
        FMBUF_NUM_WORD = 2048
        FMBUF_BIT_LEN = 256
        FMBUF_CH_LEN = FMBUF_BIT_LEN / 8
        def _calc(lst_h, w, ch):
            lp = math.ceil(ch / FMBUF_CH_LEN) * w
            line_addr_size = math.ceil(lp / 2) * 2
            h = math.prod(lst_h) if (len(lst_h) > 0) else 1
            by = math.ceil(h / FMBUF_NUM_BANK)
            _size = line_addr_size * by
            if (ch > 64 and ch % 64 != 0):
                _size += 2
            return _size
        och_div2 = min(64, och_div)  # 8/20 update
        size_in = _calc(lst_shape_in[:-1], 1, ich)
        size_w = _calc(lst_shape_w[:-1], 1, och)
        size_fmap = _calc([1], och_div2, ich)
        size_maxp = size_fmap
        size_out = _calc(lst_shape_in[:-2] + [height], 1, och)
        has_maxp = (ich % 2 != 0) or (och % 2 != 0)
        size = size_in + size_w + size_out + size_fmap
        if (has_maxp):
            size += size_maxp
        if (size > FMBUF_NUM_WORD):
            return False
        height_total = math.prod(lst_shape_in[:-1])
        if (height_total > 8192):
            return False
        else:
            return True
    def _check_batch_matmul(expr):
        attrs, args = expr.attrs, expr.args
        data_type = args[0].checked_type
        weight_type = args[1].checked_type
        if isinstance(args[0], relay.expr.Constant) or isinstance(args[1], relay.expr.Constant):
            return False
        if attrs.transpose_a or attrs.transpose_b:
            return False
        if data_type.dtype != dtype or weight_type.dtype != dtype:
            return False
        data_shape = [int(it) for it in data_type.shape]
        weight_shape = [int(it) for it in weight_type.shape]
        return can_support_matmul_fxf(data_shape, weight_shape)
    return _check_batch_matmul

def batch_norm_pattern(dtype):
    # batch norm
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    gamma = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    beta = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    moving_mean = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    moving_var = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    bn = is_tuple_get_item(is_op("nn.batch_norm")(data, gamma, beta, moving_mean, moving_var), 0)
    # activation
    bn = bn.optional(lambda x: is_op("nn.relu")(x)
                             | is_op("nn.leaky_relu")(x)
                             | swish_pattern(x)
                             | mish_pattern(x)
                             | is_op("sigmoid")(x))
    return bn

def split_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    out = is_op("split")(data)
    return out

def check_split(dtype):
    def _check_split(expr):
        attrs, args = expr.attrs, expr.args
        data_type = args[0].checked_type
        if data_type.dtype != dtype:
            return False
        if attrs.axis not in {1,2,3}:
            return False
        split_section = attrs.indices_or_sections.value \
            if isinstance(attrs.indices_or_sections, tvm.tir.expr.IntImm) \
               else (len(attrs.indices_or_sections) + 1)
        if split_section > 8:
            return False
        return True
    return _check_split

def check_conv(dtype):
    def _check_conv(extract):
        def _check_conv_op(extract):
            args, attrs = extract.args, extract.attrs
            if not isinstance(args[1], relay.expr.Constant):
                return False
            if attrs.out_dtype != dtype and attrs.out_dtype != "":
                return False
            if attrs.data_layout != "NCHW":
                return False
            data_type = args[0].checked_type
            if data_type.dtype != dtype:
                return False
            input_channel = data_type.shape[1]
            dilation, groups = list(attrs.dilation), int(attrs.groups)
            kernel_type = args[1].checked_type
            o_channels = int(attrs.channels)
            kernel_size, padding, strides = list(attrs.kernel_size), list(attrs.padding), list(attrs.strides)
            if groups != o_channels and groups > 1:
                if not (1 < groups < input_channel and input_channel % groups == 0):
                    return False
                if max(padding) != min(padding) != 1:
                    return False
                cond1 = kernel_size == [1,1]   and strides in ([1,1],[2,2]) and padding == [0, 0, 0, 0]
                cond2 = kernel_size == [3,3]   and strides in ([1,1],[2,2]) and int(max(padding)) <= 1
                cond3 = kernel_size == [4,4]   and strides == [1,1]         and int(max(padding)) <= 2
                cond4 = kernel_size == [5,5]   and strides in ([1,1],[2,2]) and int(max(padding)) <= 2
                cond5 = kernel_size == [6,6]   and strides == [1,1]         and int(max(padding)) <= 3
                cond6 = kernel_size == [7,7]   and strides in ([1,1],[2,2]) and int(max(padding)) <= 3
                cond7 = kernel_size == [9,9]   and strides in ([1,1],[2,2]) and int(max(padding)) <= 4
                cond8 = kernel_size == [11,11] and strides == [1,1]         and int(max(padding)) <= 5
                return cond1 or cond2 or cond3 or cond4 or cond5 or cond6 or cond7 or cond8

            is_depthwise = is_depthwise_conv2d(
                data_type.shape,
                attrs["data_layout"],
                kernel_type.shape,
                attrs["kernel_layout"],
                attrs["groups"],
            )

            # Dilated and Depthwise Convolution
            if is_depthwise:
                cond1 = kernel_size == [3,3] and strides in ([1,1],[2,2]) and int(max(padding)) <= int(max(strides))
                cond2 = kernel_size == [5,5] and strides in ([1,1],[2,2]) and int(max(padding)) <= 2
                cond3 = kernel_size == [7,7] and strides in ([1,1],[2,2]) and int(max(padding)) <= 3
                if (cond1 or cond2 or cond3) and dilation == [1,1] and groups == o_channels == input_channel:
                    return True
                # dilated
                if kernel_size in ([3,3], [5,5], [7,7]) and strides == [1,1] and int(max(padding)) <= dilation[0] and \
                   dilation[0] == dilation[1] and 2 <= dilation[0] <= 36 and groups == o_channels == input_channel:
                    return True
                return False

            if dilation == [1,1] and groups == 1:
               cond1 = kernel_size == [1,1]   and strides in ([1,1], [2,2]) and padding == [0,0,0,0]
               cond2 = kernel_size == [2,2]   and strides in ([1,1], [2,2]) and int(max(padding)) <= 1
               cond3 = kernel_size == [3,3]   and strides in ([1,1], [2,2]) and int(max(padding)) <= int(max(strides))
               cond4 = kernel_size == [4,4]   and strides == [1,1]          and int(max(padding)) <= 2
               cond5 = kernel_size == [5,5]   and strides in ([1,1], [2,2]) and int(max(padding)) <= 2
               cond6 = kernel_size == [6,6]   and strides in ([1,1], [2,2]) and int(max(padding)) <= 3
               cond7 = kernel_size == [7,7]   and strides in ([1,1], [2,2]) and int(max(padding)) <= 3
               cond8 = kernel_size == [9,9]   and strides in ([1,1], [2,2]) and int(max(padding)) <= 4
               cond9 = kernel_size == [11,11] and strides == [1,1]          and int(max(padding)) <= 5
               cond10 = kernel_size == [16,16] and strides == [16,16]        and padding == [0,0,0,0]
               cond11 = kernel_size == [1,7]   and strides == [1,1]          and padding == [0,3,0,3] #tlbr
               cond12 = kernel_size == [7,1]   and strides == [1,1]          and padding == [3,0,3,0] #tlbr
               cond13 = kernel_size == [1,3]   and strides == [1,1]          and padding == [0,1,0,1] #tlbr
               cond14 = kernel_size == [3,1]   and strides == [1,1]          and padding == [1,0,1,0] #tlbr
               return cond1 or cond2 or cond3 or cond4 or cond5 or cond6 or cond7 or cond8 or cond9 or cond10 or cond11 or cond12 or cond13 or cond14

            # dilated conv
            if kernel_size == [3,3] and strides == [1,1] and groups == 1 \
               and dilation[0] == dilation[1] and 2 <= dilation[0] <= 36 \
               and padding[0] == padding[1] == padding[2] == padding[3]:
                return True
            return False
        def _check_bias_add(expr):
            if not isinstance(expr.args[1], relay.expr.Constant):
                return False
            return True
        call = extract
        while True:
            if isinstance(call, relay.TupleGetItem):
                call = call.tuple_value
            if call.op.name == "bias_add":
                if not _check_bias_add(call):
                    return False
            if call.op.name == "multiply" and call.args[1].op.name == "divide": #hardswish
                if not check_hardswish(dtype)(call):
                   return False
            if call.op.name == "nn.conv2d":
                return _check_conv_op(call)
            call = call.args[0]
    return _check_conv

def check_resize(dtype):
    def _check_resize(expr):
        attrs, args = expr.attrs, expr.args
        data_type = args[0].checked_type
        if data_type.dtype != dtype or data_type.shape[0] != 1 or len(data_type.shape) != 4:
            return False
        if attrs.layout != "NCHW":
            return False
        ih,iw = list(data_type.shape)[2:]
        oh,ow = list(attrs.size)
        if ih > 4096 or iw > 4096 or oh > 4096 or ow > 4096:
            return False
        if attrs.coordinate_transformation_mode not in {"half_pixel", "pytorch_half_pixel", "align_corners", "asymmetric"}:
            return False
        if attrs.method not in {"nearest_neighbor", "linear"}:
            return False
        return True
    return _check_resize

def relu_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    return is_op("nn.relu")(data) | is_op("nn.leaky_relu")(data)

def prelu_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    slope = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    return is_op("nn.prelu")(data, slope)

def check_prelu(dtype):
    def _check_prelu(expr):
        data_type = expr.args[0].checked_type
        if data_type.dtype != dtype or data_type.shape[0] != 1 or len(data_type.shape) != 4:
            return False
        return True
    return _check_prelu

def slice_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    return is_op("strided_slice")(data)

def check_slice(dtype):
    def _check_slice(expr):
        attrs, args = expr.attrs, expr.args
        data_type = args[0].checked_type
        if data_type.dtype != dtype or data_type.shape[0] != 1 or len(data_type.shape) != 4:
            return False
        if len(attrs.begin) != 1 or attrs.axes[0] != 1 or attrs.strides[0] != 1:
            return False
        return True
    return _check_slice

def conv_transpose_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    weight = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    conv_transpose = is_op("nn.conv2d_transpose")(data, weight)
    bias = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard() # it will be merged to Conv tranpose.
    conv_transpose = conv_transpose.optional(lambda x: is_op("nn.bias_add")(x, bias))
    return conv_transpose

def check_conv_transpose(dtype):
    def _check_conv_transpose(extract):
        def _check_conv_transpose_op(extract):
            args, attrs = extract.args, extract.attrs
            if not isinstance(args[1], relay.expr.Constant):
                return False
            if attrs.out_dtype != dtype and attrs.out_dtype != "":
                return False
            if attrs.data_layout != "NCHW":
                return False
            data_type = args[0].checked_type
            if data_type.dtype != dtype:
                return False
            dilation, groups = list(attrs.dilation), int(attrs.groups)
            kernel_size, padding, strides = list(attrs.kernel_size), list(attrs.padding), list(attrs.strides)
            if dilation != [1, 1] or groups != 1 or strides != [2, 2]:
                return False
            cond1 = kernel_size == [2, 2] and int(max(padding)) <= 1
            cond2 = kernel_size == [3, 3] and int(max(padding)) <= 2
            cond3 = kernel_size == [4, 4] and int(max(padding)) <= 3
            return  cond1 or cond2 or cond3
        def _check_bias_add(expr):
            if not isinstance(expr.args[1], relay.expr.Constant):
                return False
            return True
        call = extract
        while True:
            if isinstance(call, relay.TupleGetItem):
                call = call.tuple_value
            if call.op.name == "bias_add":
                if not _check_bias_add(call):
                    return False
            if call.op.name == "nn.conv2d_transpose":
                return _check_conv_transpose_op(call)
            call = call.args[0]
        return True
    return _check_conv_transpose

def maxmin_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    max_value = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    min_value = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    out = is_op("maximum")(data, max_value)
    out = is_op("minimum")(out, min_value)
    return out

def multiply_pattern(dtype):
    x = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    y = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    return is_op("multiply")(x, y)

def check_multiply(dtype):
    def _check_multiply(extract):
        def _check_multiply_op(arg0, arg1):
            arg0_type = arg0.checked_type
            arg1_type = arg1.checked_type
            if len(arg0_type.shape) != 4:
                return False
            ch = arg0_type.shape[1];
            if isinstance(arg1, relay.expr.Constant): # second arg is parameter
                if len(arg1_type.shape) not in (0, 1, 4):
                    return False
                if len(arg1_type.shape) == 4 and list(arg1_type.shape) != [1, ch, 1, 1]:
                    return False
                return True
            # second arg is feature map
            if len(arg1_type.shape) != 4:
                return False
            if list(arg1_type.shape) != list(arg0_type.shape) and list(arg1_type.shape) != [1, ch, 1, 1]:
                return False
            return True
        args = extract.args
        if isinstance(args[0], relay.expr.Constant) and isinstance(args[1], relay.expr.Constant):
            return False
        if  args[0].checked_type.dtype != dtype or args[0].checked_type.dtype != dtype:
            return False
        return _check_multiply_op(args[0], args[1]) or _check_multiply_op(args[1], args[0])
    return _check_multiply

def check_reorg(dtype):
    def _check_reorg(extract):
        reshape2 = extract
        transpose = reshape2.args[0]
        reshape1 = transpose.args[0]
        # check reshape1
        data_type = reshape1.args[0].checked_type
        if data_type.shape[0] != 1 or len(data_type.shape) != 4 or data_type.dtype != dtype:
            return False
        if len(reshape1.attrs.newshape) != 6:
            return False

        perm = list(transpose.attrs.axes)
        if perm == [0,3,5,1,2,4]:
            in_c, in_h, in_w = data_type.shape[1:4]
            out_c, out_h, _, out_w = reshape1.attrs.newshape[1:5]
            if in_c != 4*out_c or in_h != out_h or in_w != out_w:
                return False
            if len(reshape2.attrs.newshape) != 4:
                return False
            out_c, out_h, out_w = reshape2.attrs.newshape[1:4]
            if (in_c * 4 != out_c and -1 != out_c) or in_h != out_h * 2 or in_w != out_w * 2:
                return False
            return True
        elif perm == [0,5,3,1,2,4]:
            in_c, in_h, in_w = data_type.shape[1:4]
            out_c, out_h, _, out_w = reshape1.attrs.newshape[1:5]
            if in_c != out_c or in_h != out_h * 2 or (out_w != -1 and in_w != out_w * 2):
                return False
            if len(reshape2.attrs.newshape) != 4:
                return False
            out_c, out_h, out_w = reshape2.attrs.newshape[1:4]
            if in_c * 4 != out_c or in_h != out_h * 2 or in_w != out_w * 2:
                return False
            return True
        return False
    return _check_reorg

def pad_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    pad_value = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    out = is_op("nn.pad")(data, pad_value)
    return out

def check_pad(dtype):
    def _check_pad(expr):
        args, attrs = expr.args, expr.attrs
        data_type = args[0].checked_type
        if data_type.dtype != dtype:
            return False
        if len(data_type.shape) != 4 or data_type.shape[0] != 1:
            return False
        pad_mode = str(attrs.pad_mode)
        if pad_mode != 'constant':
            return False
        pad_n, pad_c, pad_h, pad_w = list(attrs.pad_width[0]), list(attrs.pad_width[1]), list(attrs.pad_width[2]), list(attrs.pad_width[3])
        pad_value = args[1].data.asnumpy().item()
        if pad_n != [0, 0] or pad_value != 0.0:
            return False
        if pad_c != [0,0] and (pad_h != [0,0] or pad_w != [0,0]):
            return False
        return True
    return _check_pad

def hardsigmoid_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    return is_op("multiply")(is_op("clip")(is_op("add")(data, is_constant())), is_constant())

def check_hardsigmoid(dtype):
    def _check_hardsigmoid(expr):
        multiply = expr
        if not np.array_equal(multiply.args[1].data.numpy(), np.array(1 / 6).astype(dtype)):
            return False
        clip = multiply.args[0]
        if clip.attrs.a_min != 0.0:
            return False
        if clip.attrs.a_max != 6.0:
            return False
        add = clip.args[0]
        if not np.array_equal(add.args[1].data.numpy(), np.array(3).astype(dtype)):
            return False
        return True
    return _check_hardsigmoid

def mera_drp_quant_pattern_table(dtype):
    return [
        # sequence of operators
        ("mera_drp.reshape_or_flatten_and_dense", reshape_or_flatten_and_dense_pattern(dtype), check_reshape_or_flatten_and_dense(dtype)),
        ("mera_drp.reorg", reorg_pattern(dtype), check_reorg(dtype)),
        ("mera_drp.focus", focus_pattern(dtype), check_focus(dtype)),
        ("mera_drp.space2depth", space2depth_pattern(dtype), check_space2depth(dtype)),
        ("mera_drp.mish", mish_pattern(is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard())),
        ("mera_drp.hardswish", hardswish_pattern(is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()), check_hardswish(dtype)),
        ("mera_drp.pad_maxpool", pad_maxpool_pattern(dtype), check_pad_maxpool(dtype)),
        ("mera_drp.gemm", gemm_pattern(dtype), check_gemm(dtype)),
        ("mera_drp.matmul", matmul_pattern(dtype), check_matmul(dtype)),
        ("mera_drp.maxmin", maxmin_pattern(dtype)),
        ("mera_drp.hardsigmoid", hardsigmoid_pattern(dtype), check_hardsigmoid(dtype)),
        # single operator
        ("mera_drp.batch_matmul", batch_matmul_pattern(dtype), check_batch_matmul(dtype)),
        ("mera_drp.conv2d", conv_pattern(dtype), check_conv(dtype)),
        ("mera_drp.conv2d_transpose", conv_transpose_pattern(dtype), check_conv_transpose(dtype)),
        ("mera_drp.batch_norm", batch_norm_pattern(dtype), check_batch_norm),
        ("mera_drp.add", add_pattern(dtype), check_add(dtype)),
        ("mera_drp.clip", clip_pattern(dtype)),
        ("mera_drp.max_pool2d", max_pool2d_pattern(dtype), check_max_pool2d(dtype)),
        ("mera_drp.avg_pool2d", avg_pool2d_pattern(dtype), check_avg_pool2d(dtype)),
        ("mera_drp.concatenate", concatenate_pattern(dtype), check_concatenate(dtype)),
        ("mera_drp.resize", resize_pattern(dtype), check_resize(dtype)),
        ("mera_drp.upsampling", upsampling_pattern(dtype), check_upsampling(dtype)),
        ("mera_drp.global_avg_pool2d", global_avg_pool2d_pattern(dtype), check_global_avg_pool2d(dtype)),
        ("mera_drp.adaptive_avg_pool2d", adaptive_avg_pool2d_pattern(dtype), check_adaptive_avg_pool2d(dtype)),
        ("mera_drp.sigmoid", sigmoid_pattern(dtype)),
        ("mera_drp.softmax", softmax_pattern(dtype), check_softmax(dtype)),
        ("mera_drp.split", split_pattern(dtype), check_split(dtype)),
        ("mera_drp.relu", relu_pattern(dtype)),
        ("mera_drp.prelu", prelu_pattern(dtype), check_prelu(dtype)),
        ("mera_drp.slice", slice_pattern(dtype), check_slice(dtype)),
        ("mera_drp.multiply", multiply_pattern(dtype), check_multiply(dtype)),
        ("mera_drp.pad", pad_pattern(dtype), check_pad(dtype)),
    ]

@register_pattern_table("mera_drp_quant_ver100_fp32")
def mera_drp_quant_pattern_table_float32():
    return mera_drp_quant_pattern_table('float32')

@register_pattern_table("mera_drp_quant_ver100_fp16")
def mera_drp_quant_pattern_table_float16():
    return mera_drp_quant_pattern_table('float16')
