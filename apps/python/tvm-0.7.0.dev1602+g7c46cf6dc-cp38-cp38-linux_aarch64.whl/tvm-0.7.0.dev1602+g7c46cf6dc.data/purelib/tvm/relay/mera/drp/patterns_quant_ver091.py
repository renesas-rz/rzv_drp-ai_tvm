#
# (C) Copyright EdgeCortix, Inc. 2023
#
import tvm

from tvm import relay
from tvm.topi.nn import get_const_int, get_const_tuple
from ...dataflow_pattern import is_constant, is_op, is_tuple, is_tuple_get_item, wildcard
from ...op.strategy.generic import is_depthwise_conv2d
from ...op.contrib.register import register_pattern_table
from .patterns import swish_pattern, mish_pattern, softplus_pattern, hardswish_pattern, \
    adaptive_avg_pool2d_pattern, check_adaptive_avg_pool2d, upsampling_pattern, check_upsampling, \
    swish_pattern, reshape_or_flatten_and_dense_pattern

import numpy as np

def conv_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    weight = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    conv = is_op("nn.conv2d")(data, weight)
    # activation
    bias = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard() # it will be merged to Conv

    gamma = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    beta = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    moving_mean = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    moving_var = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()

    conv = conv.optional(lambda x: is_op("nn.bias_add")(x, bias))
    conv = conv.optional(lambda x: is_tuple_get_item(is_op("nn.batch_norm")(x, gamma, beta, moving_mean, moving_var), 0))
    conv = conv.optional(lambda x: is_op("nn.relu")(x)
                                 | is_op("nn.leaky_relu")(x)
                                 | is_op("tanh")(x)
                                 | swish_pattern(x)
                                 | mish_pattern(x)
                                 | softplus_pattern(x)
                                 | hardswish_pattern(x))
    return conv

def check_hardswish(dtype):
    def _check_hardswish(expr):
        if expr.op.name == "multiply":
            multiply = expr
            divide = multiply.args[1]
            if not np.array_equal(divide.args[1].data.numpy(), np.array(6).astype(dtype)):
                return False
            clip = divide.args[0]
        elif expr.op.name == "divide":
            divide = expr
            if not np.array_equal(divide.args[1].data.numpy(), np.array(6).astype(dtype)):
                return False
            multiply = divide.args[0]
            clip = multiply.args[1]
        else:
            return False
        if clip.attrs.a_min != 0.0:
            return False
        if clip.attrs.a_max != 6.0:
            return False
        add = clip.args[0]
        if not np.array_equal(add.args[1].data.numpy(), np.array(3).astype(dtype)):
            return False
        return True
    return _check_hardswish

def check_conv(dtype):
    def _check_conv(extract):
        def _check_conv_op(extract):
            args, attrs = extract.args, extract.attrs
            if not isinstance(args[1], relay.expr.Constant):
                return False
            if attrs.out_dtype != dtype and attrs.out_dtype != "":
                return False
            if attrs.data_layout != "NCHW":
                return False
            data_type = args[0].checked_type
            if data_type.dtype != dtype:
                return False
            input_channel = data_type.shape[1]
            dilation, groups = list(attrs.dilation), int(attrs.groups)
            kernel_type = args[1].checked_type
            o_channels = int(attrs.channels)
            if groups != o_channels and groups > 1:
                return False
            kernel_size, padding, strides = list(attrs.kernel_size), list(attrs.padding), list(attrs.strides)
            is_depthwise = is_depthwise_conv2d(
                data_type.shape,
                attrs["data_layout"],
                kernel_type.shape,
                attrs["kernel_layout"],
                attrs["groups"],
            )

            # Dilated and Depthwise Convolution
            if is_depthwise:
                cond1 = kernel_size == [3,3] and strides in ([1,1],[2,2]) and padding in ([0,0,0,0], [1,1,1,1])
                cond2 = kernel_size == [5,5] and strides in ([1,1],[2,2]) and padding == [2,2,2,2]
                if cond1 or cond2:
                    return True
                if strides in ([1,1],[2,2]) and groups == o_channels and dilation == [1,1]:
                    return False
                if groups == o_channels and dilation[0] == dilation[1] and dilation[0] > 1:
                    return False
                return True

            if dilation == [1,1]:
               cond1 = kernel_size == [1,1]   and strides in ([1,1], [2,2]) and padding == [0,0,0,0]
               cond2 = kernel_size == [3,3]   and strides in ([1,1], [2,2]) and int(max(padding)) < 2
               cond3 = kernel_size == [5,5]   and strides in ([1,1], [2,2]) and padding == [2,2,2,2]
               cond4 = kernel_size == [7,7]   and strides in ([1,1], [2,2]) and padding == [3,3,3,3]
               cond5 = kernel_size == [9,9]   and strides == [1,1]          and padding == [4,4,4,4]
               cond6 = kernel_size == [11,11] and strides == [1,1]          and padding == [5,5,5,5]
               return cond1 or cond2 or cond3 or cond4 or cond5 or cond6

            # dilated conv
            if kernel_size == [3,3] and strides == [1,1] and groups == 1 \
               and dilation[0] == dilation[1] and 2 <= dilation[0] <= 36 \
               and padding[0] == padding[1] == padding[2] == padding[3]:
                return True
            return False
        def _check_bias_add(expr):
            if not isinstance(expr.args[1], relay.expr.Constant):
                return False
            return True
        call = extract
        while True:
            if isinstance(call, relay.TupleGetItem):
                call = call.tuple_value
            if call.op.name == "bias_add":
                if not _check_bias_add(call):
                    return False
            if call.op.name == "multiply" and call.args[1].op.name == "divide": #hardswish
                if not check_hardswish(dtype)(call):
                   return False
            if call.op.name == "nn.conv2d":
                return _check_conv_op(call)
            call = call.args[0]
    return _check_conv

def add_pattern(dtype):
    x = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    y = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    add = is_op("add")(x, y)
    add = add.optional(lambda x: is_op("nn.relu")(x))
    return add

def check_add(dtype):
    def _check_add(extract):
        def _check_add_op(extract):
            args = extract.args
            if isinstance(args[0], relay.expr.Constant) or isinstance(args[1], relay.expr.Constant):
                return False
            left_type = args[0].checked_type
            right_type = args[1].checked_type
            if left_type.dtype != dtype:
                return False
            if right_type.dtype != dtype:
                return False
            if list(left_type.shape) != list(right_type.shape):
                return False
            if len(left_type.shape) != 2 and len(left_type.shape) != 4:
                return False
            return True
        call = extract
        while True:
            if call.op.name == "add":
                return _check_add_op(call)
            call = call.args[0]

    return _check_add

def max_pool2d_pattern(dtype):
    input = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    max_pool2d = is_op("nn.max_pool2d")(input)
    return max_pool2d

def check_max_pool2d(dtype):
    def check_max_pool2d_(extract):
        args, attrs = extract.args, extract.attrs
        data_type = args[0].checked_type
        if data_type.dtype != dtype:
            return False
        padding, pool_size, strides = list(attrs.padding), list(attrs.pool_size), list(attrs.strides)
        if strides not in ([1,1], [2,2]):
            return False
        is_kernel_padding_valid = False
        for i in range(2,16): # Supported kernel size [2,2] -> [15,15]
            if pool_size == [i,i] and max(padding) <= i//2:
                is_kernel_padding_valid = True
                break
        if not is_kernel_padding_valid:
            return False
        return True
    return check_max_pool2d_

def avg_pool2d_pattern(dtype):
    input = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    avg_pool2d = is_op("nn.avg_pool2d")(input)
    return avg_pool2d

def check_avg_pool2d(dtype):
    def check_avg_pool2d_(extract):
        args, attrs = extract.args, extract.attrs
        data_type = args[0].checked_type
        if data_type.dtype != dtype:
            return False
        input_h, input_w = data_type.shape[2], data_type.shape[3]
        padding, pool_size, strides = list(attrs.padding), list(attrs.pool_size), list(attrs.strides)
        if input_h == pool_size[0] and input_w == pool_size[1]: # Equivalent with global average pool
            return True
        if padding != [0,0,0,0]:
            return False
        if pool_size[0] != pool_size[1] or pool_size[0] < 2 or pool_size[0] > 15:
            return False
        if strides != [1,1] and strides != [2,2]:
            return False
        return True
    return check_avg_pool2d_

def concatenate_pattern(dtype):
    input = is_tuple(None)
    concat = is_op("concatenate")(input)
    return concat

def check_concatenate(dtype):
    def _check_concatenate(extract):
        axis = extract.attrs.axis
        if axis != 1: # TODO: Is this channel dimension concat???
            return False
        return True
    return _check_concatenate

def reorg_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    # reshape
    out = is_op("reshape")(data)
    # transpose
    out = is_op("transpose")(out)
    # reshape
    out = is_op("reshape")(out)
    return out

def check_reorg(dtype):
    def _check_reorg(extract):
        reshape2 = extract
        transpose = reshape2.args[0]
        reshape1 = transpose.args[0]
        # check reshape1
        data_type = reshape1.args[0].checked_type
        if data_type.shape[0] != 1 or len(data_type.shape) != 4 or data_type.dtype != dtype:
            return False
        if len(reshape1.attrs.newshape) != 6:
            return False
        in_c, in_h, in_w = data_type.shape[1:4]
        out_c, out_h, out_w = reshape1.attrs.newshape[1], reshape1.attrs.newshape[2], reshape1.attrs.newshape[4]
        if in_c != 4*out_c or in_h != out_h or in_w != out_w:
            return False
        perm = list(transpose.attrs.axes)
        if perm != [0,3,5,1,2,4]:
            return False
        if len(reshape2.attrs.newshape) != 4:
            return False
        out_c, out_h, out_w = reshape2.attrs.newshape[1:4]
        if (in_c * 4 != out_c and -1 != out_c) or in_h != out_h * 2 or in_w != out_w * 2:
            return False
        return True

    return _check_reorg

def resize_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    out = is_op("image.resize2d")(data)
    return out

def check_resize(dtype):
    def _check_resize(expr):
        attrs, args = expr.attrs, expr.args
        data_type = args[0].checked_type
        if data_type.dtype != dtype or data_type.shape[0] != 1 or len(data_type.shape) != 4:
            return False
        if attrs.layout != "NCHW":
            return False
        ih,iw = list(data_type.shape)[2:]
        oh,ow = list(attrs.size)
        if ih > 4096 or iw > 4096 or oh > 4096 or ow > 4096:
            return False
        if attrs.coordinate_transformation_mode not in {"half_pixel", "pytorch_half_pixel", "align_corners", "asymmetric"}:
            return False
        if attrs.method not in {"nearest_neighbor", "linear"}:
            return False
        if attrs.rounding_method and attrs.rounding_method != "floor":
            return False
        return True
    return _check_resize

def global_avg_pool2d_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    pattern = is_op("nn.global_avg_pool2d")(data)
    return pattern

def check_global_avg_pool2d(dtype):
    def _check_global_avg_pool2d(expr):
        attrs, args = expr.attrs, expr.args
        # check layout and data type
        if attrs.layout != "NCHW":
            return False
        data_type = args[0].checked_type
        if len(data_type.shape) != 4 or data_type.shape[0] != 1 or data_type.dtype != dtype:
            return False
        return True
    return _check_global_avg_pool2d

def sigmoid_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    out = is_op("sigmoid")(data)
    return out

def focus_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    out0 = is_op("strided_slice")(is_op("strided_slice")(data))
    out1 = is_op("strided_slice")(is_op("strided_slice")(data))
    out2 = is_op("strided_slice")(is_op("strided_slice")(data))
    out3 = is_op("strided_slice")(is_op("strided_slice")(data))
    pattern = is_op("concatenate")(is_tuple([out0, out1, out2, out3]))
    return pattern

def check_focus(dtype):
    def _check_focus(extract):
        if extract.op.name == 'concatenate':
            begin_patterns = {(0,0), (0,1), (1,0), (1,1)}
            for arg in extract.args[0]:
                begins = []
                while isinstance(arg, relay.expr.Call):
                    if arg.checked_type.dtype != dtype:
                        return False
                    if arg.op.name == 'strided_slice':
                        if arg.attrs.axes is None:
                            idx = -1
                            for i in range(len(arg.attrs.strides)):
                                # axes is None, we need get which dim index will be sliced by using strides value.
                                if arg.attrs.strides[i] != 1:
                                    if idx == -1:
                                        idx = i
                                    else:
                                        return False
                            if arg.attrs.end[idx] != 0x7fffffff: #-1
                                return False
                            begins.append(arg.attrs.begin[idx])
                            if len(begins) == 1 and idx != 3:
                                return False
                            if len(begins) == 2 and idx != 2:
                                return False
                            if arg.attrs.strides[idx] != 2:
                                return False
                            if tuple(begins) in begin_patterns:
                                begin_patterns.remove(tuple(begins))
                            elif len(begins) == 2:
                                return False
                        else:
                            if len(arg.attrs.begin) != 1:
                                return False
                            if arg.attrs.end[0] != 0x7fffffffffffffff: #-1
                                return False
                            begins.append(arg.attrs.begin[0])
                            if len(begins) == 1 and arg.attrs.axes[0] != 3:
                                return False
                            if len(begins) == 2 and arg.attrs.axes[0] != 2:
                                return False
                            if arg.attrs.strides[0] != 2:
                                return False
                            if tuple(begins) in begin_patterns:
                                begin_patterns.remove(tuple(begins))
                            elif len(begins) == 2:
                                return False
                    arg = arg.args[0]
        else:
            return False
        return len(begin_patterns) == 0
    return _check_focus

def pad_maxpool_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    pad_value = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    out = is_op("nn.pad")(data, pad_value)
    out = is_op("nn.max_pool2d")(out)
    return out

def check_pad_maxpool(dtype):
    def _check_pad_maxpool(extract):
        def _check_pad_maxpool_op(pad, maxpool):
            maxpool_attrs = maxpool.attrs
            args, attrs = pad.args, pad.attrs
            pad_mode = str(attrs.pad_mode)
            if pad_mode == 'const':
                return False
            data_type = args[0].checked_type
            if data_type.dtype != dtype:
                return False
            if len(data_type.shape) != 4 or [0,0] != list(attrs.pad_width[0]) or [0,0] != list(attrs.pad_width[1]):
                # Didn't support fused padding in NC, yet.
                return False
            [t,b], [l,r] = list(attrs.pad_width[2]), list(attrs.pad_width[3])
            pad_padding = [t,l,b,r]
            maxpool_padding, pool_size = list(maxpool_attrs.padding), list(maxpool_attrs.pool_size)
            fused_padding = [x + y for x, y in zip(maxpool_padding, pad_padding)]
            is_kernel_padding_valid = False
            for i in range(2,16): # Supported kernel size [2,2] -> [15,15]
                if pool_size == [i,i] and max(fused_padding) <= i//2:
                    is_kernel_padding_valid = True
                    break
            if not is_kernel_padding_valid:
                return False
            return True
        call = extract
        while True:
            if call.op.name == "nn.max_pool2d":
                maxpool_op = call
                if not check_max_pool2d(dtype)(call):
                    return False
            elif call.op.name == "nn.pad":
                if _check_pad_maxpool_op(call, maxpool_op):
                    return True
                else:
                    return False
            call = call.args[0]
    return _check_pad_maxpool

def gemm_pattern(dtype): # dense + bias_add
    # dense
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    weight = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    out = is_op("nn.dense")(data, weight)
    # bias add
    bias = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    out = out.optional(lambda x: is_op("nn.bias_add")(x, bias) | is_op("add")(x, bias))
    return out

def check_gemm(dtype):
    def _check_gemm(extract):
        def _check_gemm_op(expr):
            attrs, args = expr.attrs, expr.args
            data_type = args[0].checked_type
            weight_type = args[1].checked_type
            if data_type.dtype != dtype:
                return False
            if not isinstance(args[1], relay.expr.Constant):
                return False
            if len(data_type.shape) != 2 or data_type.shape[0] != 1:
                return False
            if weight_type.dtype != dtype:
                return False
            return True

        call = extract
        while call.op.name != "nn.dense":
            call = call.args[0]
        return _check_gemm_op(call)
    return _check_gemm

def matmul_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    weight = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    out = is_op("nn.dense")(data, weight)
    return out

def check_matmul(dtype):
    def _check_matmul(extract):
        def _check_matmul_op(expr):
            import math
            attrs, args = expr.attrs, expr.args
            data_type = args[0].checked_type
            weight_type = args[1].checked_type
            if data_type.dtype != dtype:
                return False
            if not isinstance(args[1], relay.expr.Constant):
                return False
            if weight_type.dtype != dtype:
                return False
            if (len(weight_type.shape) != 2):
                return False
            data_shape = [int(it) for it in data_type.shape]
            weight_shape = [int(it) for it in weight_type.shape]
            # weight of matmul is transposed
            if (data_shape[-1] != weight_shape[-1]):
                return False
            height_total = math.prod(data_shape[:-1])
            if (height_total > 8192):
                return False
            else:
                return True
            return True

        call = extract
        while call.op.name != "nn.dense":
            call = call.args[0]
        return _check_matmul_op(call)
    return _check_matmul

def check_reshape_or_flatten_and_dense(dtype):
    def _check_reshape_or_flatten_and_dense(extract):
        def _check_reshape(expr):
            data_type = expr.args[0].checked_type
            if data_type.shape[0] != 1 or len(data_type.shape) != 4 or data_type.dtype != dtype:
                return False
            newshape = expr.attrs.newshape
            if len(newshape) != 2:
                return False
            if newshape[0] != 1 and list(newshape) != [0, -1]:
                return False
            return True

        def _check_flatten(expr):
            data_type = expr.args[0].checked_type
            if data_type.shape[0] != 1 or len(data_type.shape) != 4 or data_type.dtype != dtype:
                return False
            return True

        def _check_gemm(expr):
            return check_gemm(dtype)(expr)

        call = extract
        while isinstance(call, relay.expr.Call):
            if call.op.name == "reshape":
                if not _check_reshape(call):
                    return False
            elif call.op.name == "nn.batch_flatten":
                if not _check_flatten(call):
                    return False
            elif call.op.name == "nn.dense":
                if not _check_gemm(call):
                    return False
            elif call.op.name == "add" or call.op.name == "nn.bias_add":
                pass
            else:
                return True
            call = call.args[0]
        return True
    return _check_reshape_or_flatten_and_dense


def mera_drp_quant_pattern_table(dtype):
    return [
        # sequence of operators
        ("mera_drp.reshape_or_flatten_and_dense", reshape_or_flatten_and_dense_pattern(dtype), check_reshape_or_flatten_and_dense(dtype)),
        ("mera_drp.reorg", reorg_pattern(dtype), check_reorg(dtype)),
        ("mera_drp.focus", focus_pattern(dtype), check_focus(dtype)),
        ("mera_drp.pad_maxpool", pad_maxpool_pattern(dtype), check_pad_maxpool(dtype)),
        ("mera_drp.gemm", gemm_pattern(dtype), check_gemm(dtype)),
        ("mera_drp.matmul", matmul_pattern(dtype), check_matmul(dtype)),
        # single operator
        ("mera_drp.conv2d", conv_pattern(dtype), check_conv(dtype)),
        ("mera_drp.add", add_pattern(dtype), check_add(dtype)),
        ("mera_drp.max_pool2d", max_pool2d_pattern(dtype), check_max_pool2d(dtype)),
        ("mera_drp.avg_pool2d", avg_pool2d_pattern(dtype), check_avg_pool2d(dtype)),
        ("mera_drp.concatenate", concatenate_pattern(dtype), check_concatenate(dtype)),
        ("mera_drp.resize", resize_pattern(dtype), check_resize(dtype)),
        ("mera_drp.upsampling", upsampling_pattern(dtype), check_upsampling(dtype)),
        ("mera_drp.global_avg_pool2d", global_avg_pool2d_pattern(dtype), check_global_avg_pool2d(dtype)),
        ("mera_drp.adaptive_avg_pool2d", adaptive_avg_pool2d_pattern(dtype), check_adaptive_avg_pool2d(dtype)),
        ("mera_drp.sigmoid", sigmoid_pattern(dtype)),
    ]

@register_pattern_table("mera_drp_quant_ver091_fp32")
def mera_drp_quant_pattern_table_float32():
    return mera_drp_quant_pattern_table('float32')

@register_pattern_table("mera_drp_quant_ver091_fp16")
def mera_drp_quant_pattern_table_float16():
    return mera_drp_quant_pattern_table('float16')
