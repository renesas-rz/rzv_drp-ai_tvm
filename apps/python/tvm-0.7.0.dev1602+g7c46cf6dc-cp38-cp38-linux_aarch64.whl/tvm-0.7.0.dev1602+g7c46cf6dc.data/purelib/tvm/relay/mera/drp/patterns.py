#
# (C) Copyright EdgeCortix, Inc. 2021
#
import tvm

from tvm import relay
from tvm.topi.nn import get_const_int, get_const_tuple
from ...dataflow_pattern import is_constant, is_op, is_tuple, is_tuple_get_item, wildcard
from ...op.strategy.generic import is_depthwise_conv2d
from ...op.contrib.register import register_pattern_table
import numpy as np


def swish_pattern(x):
    sig = is_op("sigmoid")(x)
    return is_op("multiply")(x, sig)


def hardswish_pattern(x):
    y = is_op("divide")(is_op("clip")(is_op("add")(x, is_constant())), is_constant())
    return is_op("multiply")(x, y)


def softplus_pattern(x):
    return is_op("log")(is_op("add")(is_op("exp")(x), is_constant()))


def mish_pattern(x):
    y = is_op("tanh")(softplus_pattern(x))
    return is_op("multiply")(x, y)


def conv_pattern(dtype):
    # TODO: handle padding
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    weight = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    conv = is_op("nn.conv2d")(data, weight)
    # bias add
    bias = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    conv = conv.optional(lambda x: is_op("nn.bias_add")(x, bias))
    # activation
    conv = conv.optional(lambda x: is_op("nn.relu")(x)
                                 | is_op("nn.leaky_relu")(x)
                                 | swish_pattern(x)
                                 | hardswish_pattern(x)
                                 | mish_pattern(x)
                                 | is_op("sigmoid")(x))
    return conv


def check_conv(dtype):
    def _check_conv(extract):
        def _check_minimum_plane_size(kernel_shape_hw, strides, pads, plane_size):
            if kernel_shape_hw == [1,1]:
                return True
            if kernel_shape_hw == [3,3]:
                if strides == [1,1]:
                    if pads == [0,0,0,0] and plane_size[0] >= 3 and plane_size[1] >= 8:
                        return True
                    elif pads in ([0,0,1,1], [1,1,0,0]) and plane_size[0] >= 3 and plane_size[1] >= 7:
                        return True
                    elif pads == [1,1,1,1] and plane_size[0] >= 3 and plane_size[1] >= 6:
                        return True
                elif strides == [2,2]:
                    if pads == [0,0,0,0] and plane_size[0] >= 7 and plane_size[1] >= 5:
                        return True
                    elif pads in ([1,1,0,0], [0,0,1,1], [1,1,1,1]) and plane_size[0] >= 6 and plane_size[1] >= 3:
                        return True
            if kernel_shape_hw == [7,7]:
                if strides == [1,1]:
                    if pads == [3,3,3,3] and plane_size[0] >= 7 and plane_size[1] >= 14:
                        return True
                elif strides == [2,2]:
                    if pads == [3,3,3,3] and plane_size[0] >= 13 and plane_size[1] >= 13:
                        return True
            return False

        def _check_conv_op(expr):
            attrs, args = expr.attrs, expr.args
            if not isinstance(args[1], relay.expr.Constant):
                return False
            strides = list(attrs.strides)
            dilation = list(attrs.dilation)
            pads = list(attrs.padding)
            # check layout and data type
            if attrs.data_layout != "NCHW":
                return False
            if attrs.out_dtype != dtype and attrs.out_dtype != "":
                return False
            data_type = args[0].checked_type
            plane_size = list(get_const_tuple(data_type.shape[2::]))
            if len(data_type.shape) != 4 or data_type.shape[0] != 1 or data_type.dtype != dtype:
                return False
            kernel_type = args[1].checked_type
            if len(kernel_type.shape) != 4 or kernel_type.dtype != dtype:
                return False
            # check kernel shape
            kernel_shape_oc = get_const_int(kernel_type.shape[0])
            kernel_shape_ic = get_const_int(kernel_type.shape[1])
            kernel_shape_hw = list(get_const_tuple(kernel_type.shape[2::]))
            if kernel_shape_hw not in ([1,1], [3,3], [7,7]):
                return False
            if kernel_shape_hw == [7,7]:
                if kernel_shape_ic > 128 or kernel_shape_oc > 64 or kernel_shape_oc % 2 == 1:
                    return False
            # check dilation
            if dilation != [1,1]:
                if dilation[0] != dilation[1]:
                    return False
                if not (pads[1] == pads[0] and pads[2] == pads[0] and pads[3] == pads[0]):
                    return False
                if attrs.groups == 1 and kernel_shape_hw == [3,3]:
                    return True
            # check plane size
            if not _check_minimum_plane_size(kernel_shape_hw, strides, pads, plane_size):
                return False
            # check strides
            if strides not in ([1,1], [2,2]):
                return False
            # check grouped conv
            is_depthwise = is_depthwise_conv2d(
                data_type.shape,
                attrs["data_layout"],
                kernel_type.shape,
                attrs["kernel_layout"],
                attrs["groups"],
            )
            if attrs.groups != 1 and not is_depthwise:
                return False
            return True

        def _check_bias_add(expr):
            if not isinstance(expr.args[1], relay.expr.Constant):
                return False
            return True

        call = extract
        while True:
            if call.op.name == "bias_add":
                if not _check_bias_add(call):
                    return False
            elif call.op.name == "nn.conv2d":
                return _check_conv_op(call)
            call = call.args[0]
    return _check_conv

def batch_norm_pattern(dtype):
    # batch norm
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    gamma = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    beta = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    moving_mean = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    moving_var = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    bn = is_tuple_get_item(is_op("nn.batch_norm")(data, gamma, beta, moving_mean, moving_var), 0)

    scale = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    shift = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    bn_simplified = is_op("add")(is_op("multiply")(data, scale), shift)
    bn = bn | bn_simplified
    # activation
    bn = bn.optional(lambda x: is_op("nn.relu")(x)
                             | is_op("nn.leaky_relu")(x)
                             | swish_pattern(x)
                             | mish_pattern(x)
                             | is_op("sigmoid")(x))
    return bn


def check_batch_norm(expr):
    def _check_data_shape(call):
        data_type = call.args[0].checked_type
        if len(data_type.shape) != 4 or data_type.shape[0] != 1:
            return False
        return True
    def _check_parameter_shape(call):
        shape = call.args[1].checked_type.shape
        if len(shape) != 4 and len(shape) != 3:
            return False
        if len(shape) == 4 and shape[0] != 1:
            return False
        if shape[-2:] != [1,1]:
            return False
        return True

    call = expr
    while True:
        if isinstance(call, relay.TupleGetItem):
            call = call.tuple_value
        if call.op.name == "add":
            return _check_data_shape(call) and _check_parameter_shape(call)
        if call.op.name == "multiply":
            return _check_parameter_shape(call)
        if call.op.name == "nn.batch_norm":
            return _check_data_shape(call)
        call = call.args[0]

def max_pool2d_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    return is_op("nn.max_pool2d")(data)


def check_max_pool2d(dtype):
    def _check_max_pool2d(expr):
        attrs, args = expr.attrs, expr.args
        # check layout and data type
        if attrs.layout != "NCHW":
            return False
        data_type = args[0].checked_type
        if len(data_type.shape) != 4 or data_type.shape[0] != 1 or data_type.dtype != dtype:
            return False
        # check ceil mode
        if attrs.ceil_mode:
            return False
        # check dilation
        if list(attrs.dilation) != [1,1]:
            return False
        # check pool size, strides, padding, and data shape
        pool_size = list(attrs.pool_size)
        strides = list(attrs.strides)
        padding = list(attrs.padding)
        data_c = get_const_int(data_type.shape[1])
        data_h = get_const_int(data_type.shape[2])
        data_w = get_const_int(data_type.shape[3])

        cond1 = pool_size == [2,2] and strides in ([1,1], [2,2]) and padding in ([1,1,1,1], [1,1,0,0], [0,0,1,1]) and 1 <= data_h and 1 <= data_w <= 4096
        cond2 = pool_size == [2,2] and strides in ([1,1], [2,2]) and padding == [0,0,0,0] and 2 <= data_h and 2 <= data_w <= 4096
        cond3 = pool_size == [3,3] and strides in ([1,1], [2,2]) and padding == [1,1,1,1] and 1 <= data_h and 1 <= data_w <= 4096
        cond4 = pool_size == [3,3] and strides in ([1,1], [2,2]) and padding in ([1,1,0,0], [0,0,1,1]) and 2 <= data_h and 2 <= data_w <= 4096
        cond5 = pool_size == [3,3] and strides in ([1,1], [2,2]) and padding == [0,0,0,0] and 3 <= data_h and 3 <= data_w <= 4096
        cond6 = pool_size == [5,5] and strides == [1,1] and padding == [2,2,2,2] and 1 <= data_h and 1 <= data_w <= 4096
        cond7 = pool_size == [5,5] and strides == [1,1] and padding in ([2,0,2,0], [0,2,0,2]) and 3 <= data_h and 3 <= data_w <= 4096
        cond8 = pool_size == [5,5] and strides == [1,1] and padding == [0,0,0,0] and 5 <= data_h and 5 <= data_w <= 4096
        cond9 = pool_size == [9,9] and strides == [1,1] and padding == [4,4,4,4] and 1 <= data_h and 1 <= data_w <= 4096
        cond10 = pool_size == [13,13] and strides == [1,1] and padding == [6,6,6,6] and 1 <= data_h and 1 <= data_w <= 4096

        if not (cond1 or cond2 or cond3 or cond4 or cond5 or cond6 or cond7 or cond8 or cond9 or cond10):
            return False
        return True
    return _check_max_pool2d


def avg_pool2d_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    return is_op("nn.avg_pool2d")(data)


def check_avg_pool2d(dtype):
    def _check_avg_pool2d(expr):
        attrs, args = expr.attrs, expr.args
        # check layout and data type
        if attrs.layout != "NCHW":
            return False
        data_type = args[0].checked_type
        if len(data_type.shape) != 4 or data_type.shape[0] != 1 or data_type.dtype != dtype:
            return False
        # check ceil mode
        if attrs.ceil_mode:
            return False
        # check count_include_pad
        if attrs.count_include_pad:
            return False
        # check dilation
        if list(attrs.dilation) != [1,1]:
            return False
        # check data shape
        data_c = get_const_int(data_type.shape[1])
        data_h = get_const_int(data_type.shape[2])
        data_w = get_const_int(data_type.shape[3])
        # check pool size
        pool_size = list(attrs.pool_size)
        padding = list(attrs.padding)
        if pool_size == [data_h,data_w] and padding == [0,0,0,0] \
            and data_c % 4 == 0 and data_c <= 16384 and data_h <= 65535 \
            and data_w <= 65535:  # GlobalAveragePool equivalent case
            return True
        if data_c > 65535 or data_h > 65535 or data_w > 65535 or data_h % 2 != 0 or data_w % 2 != 0:
            return False
        # check padding
        if padding != [0,0,0,0] and padding != [0,1,0,1]:
            return False
        if pool_size != [2,2]:
            return False
        # check strides
        if list(attrs.strides) != [2,2]:
            return False
        return True
    return _check_avg_pool2d


def global_avg_pool2d_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    return is_op("nn.global_avg_pool2d")(data)


def check_global_avg_pool2d(dtype):
    def _check_global_avg_pool2d(expr):
        attrs, args = expr.attrs, expr.args
        # check layout and data type
        if attrs.layout != "NCHW":
            return False
        data_type = args[0].checked_type
        if len(data_type.shape) != 4 or data_type.shape[0] != 1 or data_type.dtype != dtype:
            return False
        # check data shape
        data_c = get_const_int(data_type.shape[1])
        data_h = get_const_int(data_type.shape[2])
        data_w = get_const_int(data_type.shape[3])
        if data_c % 4 != 0 or data_c > 16384 or data_h > 65535 or data_w > 65535:
            return False
        return True
    return _check_global_avg_pool2d


def dense_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    weight = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    out = is_op("nn.dense")(data, weight)
    # bias add
    bias = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    out = out.optional(lambda x: is_op("add")(x, bias))
    return out


def check_dense(dtype):
    def _check_dense(extract):
        def _check_dense_op(expr):
            attrs, args = expr.attrs, expr.args
            data_type = args[0].checked_type
            weight_type = args[1].checked_type
            if len(data_type.shape) != 2:
                return False
            if data_type.shape[0] != 1:
                return False
            if data_type.dtype != dtype:
                return False
            if weight_type.dtype != dtype:
                return False
            return True

        call = extract
        while call.op.name != "nn.dense":
            call = call.args[0]
        return _check_dense_op(call)
    return _check_dense


def add_pattern(dtype):
    x = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    y = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    add = is_op("add")(x, y)
    # activation
    add = add.optional(lambda x: is_op("nn.relu")(x)
                               | is_op("nn.leaky_relu")(x)
                               | swish_pattern(x)
                               | hardswish_pattern(x)
                               | mish_pattern(x)
                               | is_op("sigmoid")(x))
    return add


def check_add(dtype):
    def _check_add(extract):
        def _check_add_op(expr):
            attrs, args = expr.attrs, expr.args
            if isinstance(args[0], relay.expr.Constant):
                return False
            left_type = args[0].checked_type
            right_type = args[1].checked_type
            if left_type.dtype != dtype:
                return False
            if right_type.dtype != dtype:
                return False
            if isinstance(args[1], relay.expr.Constant):
                if np.array_equal(args[1].data.numpy(), np.array(0).astype(dtype)):
                    return True
                else:
                    return False
            if list(left_type.shape) != list(right_type.shape):
                return False
            return True

        call = extract
        while True:
            if call.op.name == "add":
                return _check_add_op(call)
            call = call.args[0]
    return _check_add

def clip_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    out = is_op("clip")(data)
    return out


def concatenate_pattern():
    data = is_tuple(None)  # tuple with any number of inputs
    out = is_op("concatenate")(data)
    return out


def check_concatenate(expr):
    if expr.attrs.axis != 1:
        return False
    for arg in expr.args[0]:  # concatenate has one argument, which is a tuple
        if isinstance(arg, relay.TupleGetItem):
            arg = arg.tuple_value
        if not isinstance(arg.op, relay.Function):
            return False
        if "Composite" not in arg.op.attrs.keys():
            return False
        if len(arg.checked_type.shape) != 4:
            return False
    return True


def reshape_or_flatten_and_dense_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    # reshape or flatten
    out = is_op("reshape")(data) | is_op("nn.batch_flatten")(data)
    out = is_op("reshape")(out) | is_op("nn.batch_flatten")(out) | out  # resnetv1 has two batch_flatten before dense
    # dense
    weight = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    out = is_op("nn.dense")(out, weight)
    # bias add
    bias = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    out = out.optional(lambda x: is_op("nn.bias_add")(x, bias) | is_op("add")(x, bias))
    return out


def check_reshape_or_flatten_and_dense(dtype):
    def _check_reshape_or_flatten_and_dense(extract):
        def _check_reshape(expr):
            data_type = expr.args[0].checked_type
            if data_type.shape[0] != 1 or data_type.dtype != dtype:
                return False
            newshape = expr.attrs.newshape
            if len(newshape) != 2:
                return False
            if newshape[0] != 1 and list(newshape) != [0, -1]:
                return False
            return True

        def _check_flatten(expr):
            data_type = expr.args[0].checked_type
            if data_type.shape[0] != 1 or data_type.dtype != dtype:
                return False
            return True

        def _check_dense(expr):
            return check_dense(dtype)(expr)

        call = extract
        while isinstance(call, relay.expr.Call):
            if call.op.name == "reshape":
                if not _check_reshape(call):
                    return False
            elif call.op.name == "nn.batch_flatten":
                if not _check_flatten(call):
                    return False
            elif call.op.name == "nn.dense":
                if not _check_dense(call):
                    return False
            elif call.op.name == "add" or call.op.name == "nn.bias_add":
                pass
            else:
                return True
            call = call.args[0]
    return _check_reshape_or_flatten_and_dense


def reshape_and_squeeze_and_dense_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    # reshape and flatten
    out = is_op("reshape")(data)
    out = is_op("squeeze")(out)
    # dense
    weight = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    out = is_op("nn.dense")(out, weight)
    # bias add
    bias = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    out = out.optional(lambda x: is_op("add")(x, bias))
    return out


def check_reshape_and_squeeze_and_dense_pattern(dtype):
    def _check_reshape_and_squeeze_and_dense_pattern(extract):
        def _check_reshape(expr):
            data_type = expr.args[0].checked_type
            if data_type.dtype != dtype:
                return False
            newshape = expr.attrs.newshape
            if len(newshape) != 4:
                return False
            if newshape[0] != 1 and list(newshape) != [0, -1, 1, 1]:
                return False
            return True

        def _check_squeeze(expr):
            data_type = expr.args[0].checked_type
            if data_type.shape[0] != 1 or data_type.dtype != dtype:
                return False
            return True

        def _check_dense(expr):
            return check_dense(dtype)(expr)

        call = extract
        while isinstance(call, relay.expr.Call):
            if call.op.name == "reshape":
                if not _check_reshape(call):
                    return False
            elif call.op.name == "squeeze":
                if not _check_squeeze(call):
                    return False
            elif call.op.name == "nn.dense":
                if not _check_dense(call):
                    return False
            elif call.op.name == "add":
                pass
            else:
                return True
            call = call.args[0]
    return _check_reshape_and_squeeze_and_dense_pattern


def reorg_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    # reshape
    out = is_op("reshape")(data)
    # transpose
    out = is_op("transpose")(out)
    # reshape
    out = is_op("reshape")(out)
    return out


def check_reorg(dtype):
    def _check_reorg(expr):
        reshape2 = expr
        transpose = reshape2.args[0]
        reshape1 = transpose.args[0]

        # check reshape1
        data_type = reshape1.args[0].checked_type
        if data_type.shape[0] != 1 or len(data_type.shape) != 4 or data_type.dtype != dtype:
            return False
        if len(reshape1.attrs.newshape) != 6:
            return False

        # check transpose
        if len(transpose.attrs.axes) != 6:
            return False

        # check reshape2
        if len(reshape2.attrs.newshape) != 4:
            return False
        if reshape2.attrs.newshape[0] != 1:
            return False

        # check input and output size of reorg
        in_c, in_h, in_w = data_type.shape[1:4]
        out_c, out_h, out_w = reshape2.attrs.newshape[1:4]
        if in_c % 4 != 0 or in_h % 2 != 0 or in_w % 2 != 0:
            return False
        if in_h % out_h != 0 or in_w % out_w != 0:
            return False
        if out_c != -1 and out_c % in_c != 0:
            return False

        return True
    return _check_reorg


def space2depth_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    # reshape
    out = is_op("reshape")(data)
    # transpose
    out = is_op("transpose")(out)
    # reshape
    out = is_op("reshape")(out)
    # transpose
    out = is_op("transpose")(out)
    # reshape
    out = is_op("reshape")(out)
    # transpose
    out = is_op("transpose")(out)
    # reshape
    out = is_op("reshape")(out)
    return out


def check_space2depth(dtype):
    def _check_space2depth(expr):
        reshape4 = expr
        transpose3 = reshape4.args[0]
        reshape3 = transpose3.args[0]
        transpose2 = reshape3.args[0]
        reshape2 = transpose2.args[0]
        transpose1 = reshape2.args[0]
        reshape1 = transpose1.args[0]

        # check reshape1
        data_type = reshape1.args[0].checked_type
        if data_type.shape[0] != 1 or len(data_type.shape) != 4 or data_type.dtype != dtype:
            return False
        if len(reshape1.attrs.newshape) != 6:
            return False

        # check transpose1
        if len(transpose1.attrs.axes) != 6:
            return False

        # check reshape2
        if len(reshape2.attrs.newshape) != 4:
            return False
        if reshape2.attrs.newshape[0] != 1:
            return False

        # check transpose2
        if len(transpose2.attrs.axes) != 4:
            return False

        # check reshape3
        if len(reshape3.attrs.newshape) != 5:
            return False
        if reshape3.attrs.newshape[0] != 1:
            return False

        # check transpose3
        if len(transpose3.attrs.axes) != 5:
            return False

        # check reshape4
        if len(reshape4.attrs.newshape) != 4:
            return False
        if reshape4.attrs.newshape[0] != 1:
            return False

        # check input and output size of space2depth
        in_c, in_h, in_w = data_type.shape[1:4]
        out_c, out_h, out_w = reshape4.attrs.newshape[1:4]
        if in_c % 4 != 0 or in_h % 2 != 0 or in_w % 2 != 0:
            return False
        blocksize_h = tvm.tir.indexdiv(in_h, out_h)
        blocksize_w = tvm.tir.indexdiv(in_w, out_w)
        if blocksize_h != 2 or blocksize_w != 2:
            return False

        return True
    return _check_space2depth


def resize_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    out = is_op("image.resize2d")(data)
    return out


def check_resize(dtype):
    def _check_resize(expr):
        attrs, args = expr.attrs, expr.args
        data_type = args[0].checked_type
        if data_type.dtype != dtype:
            return False
        if attrs.method != "nearest_neighbor" and attrs.method != "linear":
            return False
        return True
    return _check_resize


def upsampling_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    out = is_op("nn.upsampling")(data)
    return out


def check_upsampling(dtype):
    def _check_upsampling(expr):
        attrs, args = expr.attrs, expr.args
        data_type = args[0].checked_type
        if data_type.dtype != dtype:
            return False
        if attrs.method != "nearest_neighbor":
            return False
        return True
    return _check_upsampling



def adaptive_avg_pool2d_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    return is_op("nn.adaptive_avg_pool2d")(data)


def check_adaptive_avg_pool2d(dtype):
    def _check_adaptive_avg_pool2d(expr):
        attrs, args = expr.attrs, expr.args
        out_h = get_const_int(attrs.output_size[0])
        out_w = get_const_int(attrs.output_size[1])
        if out_h != 1 or out_w != 1:
            return False
        return check_global_avg_pool2d(dtype)(expr)
    return _check_adaptive_avg_pool2d


def layout_transform_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    return is_op("layout_transform")(data)


def check_layout_transform(expr):
    if not (expr.attrs.src_layout == "NHWC" and expr.attrs.dst_layout == "NCHW"):
        return False

    # only match layout_transform that consumes the network's input
    while True:
        expr = expr.args[0]
        if isinstance(expr, relay.expr.Var):
            return True
        elif isinstance(expr, relay.expr.Call) and expr.op.get_attr("TOpPattern") in [relay.op.OpPattern.ELEMWISE, relay.op.OpPattern.BROADCAST]:
            continue
        else:
            return False

def pad_maxpool_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    pad_value = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    out = is_op("nn.pad")(data, pad_value)
    out = is_op("nn.max_pool2d")(out)
    return out

def check_pad_maxpool(dtype):
    def _check_pad_maxpool(extract):
        def _check_pad_maxpool_op(pad, maxpool):
            maxpool_attrs = maxpool.attrs
            args, attrs = pad.args, pad.attrs
            pad_mode = str(attrs.pad_mode)
            if pad_mode == 'const':
                return False
            data_type = args[0].checked_type
            if data_type.dtype != dtype:
                return False
            if len(data_type.shape) != 4 or [0,0] != list(attrs.pad_width[0]) or [0,0] != list(attrs.pad_width[1]):
                # Didn't support fused padding in NC, yet.
                return False
            [t,b], [l,r] = list(attrs.pad_width[2]), list(attrs.pad_width[3])
            pad_padding = [t,l,b,r]
            maxpool_padding, pool_size = list(maxpool_attrs.padding), list(maxpool_attrs.pool_size)
            padding = [x + y for x, y in zip(maxpool_padding, pad_padding)]
            mp_data_type = maxpool.args[0].checked_type
            pool_size = list(maxpool_attrs.pool_size)
            strides = list(maxpool_attrs.strides)
            data_c = get_const_int(mp_data_type.shape[1])
            data_h = get_const_int(mp_data_type.shape[2])
            data_w = get_const_int(mp_data_type.shape[3])
            cond1 = pool_size == [2,2] and strides in ([1,1], [2,2]) and padding in ([1,1,1,1], [1,1,0,0], [0,0,1,1]) and 1 <= data_h and 1 <= data_w <= 4096
            cond2 = pool_size == [2,2] and strides in ([1,1], [2,2]) and padding == [0,0,0,0] and 2 <= data_h and 2 <= data_w <= 4096
            cond3 = pool_size == [3,3] and strides in ([1,1], [2,2]) and padding == [1,1,1,1] and 1 <= data_h and 1 <= data_w <= 4096
            cond4 = pool_size == [3,3] and strides in ([1,1], [2,2]) and padding in ([1,1,0,0], [0,0,1,1]) and 2 <= data_h and 2 <= data_w <= 4096
            cond5 = pool_size == [3,3] and strides in ([1,1], [2,2]) and padding == [0,0,0,0] and 3 <= data_h and 3 <= data_w <= 4096
            cond6 = pool_size == [5,5] and strides == [1,1] and padding == [2,2,2,2] and 1 <= data_h and 1 <= data_w <= 4096
            cond7 = pool_size == [5,5] and strides == [1,1] and padding in ([2,0,2,0], [0,2,0,2]) and 3 <= data_h and 3 <= data_w <= 4096
            cond8 = pool_size == [5,5] and strides == [1,1] and padding == [0,0,0,0] and 5 <= data_h and 5 <= data_w <= 4096
            cond9 = pool_size == [9,9] and strides == [1,1] and padding == [4,4,4,4] and 1 <= data_h and 1 <= data_w <= 4096
            cond10 = pool_size == [13,13] and strides == [1,1] and padding == [6,6,6,6] and 1 <= data_h and 1 <= data_w <= 4096

            if not (cond1 or cond2 or cond3 or cond4 or cond5 or cond6 or cond7 or cond8 or cond9 or cond10):
                return False
            return True
        call = extract
        while True:
            if call.op.name == "nn.max_pool2d":
                maxpool_op = call
                if not check_max_pool2d(dtype)(call):
                    return False
            elif call.op.name == "nn.pad":
                if _check_pad_maxpool_op(call, maxpool_op):
                    return True
                else:
                    return False
            call = call.args[0]
    return _check_pad_maxpool

def maxmin_pattern(dtype):
    data = is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard()
    max_value = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    min_value = is_op("cast")(is_constant()).has_attr({'dtype': dtype}) | is_constant()
    out = is_op("maximum")(data, max_value)
    out = is_op("minimum")(out, min_value)
    return out

def mera_drp_no_concat_pattern_table(dtype):
    return [
        # sequence of operators
        ("mera_drp.reshape_or_flatten_and_dense", reshape_or_flatten_and_dense_pattern(dtype), check_reshape_or_flatten_and_dense(dtype)),
        ("mera_drp.reshape_and_squeeze_and_dense", reshape_and_squeeze_and_dense_pattern(dtype), check_reshape_and_squeeze_and_dense_pattern(dtype)),
        ("mera_drp.reorg", reorg_pattern(dtype), check_reorg(dtype)),
        ("mera_drp.space2depth", space2depth_pattern(dtype), check_space2depth(dtype)),
        ("mera_drp.mish", mish_pattern(is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard())),
        ("mera_drp.hardswish", hardswish_pattern(is_op("cast")(wildcard()).has_attr({'dtype': dtype}) | wildcard())),
        ("mera_drp.pad_maxpool", pad_maxpool_pattern(dtype), check_pad_maxpool(dtype)),
        ("mera_drp.maxmin", maxmin_pattern(dtype)),
        # single operator
        ("mera_drp.conv2d", conv_pattern(dtype), check_conv(dtype)),
        ("mera_drp.batch_norm", batch_norm_pattern(dtype), check_batch_norm),
        ("mera_drp.max_pool2d", max_pool2d_pattern(dtype), check_max_pool2d(dtype)),
        ("mera_drp.avg_pool2d", avg_pool2d_pattern(dtype), check_avg_pool2d(dtype)),
        ("mera_drp.global_avg_pool2d", global_avg_pool2d_pattern(dtype), check_global_avg_pool2d(dtype)),
        ("mera_drp.adaptive_avg_pool2d", adaptive_avg_pool2d_pattern(dtype), check_adaptive_avg_pool2d(dtype)),
        ("mera_drp.dense", dense_pattern(dtype), check_dense(dtype)),
        ("mera_drp.add", add_pattern(dtype), check_add(dtype)),
        ("mera_drp.clip", clip_pattern(dtype)),
        ("mera_drp.resize", resize_pattern(dtype), check_resize(dtype)),
        ("mera_drp.upsampling", upsampling_pattern(dtype), check_upsampling(dtype)),
        ("mera_drp.layout_transform", layout_transform_pattern(dtype), check_layout_transform),
    ]

@register_pattern_table("mera_drp_fp32_no_concat")
def mera_drp_no_concat_pattern_table_float32():
    return mera_drp_no_concat_pattern_table('float32')

@register_pattern_table("mera_drp_fp16_no_concat")
def mera_drp_no_concat_pattern_table_float16():
    return mera_drp_no_concat_pattern_table('float16')

@register_pattern_table("mera_drp_only_concat")
def mera_drp_only_concat_pattern_table():
    return [
        ("mera_drp.concatenate", concatenate_pattern(), check_concatenate),
    ]
