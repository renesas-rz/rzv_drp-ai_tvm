#
# (C) Copyright EdgeCortix, Inc. 2024
#

import sys
from tvm import relay, runtime
from enum import Enum

class QatType(Enum):
    PyTorch = 1
    TensorFlow = 2

    @staticmethod
    def from_str(label):
        if label.lower() == "pytorch":
            return QatType.PyTorch
        elif label.lower() == "tensorflow":
            return QatType.TensorFlow
        else:
            print("Have not supported qat type:", label)
            raise NotImplementedError

def from_onnx_qat(onnx_model, shape_dict, qat_type, drpai_quant_tool):
    assert type(qat_type) is QatType, "input qat_type is not correct"
    print("  Compile from QAT model")
    print("  QAT type: ", qat_type)
    sys.path.append(drpai_quant_tool)
    if qat_type == QatType.PyTorch:
        from drpai_quantizer.qat.Pytorch.preprocess_pth_qat import pytorch_merge_layer
        onnx_model = pytorch_merge_layer(onnx_model)
    elif qat_type == QatType.TensorFlow:
        from drpai_quantizer.qat.Tensorflow.preprocess_tf_qat import tensorflow_merge_layer
        onnx_model = tensorflow_merge_layer(onnx_model)
    else:
        print("Have not supported qat_type: ", qat_type)
        raise NotImplementedError
    return relay.frontend.from_onnx(onnx_model, shape_dict)


