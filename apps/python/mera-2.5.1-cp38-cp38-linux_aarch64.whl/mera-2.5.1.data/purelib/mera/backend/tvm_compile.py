# Copyright 2024 EdgeCortix Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import json
import os
from pathlib import Path
from .utils import *

def apache_tvm_compile(directory, logger, host_arch="x86"):
    tvm_backend_bins = get_backend_binaries_dict(directory).get("apache_tvm", [])
    for sub_bin in tvm_backend_bins:
        sub_root = Path(sub_bin)
        model_name = sub_root.name
        model_path = sub_root / 'model.tflite'
        if not model_path.exists():
            raise ValueError(f'Could not find {str(model_path)}')
        from ..mera_model import MeraModelTflite
        cpu_model = MeraModelTflite(None, model_name, model_path, False)
        mod, params = cpu_model._load_model_tvm()
        from tvm.relay.mera import build_cpu as __build_cpu
        __build_cpu(sub_root, mod, params, host_arch)
