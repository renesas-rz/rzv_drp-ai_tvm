# Copyright 2025 EdgeCortix Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import json
import os
from pathlib import Path

def check_directory(directory_path):
    if not os.path.isdir(directory_path):
        raise argparse.ArgumentTypeError(f"Error: {directory_path} is not a valid directory")
    return directory_path


def check_plan_json(directory_path):
    plan_json_path = os.path.join(directory_path, 'mera.plan')
    if not os.path.isfile(plan_json_path):
        raise FileNotFoundError(f"Error: 'plan.json' file not found in the directory {directory_path}")

    if not os.access(plan_json_path, os.R_OK):
        raise PermissionError(f"Error: 'plan.json' file does not have read permissions")

    if os.path.getsize(plan_json_path) == 0:
        raise ValueError(f"Error: 'plan.json' file is empty.")

    return plan_json_path


def load_and_parse_json(plan_json_path):
    with open(plan_json_path, 'r') as file:
        data = json.load(file)
    return data


def find_backend_binaries_dict(data, directory_path, add_unit_name = False):
    backend_binaries_dict = {}
    def search(obj):
        if isinstance(obj, dict):
            if "backend" in obj and "binaries_location" in obj:
                absolute_path = os.path.abspath(os.path.join(directory_path, obj["binaries_location"]))
                if obj["backend"] not in backend_binaries_dict:
                    backend_binaries_dict[obj["backend"]] = []
                if add_unit_name:
                    backend_binaries_dict[obj["backend"]].append((absolute_path, obj["name"]))
                else:
                    backend_binaries_dict[obj["backend"]].append(absolute_path)
            for _, value in obj.items():
                search(value)
        elif isinstance(obj, list):
            for item in obj:
                search(item)

    search(data)
    return backend_binaries_dict


def get_backend_binaries_dict(directory_path, add_unit_name = False):
    check_directory(directory_path)
    plan_json_path = check_plan_json(directory_path)
    data = load_and_parse_json(plan_json_path)
    return find_backend_binaries_dict(data, directory_path, add_unit_name=add_unit_name)
