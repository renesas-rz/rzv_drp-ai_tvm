# Copyright 2024 EdgeCortix Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""MERA Utility functions."""

import subprocess
import logging
from pathlib import Path

def cmd(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, raise_if_fail = True):
    logging.debug(f"Running command '{command}'")
    with subprocess.Popen(command, shell=True, stdout=stdout, stderr=stderr, universal_newlines=True, errors='replace') as p:
        for line in p.stdout:
            print(line, end='')
    if p.returncode != 0 and raise_if_fail:
        raise subprocess.CalledProcessError(p.returncode, command)
    return p.returncode

def find_tool(tool_name : str) -> str:
    __here__ = Path(__file__).resolve().parent
    loc = __here__ / 'bin_utils' / tool_name
    loc_exe = __here__ / 'bin_utils' / (tool_name + ".exe")
    if not loc.exists() and not loc_exe.exists():
        raise ValueError(f'ERROR: Could not locate tool {tool_name}')
    if loc.exists:
        return str(loc)
    return str(loc_exe)

def mera2_sanitize(x : str) -> str:
    # TODO - Match MERA2
    return x.replace(':', '_').replace('/', '_').replace('.', '_')
