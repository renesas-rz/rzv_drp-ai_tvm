# Copyright 2025 EdgeCortix Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""MERA Quantizer Configuration classes."""

from enum import Enum

class QType(Enum):
  S8 = "S8"     #: 8-bit signed, ranged [-128, 127]
  U8 = "U8"     #: 8-bit unsigned, ranged [0, 255]
  S7 = "S7"     #: 7-bit signed, ranged [-64, 63]
  U7 = "U7"     #: 7-bit unsigned, ranged [0, 127]
  BF16 = "BF16" #: Unquantized BrainFloat16 type.

class QScheme(Enum):
  SYMMETRIC = "SYMMETRIC" #: Quantization range centered around real value 0.
  AFFINE = "AFFINE"       #: Quantization range adjusted to observed <min,max> from data

class QMode(Enum):
  PER_TENSOR = "PER_TENSOR"               #: Single set of <scale,zero_point> for the whole tensor.
  PER_CHANNEL = "PER_CHANNEL"             #: A different set of <scale,zero_point> for each of the tensor's channels.
  PER_CHANNEL_GROUP = "PER_CHANNEL_GROUP" #: A different set of <scale,zero_point> for each group of several tensor's channels.

class QTarget(Enum):
  WEIGHT = "WEIGHT" #: Tensor are the weights of a quantizable operation.
  DATA = "DATA"     #: Tensor representing the activated data of a quantizable operation.

class ObserverClass(Enum):
  MIN_MAX = "MIN_MAX"     #: Will get the quantization range as <min,max> based on the whole calibration data.
  MAX_ABS = "MAX_ABS"     #: Will get the quantization range as <-max(abs),max(abs)> of the calibration data.
  HISTOGRAM = "HISTOGRAM" #: An optimised <min,max> is calculated based on the distribution of the calibration data using a histogram. Can only be used PER_TENSOR.

class OperatorConfig:
  """Set of quantizer configurations to be applied to an operator."""

  def __init__(self, qtype : QType, qscheme : QScheme, qmode : QMode, qtarget : QTarget, observer : ObserverClass, **kwargs):
    self._qtype = qtype
    self._qscheme = qscheme
    self._qmode = qmode
    self._qtarget = qtarget
    self._observer = observer

    self.histogram_obs_n_bins = int(kwargs.get("histogram_obs_n_bins", 2048))
    self.histogram_obs_upsample_rate = int(kwargs.get("histogram_obs_upsample_rate", 128))
    self.per_channel_limit = int(kwargs.get("per_channel_limit", -1))
    self.per_channel_grp_size = int(kwargs.get("per_channel_grp_size", 32))
    self.use_symmetric_range = bool(kwargs.get("use_symmetric_range", False))

  @property
  def qtype(self) -> QType:
    return self._qtype

  @qtype.setter
  def qtype(self, qtype):
    self._qtype = qtype

  @property
  def qscheme(self) -> QScheme:
    return self._qscheme

  @qscheme.setter
  def qscheme(self, qscheme):
    self._qscheme = qscheme

  @property
  def qmode(self) -> QMode:
    return self._qmode

  @qmode.setter
  def qmode(self, qmode):
    self._qmode = qmode

  @property
  def qtarget(self) -> QTarget:
    return self._qtarget

  @qtarget.setter
  def qtarget(self, qtarget):
    self._qtarget = qtarget

  @property
  def observer(self) -> ObserverClass:
    return self._observer

  @observer.setter
  def observer(self, observer):
    self._observer = observer

  def set_options(self, histogram_n_bins : int = None, histogram_obs_upsample_rate : int = None,
      per_channel_limit : int = None, per_channel_grp_size : int = None, use_symmetric_range : bool = None):
    """Sets advanced quantization options for this operator.

    :param histogram_n_bins: When using histogram observer, overrides default number of bins used.
    :param histogram_upsample_rate: When using histogram observer, overrides default upsample rate for histogram aggregations.
    :param per_channel_limit: Architecture limitation to mark the maximum number of channels of a tensor possible
      where PER_CHANNEL quantization can still be done. Any operation above this limit will switch to use PER_CHANNEL_GROUP instead.
    :param per_channel_grp_size: When using PER_CHANNEL_GROUP, specifies the max size of q_params that will group all the channels in a tensor.
    :param use_symmetric_range: Reduces the range of quantization so that values are set in <-MaxVal,MaxVal>. e.g. [-127,127] for int8 type.
      Only valid for the case of signed quantization.
    """
    if histogram_n_bins is not None:
      self.histogram_obs_n_bins = int(histogram_obs_n_bins)
    if histogram_obs_upsample_rate is not None:
      self.histogram_obs_upsample_rate = histogram_obs_upsample_rate
    if per_channel_limit is not None:
      self.per_channel_limit = per_channel_limit
    if per_channel_grp_size is not None:
      self.per_channel_grp_size = per_channel_grp_size
    if use_symmetric_range is not None:
      self.use_symmetric_range = use_symmetric_range
    return self

  def _to_dict(self):
    return {
      "q_type" : self.qtype.value,
      "scheme" : self.qscheme.value,
      "mode" : self.qmode.value,
      "target" : self.qtarget.value,
      "observer_type" : self.observer.value,
      "histogram_obs_n_bins" : self.histogram_obs_n_bins,
      "histogram_obs_upsample_rate" : self.histogram_obs_upsample_rate,
      "per_channel_limit" : self.per_channel_limit,
      "per_channel_grp_size" : self.per_channel_grp_size,
      "use_symmetric_range" : self.use_symmetric_range
    }


class LayerConfig:
  """Set of quantization configurations to be applied for a Layer in the model"""

  def __init__(self, conv_act : OperatorConfig, conv_weights : OperatorConfig,
      mm_act : OperatorConfig, mm_weights : OperatorConfig):
    self._conv_act = conv_act
    self._conv_weights = conv_weights
    self._mm_act = mm_act
    self._mm_weights = mm_weights

  @property
  def conv_act(self) -> OperatorConfig:
    return self._conv_act

  @property
  def conv_weights(self) -> OperatorConfig:
    return self._conv_weights

  @property
  def mm_act(self) -> OperatorConfig:
    return self._mm_act

  @property
  def mm_weights(self) -> OperatorConfig:
    return self._mm_weights

  def _to_dict(self):
    return {
      "conv_weights_cfg" : self._conv_weights._to_dict(),
      "conv_act_cfg" : self._conv_act._to_dict(),
      "mm_weights_cfg" : self._mm_weights._to_dict(),
      "mm_act_cfg" : self._mm_act._to_dict()
    }

class TransformConfig:
  """Class representing options for transformation of model into quantized MERA model."""

  def __init__(self):
    self._map_silu_to_hswish = True
    self._fuse_domains_for_i8_concat = True
    self._glu_bf16_outlier_threshold = 40.0
    self._enable_i8_transpose = False
    self._use_bf16_for_small_ch_conv = False

  def _to_dict(self):
    return {
      "map_silu_to_hswish" : self.map_silu_to_hswish,
      "fuse_domains_for_i8_concat" : self.fuse_i8_concat_domains,
      "glu_bf16_outlier_threshold" : self.glu_bf16_outlier_threshold,
      "enable_i8_transpose": self.enable_i8_transpose,
      "use_bf16_for_small_ch_conv" : self.use_bf16_for_small_ch_conv,
    }

  @property
  def map_silu_to_hswish(self) -> bool:
    return self._map_silu_to_hswish

  @map_silu_to_hswish.setter
  def map_silu_to_hswish(self, value : bool):
    self._map_silu_to_hswish = bool(value)

  @property
  def fuse_i8_concat_domains(self) -> bool:
    return self._fuse_domains_for_i8_concat

  @fuse_i8_concat_domains.setter
  def fuse_i8_concat_domains(self, value : bool):
    self._fuse_domains_for_i8_concat = bool(value)

  @property
  def use_bf16_for_small_ch_conv(self) -> bool:
    return self._use_bf16_for_small_ch_conv

  @use_bf16_for_small_ch_conv.setter
  def use_bf16_for_small_ch_conv(self, value : bool):
    self._use_bf16_for_small_ch_conv = bool(value)

  @property
  def enable_i8_transpose(self) -> bool:
    return self._enable_i8_transpose

  @enable_i8_transpose.setter
  def enable_i8_transpose(self, value : bool):
    self._enable_i8_transpose = bool(value)

  @property
  def glu_bf16_outlier_threshold(self) -> float:
    return self._glu_bf16_outlier_threshold

  @glu_bf16_outlier_threshold.setter
  def glu_bf16_outlier_threshold(self, threshold : float):
    if float(threshold) < 1.0:
      raise ValueError(f'ERROR setting glu_bf16_outlier_threshold: Value must be >= 1.0')
    self._glu_bf16_outlier_threshold = float(threshold)


class QuantizerConfig:
  """Class representing the configuration of the MERA quantizer."""

  def __init__(self, global_cfg : LayerConfig, flow_version : int = 1):
    self.global_cfg = global_cfg
    self.layer_cfg = {}
    self.flow_version = flow_version
    self._transform_cfg = TransformConfig()
    self.schema = 1

  @property
  def transform_cfg(self) -> TransformConfig:
    return self._transform_cfg

  def to_dict(self):
    return {
      "schema" : self.schema,
      "flow_version" : self.flow_version,
      "layer_conf" : {k:v._to_dict() for k,v in self.layer_cfg.items()},
      "global_cfg" : self.global_cfg._to_dict(),
      "transform_cfg" : self.transform_cfg._to_dict(),
    }


class QuantizerConfigPresets:
  DNA_SAKURA_II = QuantizerConfig(LayerConfig(
    OperatorConfig(QType.U7, QScheme.AFFINE, QMode.PER_TENSOR, QTarget.DATA, ObserverClass.HISTOGRAM), # Conv Act
    OperatorConfig(QType.S8, QScheme.SYMMETRIC, QMode.PER_CHANNEL, QTarget.WEIGHT, ObserverClass.MIN_MAX), # Conv Weights
    OperatorConfig(QType.S8, QScheme.SYMMETRIC, QMode.PER_TENSOR, QTarget.DATA, ObserverClass.MAX_ABS), # MM Act
    OperatorConfig(QType.S8, QScheme.SYMMETRIC, QMode.PER_CHANNEL, QTarget.WEIGHT, ObserverClass.MAX_ABS, per_channel_limit=32704, per_channel_grp_size=32), # MM Weights
  ))
  ALT = QuantizerConfig(LayerConfig(
    OperatorConfig(QType.S8, QScheme.AFFINE, QMode.PER_TENSOR, QTarget.DATA, ObserverClass.MAX_ABS), # Conv Act
    OperatorConfig(QType.S8, QScheme.SYMMETRIC, QMode.PER_CHANNEL, QTarget.WEIGHT, ObserverClass.MIN_MAX, use_symmetric_range=True), # Conv Weights
    OperatorConfig(QType.S8, QScheme.SYMMETRIC, QMode.PER_TENSOR, QTarget.DATA, ObserverClass.MAX_ABS), # MM Act
    OperatorConfig(QType.S8, QScheme.SYMMETRIC, QMode.PER_TENSOR, QTarget.WEIGHT, ObserverClass.MAX_ABS, use_symmetric_range=True), # MM Weights
  ), flow_version = 10)
  MCU = ALT #: Sample base configuration for MCU quantizations.
  DEFAULT = DNA_SAKURA_II #: Sample base configuration for DNA quantizations.

