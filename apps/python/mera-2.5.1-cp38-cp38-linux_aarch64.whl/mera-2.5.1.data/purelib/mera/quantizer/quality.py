# Copyright 2025 EdgeCortix Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Wrapper class for quantizer quality objects"""

class QuantizationQuality:
  """Container class that holds different quality metrics of a quantized tensor."""

  def __init__(self, data, out_names):
    self.__data = data
    self.out_names = out_names
    self.__out_data = [m for m in self.__data if m[0] in self.out_names]

  def __score(self, d):
    try:
      if float(d.max_val) == float(d.min_val):
        # Corner case, the reference data is all the same value, so check for any error
        return 100 if float(d.mean_sq_err)==0.0 else 0
      __range = float(d.max_val) - float(d.min_val)
      return 100 * (1 - (float(d.mean_sq_err)/(__range * __range)))
    except:
      return 'N/A'

  def to_table(self, extra_debug_info : bool = False):
    """Returns a tabulated table representation of the data"""
    from tabulate import tabulate
    import copy
    D = []
    D_out = []
    H = ['Node ID', 'Rewrite Class', 'psnr', 'score', 'mse', 'mean_err', 'max_abs_err', 'min_fp32', 'min_qtz', 'max_fp32', 'max_qtz']
    if extra_debug_info:
        H += ['err_arg_max']
    H_out = copy.deepcopy(H)
    H_out[0] = 'Output ID'
    for m in self.__data:
        node_id,node_class,rw_name,d = m
        E = [node_id, rw_name, d.psnr, self.__score(d), d.mean_sq_err, d.mean_err, d.max_abs_err, d.min_val, d.min_val_qtz, d.max_val, d.max_val_qtz]
        if extra_debug_info:
            E.append(d.err_arg_max)
        D.append(E)
        if node_id in self.out_names:
            D_out.append(E)
    return (tabulate(D, headers=H, tablefmt="fancy_outline", numalign="right", floatfmt=".3f")
      , tabulate(D_out, headers=H_out, tablefmt="fancy_outline", numalign="right", floatfmt=".3f"))

  def __summary_row(self, node_id):
    m = next((x[3] for x in self.__data if x[0] == node_id), None)
    if m is None:
      return {"id" : node_id, "psnr" : 'N/A', "score" : 'N/A', "mse" : 'N/A', "mae" : 'N/A'}
    return {"id" : node_id, "psnr" : m.psnr, "score" : self.__score(m), "mse" : m.mean_sq_err, "mae" : m.max_abs_err}

  def out_summary(self):
    """Returns a metric summary of the outputs of the model."""
    return [self.__summary_row(out_id) for out_id in self.out_names]

  def node_summary(self):
    """Returns a metric summary of the intermediate nodes of the model."""
    return [self.__summary_row(n[0]) for n in self.__data if n[0] not in self.__out_data]
