# Copyright 2022 EdgeCortix Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Mera Quantizer classes"""
import json
import pickle
import mera
import struct
import numpy as np

from argparse import ArgumentError
from typing import Union, List, Tuple, Dict
from pathlib import Path
from .deploy_project import logger, Layout, Target, ArtifactFileType
from .quantization_quality import *
from . import quantizer
from .mera_platform import Platform
from .model.input_desc import InputDescriptionContainer
from tqdm import tqdm
from enum import Enum
from tempfile import TemporaryDirectory
from datetime import datetime

class ModelQuantizerFlow(Enum):
    TORCH = 'torch'
    ONNX = 'onnx'
    TF_LITE = 'tflite'
    MERA_MODEL = 'mera_model'

class QuantizedMeraModelResult:
    """Class that represents the result of a model quantized with the MERA quantizer."""
    __VERSION_PACK = 3

    def __init__(self, input_desc, qtzed_mod, q_params, params, fp32_rtmod, mera_platform, mera_qtz_params):
        self.input_desc = input_desc
        self.qtzed_mod = qtzed_mod
        self.q_params = q_params
        self.params = params
        self.fp32_rtmod = fp32_rtmod
        self.mera_platform = mera_platform
        self.mera_qtz_params = mera_qtz_params
        self.has_mera2 = False

    def save(self, file_name : Union[str, Path]) -> None:
        f_path = Path(file_name).resolve()
        logger.debug(f"Saving quantized MERA model to '{f_path}' ...")
        from tvm.ir import save_json as __tvm_save_json
        ser_tvm_ir = __tvm_save_json(self.qtzed_mod)
        ser_params = {k: v.numpy() for k,v in self.params.items()}
        pickle_data = {
            "version" : QuantizedMeraModelResult.__VERSION_PACK,
            "data" : (self.input_desc, ser_tvm_ir, self.q_params, ser_params, self.mera_platform, self.mera_qtz_params)
        }
        with open(f_path, "wb") as f:
            pickle.dump(pickle_data, f)

    def save_qtz_parameters(self, file_name : Union[str, Path]) -> None:
        f_path = Path(file_name).resolve()
        logger.debug(f"Saving MERA quantization parameters to '{f_path}' ...")
        with open(f_path, "w") as f:
            f.write(json.dumps(self.q_params))

    def load(file_name : Union[str, Path]):
        f_path = Path(file_name).resolve()
        if not f_path.is_file():
            raise ValueError(f"Could not open MERA quantized model '{f_path}'. File not found.")
        try:
            with open(f_path, "rb") as f:
                pkl_data = pickle.load(f)
                def __extract_version_from_file(pkl_data):
                    # V1 does not contain an explicit field for version
                    return 1 if (not isinstance(pkl_data, dict)) else int(pkl_data["version"])
                __mera_ver = __extract_version_from_file(pkl_data)

                if __mera_ver >= 4:
                    # Compatibility break, load for MERA2
                    input_desc, q_params, mera_platform = pkl_data["metadata"]
                    return QuantizedMera2ModelResultPack(input_desc, q_params, mera_platform,
                        pkl_data["units"], pkl_data["plan"], pkl_data["params"])
                # Backwards compatible unpacking.
                if __mera_ver == 1: # (input_desc, ser_tvm_ir, q_params, ser_params, flow)
                    input_desc, ser_tvm_ir, q_params, ser_params = pkl_data[:4]
                    mera_platform = Platform.SAKURA_1
                    mera_qtz_params = {}
                elif __mera_ver == 2: # (input_desc, ser_tvm_ir, q_params, ser_params)
                    input_desc, ser_tvm_ir, q_params, ser_params = pkl_data["data"][:4]
                    mera_platform = Platform.SAKURA_1
                    mera_qtz_params = {}
                elif __mera_ver == 3: # (input_desc, ser_tvm_ir, q_params, ser_params, mera_platform)
                    input_desc, ser_tvm_ir, q_params, ser_params, mera_platform, mera_qtz_params = pkl_data["data"]
                else:
                    raise ValueError(f"Cannot load .mera models saved with a higher file version: {__mera_ver}.\n"
                        + "Please upgrade your version of MERA")
            from tvm.ir import load_json as __tvm_load_json
            tvm_ir = __tvm_load_json(ser_tvm_ir)
            return QuantizedMeraModelResult(input_desc, tvm_ir, q_params, ser_params, None, mera_platform, mera_qtz_params)
        except Exception as ex:
            raise ValueError(f"Found error while loading MERA quantized model '{f_path}': {ex}")

    def measure_quantization_quality(self, dataset : Union[List[np.ndarray], List[List[np.ndarray]], List[Dict[str, np.ndarray]]],
            debug_mode : bool = False) -> MeraQualityContainer:
        def __mera2_parse_node_list(data):
            for sub_g,nodes in data.items():
                # Entry tuple of (node_id, node_type)
                data[sub_g] = [n[0] for n in nodes]
            return data
        if self.fp32_rtmod is None:
            raise ValueError(f'No fp32 reference model is available')
        use_mera2 = self.has_mera2
        if not use_mera2:
            node_list = list(self.fp32_rtmod._get_interpreter_node_list())
        else:
            node_list = __mera2_parse_node_list(self.fp32_rtmod.runner._GetInterpreterNodeList())
        node_data = {}

        _dataset = dataset if isinstance(dataset, list) else [dataset]
        qtz_out = []
        ref_out = []
        with TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            # Save model to temp dir
            model_path = tmpdir / "model.mera"
            self.save(model_path)
            # Deploy model
            with mera.Deployer(tmpdir / "_out") as deployer:
                model = mera.ModelLoader(deployer).from_quantized_mera(model_path, use_legacy=(not use_mera2))
                deploy = deployer.deploy(model, target=Target.InterpreterHw, mera_platform=self.mera_platform)
                runner = deploy.get_runner()
            if debug_mode:
                if not use_mera2:
                    qtzed_node_list = runner.rt_mod._get_interpreter_node_list()
                else:
                    qtzed_node_list = __mera2_parse_node_list(runner.runner._GetInterpreterNodeList())
            num_inputs = model.input_desc.num_inputs
            for inp in tqdm(_dataset, ncols=100, colour='yellow', desc='Evaluating quality', unit=' samples'):
                if use_mera2:
                    if num_inputs > 1 and not isinstance(inp, dict):
                        raise ValueError(f'Only dict format allowed for evaluation samples with multiple inputs')
                    if num_inputs > 1:
                        __unneeded_inputs = set(inp.keys()) - set(runner.get_input_names())
                        if len(__unneeded_inputs) > 0:
                            logger.warn(f"Ignoring calibration data for input(s) {list(__unneeded_inputs)} because they do not exist in the model.")
                            [inp.pop(x) for x in __unneeded_inputs]
                    qtz_out.append(tuple(runner.set_input(inp).run().get_outputs()))
                    self.fp32_rtmod.set_input(inp).run()
                    ref_out.append(tuple([self.fp32_rtmod.get_output(i) for i in range(self.fp32_rtmod.get_num_outputs())]))
                else:
                    if isinstance(inp, tuple):
                        inp = list(inp)
                    elif not isinstance(inp, list):
                        inp = [inp]
                    assert len(inp) == num_inputs, f"Input evaluation set must be a list of {num_inputs} elements (num inputs)."
                    qtz_out.append(tuple(runner.set_input(inp).run().get_outputs()))
                    [self.fp32_rtmod.set_input(i, inp[i]) for i in range(num_inputs)]
                    # TODO - Use MERA interface
                    self.fp32_rtmod.run()
                    ref_out.append(tuple([self.fp32_rtmod.get_output(i).asnumpy() for i in range(self.fp32_rtmod.get_num_outputs())]))
                if debug_mode:
                    if use_mera2:
                        for sub_name,op_list in node_list.items():
                            if sub_name not in qtzed_node_list:
                                continue
                            for op in op_list:
                                if op not in qtzed_node_list[sub_name]:
                                    continue
                                if op not in node_data:
                                    node_data[op] = {}
                                    node_data[op]["ref"] = []
                                    node_data[op]["got"] = []
                                def __assemble_buffer(data):
                                    __parse_map = { 'Float32' : np.float32, 'Int8' : np.int8, 'UInt8' : np.uint8, 'Int32' : np.int32 }
                                    if data[2] not in __parse_map:
                                        raise ValueError(f'Could not find data type {data[2]} in map.')
                                    np_type = __parse_map[data[2]]
                                    return np.frombuffer(bytearray(data[1]), dtype=np_type).reshape(tuple(data[0]))
                                node_data[op]["ref"].append(__assemble_buffer(self.fp32_rtmod.runner._GetInterpreterBuffer(str(op))))
                                node_data[op]["got"].append(__assemble_buffer(runner.runner._GetInterpreterBuffer(str(op))))
                    else:
                        for op in node_list:
                            if op not in qtzed_node_list:
                                continue
                            if op not in node_data:
                                node_data[op] = {}
                                node_data[op]["ref"] = []
                                node_data[op]["got"] = []
                            node_data[op]["ref"].append(self.fp32_rtmod._get_interpreter_buffer(op))
                            node_data[op]["got"].append(runner.rt_mod._get_interpreter_buffer(op))
        out_qlty = calculate_quantization_quality(ref_out, qtz_out)
        if debug_mode:
            return MeraDebugQualityContainer(out_qlty, node_data, self.q_params)
        else:
            return MeraQualityContainer(out_qlty)

class QuantizedMera2ModelResult(QuantizedMeraModelResult):
    def __init__(self, prj_loc, input_desc, q_params, fp32_rtmod, mera_platform, mera_qtz_params):
        self.prj_loc = prj_loc
        self.input_desc = input_desc
        self.q_params = q_params
        self.fp32_rtmod = fp32_rtmod
        self.mera_platform = mera_platform
        self.mera_qtz_params = mera_qtz_params
        self.has_mera2 = True

    def _get_files_from_backend(self, backend):
        __BACKEND_MAP = {
            'mera_dna' : 'model.dnair',
            'apache_tvm' : 'model.tflite',
            'mera_block' : 'model.mera_block'
        }
        if backend not in __BACKEND_MAP:
            raise ValueError(f'Unhandled plan backend {backend}')
        return __BACKEND_MAP[backend]

    def save(self, file_name : Union[str, Path]) -> None:
        f_path = Path(file_name).resolve()
        logger.debug(f"Saving quantized MERA model to '{f_path}' ...")
        __VERSION_PACK = 4
        pickle_data = {
            "version" : __VERSION_PACK,
            "metadata" : (self.input_desc, self.q_params, self.mera_platform),
            "params" : self.mera_qtz_params,
            "units" : []
        }
        # Save the plan and all module inputs
        plan_loc = self.prj_loc.get_artifact('Quantizer', 'mera.plan')
        compile_loc = plan_loc.parent.resolve()
        with open(plan_loc, 'r') as r:
            plan_data_str = r.read()
            pickle_data["plan"] = plan_data_str
            plan_data = json.loads(plan_data_str)
        __all_units = []
        for stages in plan_data["execution"]["stages"]:
            for stage in stages:
                for groups in stage:
                    __all_units.append(groups[0])
        for unit in __all_units:
            binary_loc = compile_loc / unit["binaries_location"]
            def __fetch(file_name):
                    return r.read()
            file_name = self._get_files_from_backend(unit["backend"])
            with open(binary_loc / file_name, 'rb') as r:
                __unit_data = r.read()
            pickle_data["units"].append({
                "unit" : unit,
                "data" : __unit_data
            })
        with open(f_path, "wb") as f:
            pickle.dump(pickle_data, f)

class QuantizedMera2ModelResultPack(QuantizedMera2ModelResult):
    def __init__(self, input_desc, q_params, mera_platform, unit_list, plan_str, mera_qtz_params):
        super().__init__(None, input_desc, q_params, None, mera_platform, mera_qtz_params)
        self.unit_list = unit_list
        self.plan_str = plan_str

    def to_deploy_dir(self, prj):
        # Recreate folder structure
        deploy_path = Path(prj.get_cwd()) / 'compilation'
        deploy_path.mkdir(parents=True, exist_ok=True)
        with open(deploy_path / 'mera.plan', 'w') as w:
            w.write(self.plan_str)
        constant_data_path = Path(prj.get_cwd()) / 'param_data'
        constant_data_path.mkdir(parents=True, exist_ok=True)
        for ct_name,ct_data in self.mera_qtz_params.items():
            with open(constant_data_path / f'{ct_name}.bin', 'wb') as w:
                w.write(ct_data)
        for unit in self.unit_list:
            unit_info = unit["unit"]
            unit_dir = deploy_path / unit_info["binaries_location"]
            unit_dir.mkdir(parents=True, exist_ok=True)
            bin_name = self._get_files_from_backend(unit_info["backend"])
            with open(unit_dir / bin_name, 'wb') as w:
                w.write(unit["data"])

class ModelQuantizer:
    """Class to perform quantization of a model targeting MERA stack."""

    def __init__(self, model : Union[str, Path, mera.MeraModel],
            input_shape : Union[Tuple, List[Tuple]],
            layout : Layout = Layout.NHWC,
            shape_mapping : Dict[str, int] = {},
            mera_platform : Platform = Platform.SAKURA_2C,
            input_types : List = None,
            quantization_directory : Path = None,
            **model_load_kwargs):
        """Loads a model in which MERA can perform quantization for heterogeneous ML frameworks.

        :param model: Model to include. This can be set in many formats depending on the input framework:
          * PyTorch: Accepts a torchscript traced module, a path to a serialised traced torchscript module (*.pt extension) or a torch module.
          * ONNX: Accepts a path to a serialized ONNX model (*.onnx extension) whose op-set is one of the following: [10].
          * TFLite: Accepts a path to a serialized tensorflow lite model (*.tflite extension).
        :param input_shape: Specify a tuple with the shape of the input, or a list of tuples in case the model has multiple inputs.
        :param layout: Specify the 4D tensor layout of the model.
        :param shape_mapping: Override symbolic shape mappings (only ONNX).
        :param mera_platform: Sets the current platform target for quantization.
        :param input_types: List numpy types that allows overriding default assign of float32 for the inputs.
        :param quantization_directory: Optional directory where quantization artifacts will be dumped.
        :param model_load_kwargs: Any extra arguments to pass through to the ModelLoader.
        """
        import torch
        from torch.nn.modules.module import Module as TorchModule
        from torch.jit import ScriptModule as TorchScriptModule

        # Model Validation
        if isinstance(input_shape, tuple):
            input_shape = [input_shape]
        self.model, self.flow = ModelQuantizer.__model_load(model, input_shape, shape_mapping)

        self.layout = Layout(layout)
        self.calibrated = False
        self.transformed = False
        self.mera_platform = mera_platform

        if not input_shape:
            raise ArgumentError(f'input_shape argument needs to be provided.')
        self.input_shape = input_shape if isinstance(input_shape, list) else [input_shape]
        if not np.all([isinstance(x, tuple) for x in self.input_shape]):
            raise ArgumentError(f'All provided input shapes must be tuples')

        # Prepare quantizer mod
        logger.info(f'Loading and converting {str(self.flow.value)} model to MERA model...')
        # TODO - Once we fully migrated this class will be rewriten entiretly.
        self.use_mera2 = False
        if self.flow == ModelQuantizerFlow.TORCH or self.flow == ModelQuantizerFlow.ONNX:
            self.input_type = input_types
            if not self.input_type:
                self.input_type = ['float32'] * len(self.input_shape)
            if len(self.input_type) != len(self.input_shape):
                raise ArgumentError(f'input_types argument length does not match expected length ({len(self.input_shape)})')

            if self.flow == ModelQuantizerFlow.ONNX:
                input_names = [in_def.name for in_def in self.model.graph.input]
            else:
                input_names = [f'input_{idx}' for idx in range(len(self.input_shape))]

            self.input_desc = [(in_name, (tuple(shp), in_type)) for in_name,shp,in_type in zip(input_names, self.input_shape, self.input_type)]
            import os
            __use_legacy_deploy = os.getenv('MERA_USE_LEGACY_DEPLOYER', None)
            if self.flow == ModelQuantizerFlow.TORCH:
                from tvm.relay.frontend import from_pytorch as __tvm_from_pytorch
                mod, params = __tvm_from_pytorch(self.model, self.input_desc, layout=self.layout.value)
            elif self.flow == ModelQuantizerFlow.ONNX and self.mera_platform == Platform.SAKURA_2C and not __use_legacy_deploy:
                # Activate MERA2 quantizer deployment
                self.use_mera2 = True
            else:
                from tvm.relay.frontend import from_onnx as __tvm_from_onnx
                mod, params = __tvm_from_onnx(self.model)
        elif self.flow == ModelQuantizerFlow.TF_LITE:
            from tvm.relay.frontend import from_tflite as __tvm_from_tflite
            self.input_desc = {f'input_{idx}' : shp for idx,shp in enumerate(self.input_shape)}
            self.input_type = [np.float32] * len(self.input_shape)
            dtype_dict = {f'input_{x}' : 'float32' for x in range(len(self.input_shape))}
            mod, params = __tvm_from_tflite(self.model, shape_dict=self.input_desc, dtype_dict=dtype_dict)
        elif self.flow == ModelQuantizerFlow.MERA_MODEL:
            self.input_desc = self.model.input_desc
            self.input_shape = [inp.input_shape for inp in self.input_desc.all_inputs.values()]
            self.input_type = [desc.input_type for desc in self.input_desc.all_inputs.values()]
            mod, params = self.model._load_model_tvm()
        else:
            raise ValueError(f'Unsupported quantization flow {self.flow}')

        if self.use_mera2:
            if quantization_directory:
                tmp_dir = Path(quantization_directory).resolve()
            else:
                self.mera2_tmp_dir = TemporaryDirectory()
                tmp_dir = Path(self.mera2_tmp_dir.name).resolve()
            with mera.Deployer(tmp_dir, overwrite=True) as deployer:
                self.mera2_qtzer_prj = deployer.prj
                model = mera.ModelLoader(deployer).from_onnx(model, shape_mapping=shape_mapping, **model_load_kwargs)
                deployment = deployer.deploy(model, mera_platform=self.mera_platform, target=Target.Quantizer)
            self.qtzer_mod = deployment.get_runner()
            return
        from tvm.relay.mera import build_fp32 as __build_fp32
        from tvm.relay.mera import build_config as __build_config
        with __build_config(target='Quantizer', arch=str(mera_platform)):
            json, lib, params, mod = __build_fp32(mod, params, 'Quantizer', "x86")
        self.mod = mod
        self.params = params

        from tvm.runtime import cpu as __cpu
        from tvm.runtime import save_param_dict as __save_param_dict
        from tvm.contrib.graph_executor import create as __create
        self.qtzer_mod = __create(json, lib, __cpu())
        param_bytes = __save_param_dict(params)
        self.qtzer_mod.load_params(param_bytes)
        logger.info(f'Model ready for quantization')

    def __model_load(mod_input, in_shape, shape_mapping):
        if isinstance(mod_input, mera.MeraModel):
            return mod_input, ModelQuantizerFlow.MERA_MODEL
        elif isinstance(mod_input, torch.jit.ScriptModule):
            return mod_input, ModelQuantizerFlow.TORCH
        elif isinstance(mod_input, str) or isinstance(mod_input, Path):
            # Treat it as a path
            model_path = Path(str(mod_input))

            if model_path.suffix == '.pt':
                if not model_path.exists():
                    raise ArgumentError(f'Could not find PyTorch traced model file {model_path}')
                with torch.no_grad():
                    return torch.jit.load(str(model_path)), ModelQuantizerFlow.TORCH
            elif model_path.suffix == '.onnx':
                if not model_path.exists():
                    raise ArgumentError(f'Could not find ONNX model file {model_path}')
                from .mera_model import MeraModelOnnx
                return MeraModelOnnx._resolve_model(model_path, 1, shape_mapping, load_external_data=False), ModelQuantizerFlow.ONNX
            elif model_path.suffix == '.tflite':
                if not model_path.exists():
                    raise ArgumentError(f'Could not find TFLite model file {model_path}')
                from tflite import Model as __tfliteModel
                return __tfliteModel.GetRootAsModel(model_path.read_bytes(), 0), ModelQuantizerFlow.TF_LITE
            else:
                raise ArgumentError(f"Unknown or unsupported model file {model_path.suffix}.\n"\
                 + "Currently only PyTorch, ONNX or TFLite models supported for quantization")
        elif isinstance(mod_input, TorchModule):
            # Generate a script module out of it
            assert len(in_shape) == 1, "Automatic tracing with multiple inputs not implemented"
            with torch.no_grad():
                return torch.jit.trace(mod_input, torch.randn(*in_shape[0], dtype=torch.float32)).eval(), ModelQuantizerFlow.TORCH

    def __parse_q_params(self):
        if self.use_mera2:
            q_params_all = self.qtzer_mod.runner._CalculateQParams()
            all_params = {}
            for unit_name,q_params_container in q_params_all.items():
                q_params = json.loads(q_params_container)
                all_params = {**all_params, **q_params}
            return all_params
        q_params_str = self.qtzer_mod["mera_calculate_qparams"]()
        q_params = json.loads(q_params_str)
        all_params = {}
        for q_param in q_params:
            all_params = {**all_params, **q_param}
        return all_params

    def apply_smoothquant(self, alpha : float = 0.5, autotune : bool = True):
        """Applies the SmoothQuant algorithm for transformer models after running some calibration inputs.
        The result is an fp32 identical model with smoothing vectors applied based on the algorithm rules.
        After applying SQ, the calibration will be reset, so another set of calibration samples should be fed to the model.

        :param alpha: Static alpha value to apply to every layer in the model. Must be a value between 0 and 1
        :param autotune: Whether MERA should choose the optimal alpha for each operator that minimises quantization error.
        Overrides value provided for alpha.
        """
        if alpha < 0 or alpha > 1:
            raise ValueError(f'SmoothQuant alpha parameter must be between [0.0, 1.0], not {alpha}')
        param_val = str(alpha)
        if autotune:
            param_val = str('auto')
        if self.use_mera2:
            self.qtzer_mod.runner._RunSmoothQuant(bool(autotune), float(alpha))
        else:
            self.qtzer_mod['mera_quantizer_run_smoothquant'](param_val)

    def calibrate(self, calibration_inputs : Union[List[np.ndarray], List[List[np.ndarray]], List[Dict[str, np.ndarray]]]):
        """Feeds a series of realistic input data tensors which will calibrate the model for better quantization quality.
        MERA will observe the data ranges on all nodes across the whole model and will use that information to determine what
        are the best quantization domains based on the representative dataset and the user configuration. It is recommended to use
        a big enough dataset of realistic input data in order to obtain the best accuracy results for quantization.

        :param calibration_inputs: List of NumPy tensors with a representative dataset of real data. The length of this list will
        determine how many calibration iterations are performed. If the model contains more than one input, a list of lists is
        expected as input in the format of C[NC][NI], where NC is the number of calibration samples and NI is the number of inputs.
        For models with multiple inputs it also accepts a list of dictionaries, where each sample is a dict of input_name:data pairing.
        """
        c_ins = list(calibration_inputs)
        n_runs = int(len(c_ins))
        if n_runs == 0:
            raise ArgumentError(f'At least 1 calibration sample needs to be provided')

        self.reset_calibration()
        logger.info(f'Running model quantization with {n_runs} samples ...')
        for it in tqdm(range(n_runs), ncols=100, colour='yellow', desc='Running calibration', unit=' samples',
                bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining},{rate_noinv_fmt}{postfix}]'):
            in_data = c_ins[it]
            if self.use_mera2:
                __in_len = len(self.qtzer_mod.get_input_names())
                if (isinstance(in_data, list) or isinstance(in_data, tuple)) and __in_len > 1:
                    # TODO - Demote to warning
                    raise ValueError(f'Providing calibration data for multiple inputs as a list is no longer supported.\n'
                     + f'Please provide each of the calibration inputs as a dictionary with keys {self.qtzer_mod.get_input_names()} instead.')
                elif isinstance(in_data, dict):
                    __unset_inputs = set(self.qtzer_mod.get_input_names()) - set(in_data.keys())
                    if len(__unset_inputs) > 0:
                        raise ValueError(f'Missing calibration data for input(s) {list(__unset_inputs)} on sample #{it}\n'
                            + f'Currently providing data for {list(in_data.keys())} instead.')
                    __unneeded_inputs = set(in_data.keys()) - set(self.qtzer_mod.get_input_names())
                    if len(__unneeded_inputs) > 0:
                        logger.warn(f"Ignoring calibration data for input(s) {list(__unneeded_inputs)} because they do not exist in the model.")
                        [in_data.pop(x) for x in __unneeded_inputs]
                elif __in_len != 1:
                    raise ValueError(f'Incorrect number of inputs fed for calibration for sample #{it}: '
                        + f'Expected {len(self.qtzer_mod.get_input_names())} inputs but got a single value instead')
                self.qtzer_mod.set_input(in_data)
            else:
                if isinstance(in_data, tuple):
                    calib_type = [x.dtype for x in in_data]
                else:
                    if not isinstance(in_data, list):
                        in_data = [in_data]
                    calib_type = [x.dtype for x in in_data]
                if self.input_type != calib_type:
                    raise ValueError(f'Incorrect data type found for image #{it}: '
                    + f'Expected {self.input_type} but got {calib_type}')
                [self.qtzer_mod.set_input(i, d) for i,d in enumerate(in_data)]
            self.qtzer_mod.run()
        self.calibrated = True
        return self

    def reset_calibration(self):
        if self.use_mera2:
            self.qtzer_mod.runner._QuantizerReset()
        else:
            self.qtzer_mod["mera_quantizer_reset"]()
        self.calibrated = False
        return self

    def quantize(self) -> QuantizedMeraModelResult:
        if not self.calibrated:
            logger.warning(f'No calibration results are available for this model. Will use default Quantization params.\n'
            + 'Please use calibrate() method to compute quantization domains.')
        if self.use_mera2:
            plan_loc = self.mera2_qtzer_prj.get_artifact('Quantizer', 'mera.plan')
            qtzed_mod = self.qtzer_mod.runner._QuantizeTransform()
            qtzed_params_raw = self.qtzer_mod.runner._ExportQuantizedParams()
            def __parse_qtz_params(raw_data):
                parsed = {}
                offset = 0
                while offset < len(raw_data):
                    id_len = struct.unpack_from('<L', raw_data, offset=offset)[0]
                    offset += 4
                    name = struct.unpack_from(f'{id_len}s', raw_data, offset=offset)[0].decode("utf-8")
                    offset += id_len
                    data_len = struct.unpack_from('<Q', raw_data, offset=offset)[0]
                    offset += 8
                    data = struct.unpack_from(f'{data_len}s', raw_data, offset=offset)[0]
                    offset += data_len
                    parsed[name] = data
                return parsed
            qtzed_params = {}
            for unit_name,params_raw in qtzed_params_raw.items():
                qtzed_params = {**qtzed_params, **__parse_qtz_params(bytearray(params_raw))}
            compilation_dir = plan_loc.parent
            for unit_name,qtz_ir in qtzed_mod.items():
                with open(compilation_dir / f'{unit_name}__DNA_MERA' / 'model.dnair', 'wb') as w:
                    w.write(bytearray(qtz_ir))
            return QuantizedMera2ModelResult(self.mera2_qtzer_prj, self.input_desc, self.__parse_q_params(),
                self.qtzer_mod, self.mera_platform, qtzed_params)
        from tvm.relay.mera import qtz_transform as __mera_qtz_transform
        qtzed_mod, new_tvm_params = __mera_qtz_transform(self.mod, self.qtzer_mod)
        new_params = {**new_tvm_params, **self.params}
        from tvm.relay.mera import export_qtz_params as __mera_export_qtz_params
        mera_qtz_params = __mera_export_qtz_params(self.qtzer_mod)
        return QuantizedMeraModelResult(self.input_desc, qtzed_mod, self.__parse_q_params(), new_params,
            self.qtzer_mod, self.mera_platform, mera_qtz_params)

class Quantizer:
    """Class with API to quantize models using MERA"""
    __PRJ_SECTION_NAME = 'quantizer'

    def __init__(self, deployer, model,
            quantizer_config : quantizer.QuantizerConfig = quantizer.QuantizerConfigPresets.DEFAULT,
            mera_platform : Platform = Platform.SAKURA_2C, **kwargs):
        """Creates a class for creating MERA quantized models.

        :param deployer: Instance of deployment project created with mera.Deployer.
        :param model: Model to be quantized loaded with mera.ModelLoader.
        :param quantizer_config: Instance of quantizer configuration with user defined options.
        :param mera_platform: Platform to be used for quantizer deployment.
        """
        self.deployer = deployer
        self.prj = deployer.prj
        self.model = model
        if not isinstance(quantizer_config, quantizer.QuantizerConfig):
            raise ValueError(f'Provided quantizer config is not of type quantizer.QuantizerConfig')
        self.quantizer_config = quantizer_config
        self.mera_platform = mera_platform
        self.transformed = False
        if self.mera_platform == Platform.ALT2:
            self.quantizer_config.flow_version = 11

        try:
            # Use cached deployment for quantizer
            self.fp32_mir_file = self.prj.get_artifact(Quantizer.__PRJ_SECTION_NAME, 'model.mir')
            logger.info(f"Using existing prepared model for quantization.")
        except:
            # Deploy for MERA Interpreter target and get the MIR file for quantizer
            self.fp32_mir_file = self.deployer.deploy(self.model, mera_platform=self.mera_platform,
                target=Target.MERAInterpreter, __orig_mera_qtz=True).model_loc
            self.prj.add_artifact([(Quantizer.__PRJ_SECTION_NAME, self.fp32_mir_file)])

        self.qtzer_cfg_path = self.prj.save_artifact('qtz_conf.json', ArtifactFileType.JSON,
            Quantizer.__PRJ_SECTION_NAME, self.quantizer_config.to_dict())

        from .mera2libs import quantizer as m2_quantizer
        m2_quantizer.RegisterLogger()

        self.qtzer_impl = m2_quantizer.CreateQuantizer(str(self.fp32_mir_file), str(self.qtzer_cfg_path))
        self.qlty_list = []
        self._calibration_count = 0
        self._eval_count = 0
        self.transform_report = None
        in_info = self.qtzer_impl.GetInputInfo()
        self.in_info = {n.id : n for n in in_info}
        out_info = self.qtzer_impl.GetOutputInfo()
        self.out_info = {n.id : n for n in out_info}
        logger.info("Model ready for quantization")

    def __format_sq_table(self, sq_data):
        from tabulate import tabulate
        D = []
        H = ['LayerNorm ID', 'Applied', 'alpha']
        for node_id,d in sq_data.items():
            D.append([node_id, d.applied, np.round(d.chosen_alpha, 2) if bool(d.applied) else "N/A"])
        print(tabulate(D, headers=H, tablefmt="fancy_outline", numalign="right", floatfmt=".2f"))

    def __human_fmt(self, x, units, scale=1000):
        for unit in units:
            if x < scale:
                return f"{x:3.1f}{unit}"
            x /= scale
        raise ValueError(f'Number too large')

    def __human_fmt_size(self, x):
        return self.__human_fmt(x, ['B', 'KB', 'MB', 'GB', 'TB', 'EB'])

    def __human_fmt_count(self, x):
        return self.__human_fmt(x, ['', 'K', 'Mil', 'Bil', 'Tril'])

    def __format_qtz_transform_report(self, qt_data):
        __row_parsed = {}
        __all_types = set([t_row.data_type for t_row in qt_data.transform_data])
        for t_row in qt_data.transform_data:
            if t_row.node_class not in __row_parsed:
                __row_parsed[t_row.node_class] = {n:[0,0] for n in __all_types}
            __row_parsed[t_row.node_class][t_row.data_type][0] += 1
            __row_parsed[t_row.node_class][t_row.data_type][1] += t_row.param_bytes
        from tabulate import tabulate
        print(f'Model param post-quantization report:')
        print(f'  Original size:    {self.__human_fmt_size(qt_data.orig_param_size_bytes)} ({self.__human_fmt_count(qt_data.orig_num_params)} params)')
        print(f'  Transformed size: {self.__human_fmt_size(qt_data.transformed_param_size_bytes)} ({self.__human_fmt_count(qt_data.transformed_num_params)} params)')
        print(f'  Not transformed size: {self.__human_fmt_size(qt_data.untransformed_param_size_bytes)} ({self.__human_fmt_count(qt_data.untransformed_num_params)})')
        print(f'  Transform ratio: {qt_data.GetQuantizedRatio():.2f}')
        # Summary of Node_class : Count_of_types
        __all_types = list(__all_types)
        H = ['Node Class'] + [f'# {t}' for t in __all_types]
        D = []
        for node_class,row in __row_parsed.items():
            row_content = [str(row[t][0]) + (f' ({self.__human_fmt_size(row[t][1])})' if row[t][1]>0 else '') for t in __all_types]
            D.append([node_class] + row_content)
        D.append(['TOTAL'] + [str(sum([__row_parsed[n][t][0] for n in __row_parsed.keys()]))\
        +f' ({self.__human_fmt_size(sum([__row_parsed[n][t][1] for n in __row_parsed.keys()]))})' for t in __all_types])
        print(tabulate(D, headers=H, tablefmt="fancy_outline", numalign="right", floatfmt=".2f"))

    def __format_sensitivity_report(self, sdata):
        sdata = sorted(sdata, key=lambda x: x.recipe_root)
        H = ['Node Root', 'Rewrite Name', 'Metric Kind', 'Value']
        D = []
        for s_row in sdata:
            k,v = list(s_row.sensitivity_metrics.items())[0]
            D.append([s_row.recipe_root, s_row.rewrite_name, k, float(v)])
        from tabulate import tabulate
        print(tabulate(D, headers=H, tablefmt="fancy_outline", floatfmt=".2f"))

    def __run_samples_core(self, data, run_kind, qlty_list = None):
        n_runs = int(len(data))
        logger.info(f"Running model {run_kind} with {n_runs} samples ...")
        is_calibration = run_kind == 'calibration'
        if is_calibration:
            self._calibration_count = n_runs
        else:
            self._eval_count = n_runs
        for it in tqdm(range(n_runs), ncols=100, colour='yellow', desc=f'Running {run_kind}', unit=' samples',
            bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining},{rate_noinv_fmt}{postfix}]'):
            sample = data[it]
            if not isinstance(sample, dict):
                raise ValueError(f'ERROR at #{it}: Data provided is not a dictionary, it is a {type(sample)}')
            for in_name, in_data in sample.items():
                from .utils import mera2_sanitize
                in_name = mera2_sanitize(in_name)
                if in_name not in self.in_info:
                    logger.warn(f"Provided input name {in_name} is not one of the valid inputs {list(self.in_info.keys())}. Ignoring it.")
                    continue
                iinfo = self.in_info[in_name]
                __dtype_map = {
                    "UInt8" : np.uint8, "Int8" : np.int8, "Int32" : np.int32, "Bool" : bool, "Int64" : np.int64, "Float32" : np.float32
                }
                if in_data.shape != tuple(iinfo.shape):
                    raise ValueError(f'ERROR at #{it}: Shape input mismatch for "{in_name}": {in_data.shape} vs {iinfo.shape}')
                if in_data.dtype != __dtype_map.get(iinfo.dtype_str):
                    raise ValueError(f'ERROR at #{it}: Input dtype mismatch for "{in_name}": {in_data.dtype} vs {iinfo.dtype_str}')
                self.qtzer_impl.SetInput(str(in_name), in_data.flatten().view('uint8'))
            if is_calibration:
                self.qtzer_impl.RunCalibrationSample()
            elif run_kind == 'evaluation':
                quality_data = self.qtzer_impl.RunEvaluationSample()
                qlty_list.append(quantizer.QuantizationQuality(quality_data.collected_metrics, list(self.out_info)))
            elif run_kind == 'sensitivity':
                self.qtzer_impl.RunSensitivitySample()
            else:
                raise ValueError(f'Unknown run kind')

    def calibrate(self, calibration_data : List[Dict[str, np.ndarray]]):
        """Feeds a series of realistic input data samples in order to be able to compute accurate internal ranges.
        MERA will collect the information from the execution of these data samples and compute the quantization domains as determined
        by the user configuration. It is recommended to use a big enough dataset of realistic samples in order to obtain the best
        quantization accuracy results.

        :param calibration_data: List of dictionaries with the format {'input_name' : 'np_array'} containing the different data samples.
        """
        if not isinstance(calibration_data, list):
            raise ValueError(f'calibration_data argument is not a list, it is a {type(calibration_data)}')
        if self.transformed:
            self.reset()
        self.__run_samples_core(calibration_data, 'calibration')
        return self

    def for_mixed_precision(self, sensitivity_data : List[Dict[str, np.ndarray]], display_table : bool = False):
        """Applies mixed-precision quantization to a machine learning model.

        Strategically quantizes different layers with varying bit-widths to optimize
        the trade-off between model accuracy and computational efficiency. More
        sensitive layers retain higher precision while less critical operations
        are aggressively quantized.

        :param sensitivity_data: List of realistic data samples used to compute the sensitivity of each layer in order to aid the
            choice of implementation.
        :param display_table: Display in stdout a table summarising the sensitivity per layer.
        """
        if not isinstance(sensitivity_data, list):
            raise ValueError(f'sensitivity_data argument is not a list, it is a {type(sensitivity_data)}')
        if len(sensitivity_data) == 0:
            raise ValueError(f'sensitivity_data must contain at least one sample')
        self.qtzer_impl.MixedPrecisionReady()
        self.__run_samples_core(sensitivity_data, 'sensitivity')
        stv_data = self.qtzer_impl.CalculateSensitivity()
        if display_table:
            self.__format_sensitivity_report(stv_data)
        return self

    def reset(self):
        """Resets all the internal observed metrics of the quantizer as well as any existing qtz transformed model."""
        self.qtzer_impl.Reset()
        self.transformed = False
        self.qlty_list = []
        self.transform_report = None
        self._calibration_count = 0
        self._eval_count = 0
        return self

    def quantize(self, alpha : float = 0.25, gamma : float = 1.0, s_min : float = 8.0, beta : float = 10.0, k : float = 4.0):
        """Uses the data gathered from the calibrate() method and creates a transformed model based on the quantizer configuration."""
        self.transform_report = self.qtzer_impl.QuantizeTransform(alpha, gamma, s_min, beta, k)
        self.__format_qtz_transform_report(self.transform_report)
        self.transformed = True
        return self

    def evaluate_quality(self, evaluation_data : List[Dict[str, np.ndarray]], display_table : bool = True):
        """Measures the quantization quality of a transformed model with a given evaluation data.
        This should be some realistic data sample(s) ideally different from the calibration dataset.
        In order to measure quality the user must have called quantize() method first.

        :param evaluation_data: List of dictionaries with the format {'input_name' : 'np_array'} containing the different data samples.
        :param display_table: Whether to display quality metrics to stdout or not.
        :return: List of quality metrics container.
        """
        if not self.transformed:
            raise ValueError(f'Can only get quality after the model is quantized. Call quantize() first')
        if not isinstance(evaluation_data, list):
            raise ValueError(f'evaluation_data argument is not a list, it is a {type(evaluation_data)}')
        self.qlty_list = []
        self.__run_samples_core(evaluation_data, 'evaluation', qlty_list=self.qlty_list)
        if display_table:
            for q in self.qlty_list:
                node_table,out_table = q.to_table()
                print(node_table)
                print(out_table)
        return self.qlty_list

    def save_to(self, dst_path):
        """Saves the transformed model to file. Must have called quantize() first.
        :param dst_path: Destination path where the model will be saved.
        """
        if not self.transformed:
            raise ValueError(f'Can only save after the model is quantized. Call quantize() first')
        self.qtzer_impl.SaveQuantizedTo(str(dst_path))
        return self

    def apply_smoothquant(self, alpha : float = 0.5, autotune : bool = True):
        sq_dst = self.prj.root_path / 'model_sq.mera'
        sq_report = self.qtzer_impl.ApplySmoothQuant(alpha, autotune, str(sq_dst))
        self.__format_sq_table(sq_report)
        logger.info(f'Saved SmoothQuant transformed model to {sq_dst}')
        # Have to recreate the quantizer with the new SQ model
        from .mera2libs import quantizer as m2_quantizer
        self.qtzer_impl = m2_quantizer.CreateQuantizer(str(sq_dst), str(self.qtzer_cfg_path))
        self.reset()
        return self

    def get_report(self, model_id):
        """Extracts all information about the quantization process as a dictionary that can be saved for debugging.

        :param model_id: Identifier to be used for this document.
        """
        if not self.transformed:
            raise ValueError(f'Can only generate quantization report after the model is quantized. Call quantize() first')
        return {
            "model_id" : model_id,
            "creation_time" : datetime.now().strftime("%m/%d/%Y, %H:%M:%S"),
            "platform" : str(self.mera_platform),
            "calib_count" : self._calibration_count,
            "eval_count" : self._eval_count,
            "transform_info" : self.transform_report.ToDict(),
            "quality_info" : [{"nodes" : q.node_summary(), "outputs" : q.out_summary()} for q in self.qlty_list],
            "quantizer_config" : self.quantizer_config.to_dict()
        }

def get_input_desc(mera_model_path) -> InputDescriptionContainer:
    """ Retrieve the input description of a MERA quantized model generated with MERA2.

    :param mera_model_path: Path to .mera model file.

    :return: Dict with info about the model's inputs.
    """
    from .mera2libs import quantizer as m2_quantizer
    data = m2_quantizer.GetInputDesc(str(mera_model_path))
    desc_parsed = {d.id:(tuple(d.shape), str(d.dtype_str).lower()) for d in data}
    return InputDescriptionContainer(desc_parsed)
