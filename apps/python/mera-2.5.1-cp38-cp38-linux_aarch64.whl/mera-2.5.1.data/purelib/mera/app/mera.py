#! /usr/bin/env python3

import argparse
import mera
import sys
import subprocess
import os

from pathlib import Path

__mera_loc__ = Path(mera.__file__).resolve().parent

def cmd(command, cwd = os.getcwd(), print_stdout = True, assert_retcode = False):
    stdout_str = ''
    with subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, cwd=cwd) as p:
        for line in p.stdout:
            line_str = line.decode('utf-8')
            stdout_str += line_str
            if print_stdout:
                print(line_str, end='')
    if assert_retcode and int(p.returncode) != 0:
        raise ValueError(f'Failed to run command "{command}". Ret code is {int(p.returncode)}')
    return p.returncode, stdout_str

def find_bin_util(name):
    return str(__mera_loc__ / 'bin_utils' / name)

def check_for_driver(driver_name, supported_drivers) -> str:
    orig_name = driver_name
    uname = str(cmd('uname -r', print_stdout=False)[1]).strip()
    driver_name = f'{driver_name}_{uname}.ko'
    if not Path(find_bin_util(driver_name)).exists():
        print(f'ERROR: Cannot find suitable {orig_name} driver for Linux version "{uname}"\n'
            + f'Available driver(s): {supported_drivers}\nExiting...')
        return None
    return driver_name

def main():
    arg_p = argparse.ArgumentParser(description='Utility to query information about MERA platform')
    arg_p.add_argument('-v', '--version', action='store_true', help='Display the current version about the installed MERA')

    args = arg_p.parse_args()
    if args.version:
        print(mera.get_versions())
        return 0
    arg_p.print_help()
    return 0

if __name__ == '__main__':
    sys.exit(main())
