# Copyright 2022 EdgeCortix Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Mera Deployer classes"""

import os
import time
import platform
import numpy as np

from datetime import date
from pathlib import Path

from .deploy_project import ArtifactFileType, Target, logger, _create_mera_project, CompilationFlow
from .mera_model import MeraModel, MeraModelQuantized, Mera2ModelFused, Mera2ModelQuantized
from .version import __version__
from .mera_deployment import MeraTvmDeployment, MeraDeployment, MeraTvmPrjDeployment, MeraInterpreterDeployment
from .mera_platform import Platform, AccelKind
from .utils import cmd, find_tool

class _DeployerBase:
    """Base class for Mera deployer handler"""

    def __init__(self, output_dir : str, overwrite : bool = False):
        """Create a new deployment project with a given toolchain

        :param output_dir: Output directory relative to cwd where the project should be deployed
        :param overwrite: Whether the folder should be wiped before starting a new deployment. Defaults to false
        """
        self.prj = _create_mera_project(output_dir, overwrite, self._get_compile_flow())

    def __enter__(self):
        self.prj._lock()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.prj._unlock()

    def _validate_args(self, model, mera_platform, target, host_arch):
        if not isinstance(model, MeraModel):
            raise ValueError(f'Model is not of MeraModel type.')

        if isinstance(target, str):
            target = Target[target]
        elif not isinstance(target, Target):
            raise ValueError(f'target parameter {target} could not be interpreted as a valid Target')
        target_str = target.str_val
        x86_only = target.x86_only

        if isinstance(mera_platform, Platform):
            arch_val = mera_platform.platform_name
        else:
            arch_val = mera_platform

        __PRCS_MAP = {
            'x86_64' : 'x86',
            'i386' : 'x86',
            'AMD64' : 'x86'
            # TODO - Missing mapping for ARM
        }
        __SUPPORTED_ARCH = ['x86', 'arm']
        if not host_arch:
            _prcs = platform.machine()
            host_arch = __PRCS_MAP.get(_prcs, _prcs)

        if host_arch not in __SUPPORTED_ARCH:
            raise ValueError(f'Unsupported host architecture "{host_arch}". '
            f'Only [{" ".join(__SUPPORTED_ARCH)}] architectures are supported.')

        if host_arch != 'x86' and x86_only:
            raise ValueError(f'Selected host_arch="{host_arch}", but target "{target_str}" only supports x86 architectures')
        return target_str, arch_val, host_arch, target

    def _get_compile_flow(self):
        raise NotImplementedError()


class MERADeployer(_DeployerBase):
    """MERA standard deployer with MERA's compiler stack:"""

    def _get_compile_flow(self):
        return CompilationFlow.MERA

    def _prepare_model_parse_cfg(self, model, arch_str='', ccfg_str='', host_arch='', target=None, mera_platform=None,
        ccodegen_enable_ospi=False, ccodegen_enable_ref_data=False, ccodegen_to_can=False, fe_mode=None,
        dna_extract_qtz_io_to_cpu=True, **kwargs):
        # TODO - Missing fields
        __SCHEMA_VER = 2
        sym_dims = model.shape_mapping if hasattr(model, 'shape_mapping') else {}
        try:
            model_info = {}
            mi = model.model_info if hasattr(model, 'model_info') else {}
            for mi_name,mi_data in mi.items():
                model_info[mi_name] = str(mi_data)
        except Exception as ex:
            logger.warn(f"Could not prepare model info data: {ex}")
            model_info = {}
        if fe_mode is not None:
            __fe_mode = fe_mode
        elif target == Target.MERAInterpreter:
            __fe_mode = "CONVERTED_ONLY"
        else:
            __fe_mode = "FULL"
        try:
            __DEVICE_MAP = {
                AccelKind.DNA : ['CPU', 'EC_SAKURA_II'],
                AccelKind.MCU : ['CPU', 'EC_C_CODEGEN'],
            }
            __devices = __DEVICE_MAP.get(mera_platform.accelerator_kind, ['CPU'])
        except:
            __devices = ['CPU']
        return {
            "schema" : __SCHEMA_VER,
            "metadata" : {}, # TODO
            "checksums" : {}, # TODO
            "devices" : __devices,
            "model_path" : str(model.model_path),
            "output_dir" : str(self.prj.get_cwd()),
            "symbolic_dimensions": sym_dims,
            "model_info": model_info,
            "frontend_options": {
                "kv_cache_length": int(kwargs.get("kv_cache_length", 0))
            },
            "backend_options": {
                "cpu" : {
                    "host_arch" : host_arch
                },
                "dna" : {
                    "arch_cfg" : arch_str,
                    "ccfg" : ccfg_str,
                    "extract_qtz_io_to_cpu" : bool(dna_extract_qtz_io_to_cpu)
                },
                "ccodegen" : {
                    "enable_ethos" : mera_platform == Platform.ALT2,
                    "enable_ospi" : bool(ccodegen_enable_ospi),
                    "enable_ref_data" : bool(ccodegen_enable_ref_data),
                    "convert_canonical" : bool(ccodegen_to_can),
                }
            },
            "fe_mode" : __fe_mode
        }

    def __populate_ccfg(self, bc):
        # Adds values to the currently mandatory Ccfg parameters
        def __add(key, val):
            if key not in bc:
                bc[key] = val
        __add('max_tile_width', 64)
        __add('max_tile_height', 64)
        __add('max_acc_tile_height', 16)
        __add('max_acc_tile_width', 32)
        __add('use_small_acc_mem', 'true')
        return bc

    def _apply_frontend(self, model, deploy_cfg_json):
        extension = Path(model.model_path_orig).suffix if model.model_path_orig else None
        if isinstance(model, Mera2ModelFused):
            cmd(f'{find_tool("mera_fused_cli")} {deploy_cfg_json}')
        elif isinstance(model, Mera2ModelQuantized):
            cmd(f'{find_tool("fe_meraqtz_cli")} {deploy_cfg_json}')
        elif extension == '.onnx':
            cmd(f'{find_tool("fe_onnx_cli")} {deploy_cfg_json}')
        elif extension == '.tflite':
            cmd(f'{find_tool("fe_tflite_cli")} {deploy_cfg_json}')
        elif extension == '.pte':
            cmd(f'{find_tool("fe_exir_cli")} {deploy_cfg_json}')
        else:
            raise ValueError(f"File extension not supported: {extension}")

    def _fuse_models(self, mera_models, share_input):
        if share_input:
            raise ValueError(f'Input sharing for model fusion not supported yet')
        fuse_locs = []
        fused_out_path = self.prj.get_cwd() / 'model' / 'model.mera_fused'
        (self.prj.get_cwd() / 'model').mkdir(exist_ok=True)
        for idx,m in enumerate(mera_models):
            self.prj.pushd(f'model_{idx}', abs=True)
            logger.info(f'** Loading fuse model #{idx}: {m.model_path}')
            deploy_cfg_json = self._prepare_model_parse_cfg(m, fe_mode="FRAMEWORK_ONLY")
            deploy_cfg_json = self.prj.save_artifact(f'deploy_cfg.json', ArtifactFileType.JSON, 'mera2_dcfg', deploy_cfg_json)
            self._apply_frontend(m, deploy_cfg_json)
            fuse_locs.append(str((self.prj.get_cwd() / 'model.mir').resolve()))
            self.prj.popd()
        cmd(f'{find_tool("mera_model_fuser")} {str(fused_out_path.resolve())} {" ".join(fuse_locs)}')
        return fused_out_path

    def deploy(self, model : MeraModel, mera_platform : Platform = Platform.SAKURA_2C, build_config = {},
        target : Target = Target.Simulator, host_arch : str = None, mcu_config = {}, vela_config = {},
        kv_cache_length : int = 0, **kwargs):
        """Launches the compilation of a MERA project for a MERA model using the MERA stack.

        :param model: Model object loaded from mera.ModelLoader
        :param mera_platform: MERA platform architecture enum value
        :param build_config: MERA build configuration dict
        :param target: MERA build target
        :param host_arch: Host arch to deploy for. If unset, it will pick the current host platform,
            provide a value to override the setting.
        :param mcu_config: Dictionary with user overrides for MCU CCodegen tool. The following fields are allowed:
            `suffix`, `weight_location`, `use_x86`
        :param vela_config: Dictionary with user overrides for MCU Vela tool. The following fields are allowed:
            `enable_ospi`, `config`, `sys_config`, `accel_config`, `optimise`, `memory_mode`, `verbose_all`.
        :param kv_cache_length: When deploying Transformer models, specifies the KV Cache's max size that will be built. If set to 0 (default), KV Cache won't be used.
        :return: The object representing the result of a MERA deployment
        """
        target_str, arch_val, host_arch, target = self._validate_args(model, mera_platform, target, host_arch)
        __force_legacy_deploy = os.getenv('MERA_USE_LEGACY_DEPLOYER', None)
        skip_fe = False
        extension = Path(model.model_path_orig).suffix if model.model_path_orig else None
        if extension == '.onnx' or extension == '.tflite' or extension == ".pte":
            __model_check = mera_platform in [Platform.SAKURA_2C, Platform.ALT1, Platform.ALT2]
        elif isinstance(model, MeraModelQuantized):
            __model_check = model._using_mera2()
            # Frontend is already applied.
            skip_fe = True
        elif isinstance(model, Mera2ModelFused):
            __model_check = True
            if mera_platform != Platform.SAKURA_2C:
                raise ValueError(f'Cannot use this model fusion for MERA platform {mera_platform}')
        else:
            __model_check = False
        if isinstance(model, Mera2ModelQuantized):
            # This always has to go through MERA2
            __model_check = True
            if __force_legacy_deploy:
                logger.warn("Cannot force legacy deplyer when using a MERA2 quantized model... Suppressing option")
                __force_legacy_deploy = False
        if __force_legacy_deploy or not __model_check:
            # Current fall-back, if the model is not ONNX or not for SAKURA2, use old-style deployer.
            self.__class__ = TVMDeployer # It's only a bit hacky...
            self.prj.compile_flow = CompilationFlow.TVM # force to use TVM flow
            return self.deploy(model, mera_platform=mera_platform, build_config=build_config, target=target, host_arch=host_arch)
        curr_cwd = os.getcwd()
        logger.info(f" *** mera v{__version__} ***")
        logger.info(f"Starting deployment of model '{model.model_name}'...")

        # Change directory to target's build subdir
        self.prj.pushd("build", abs=True)
        self.prj.pushd(target_str)
        os.chdir(self.prj.get_cwd())

        # Resolve model and update it, if applicable
        if hasattr(model, '_save_resolved_model'):
            model._save_resolved_model()

        tm_start = time.time()
        # Prepare deploy cfg file
        import yaml
        __from_qtz = bool(kwargs.get('__orig_mera_qtz', False))
        build_config['target'] = target_str
        build_config = self.__populate_ccfg(build_config) if mera_platform.accelerator_kind == AccelKind.DNA else {}
        ccfg_str = yaml.safe_dump(build_config).rstrip('\n')
        deploy_cfg_json = self._prepare_model_parse_cfg(model, arch_val, ccfg_str, host_arch, target, mera_platform,
            vela_config.get('enable_ospi', False), kwargs.get('enable_ref_data', False), __from_qtz, kv_cache_length=kv_cache_length)
        deploy_cfg_json = self.prj.save_artifact('deploy_cfg.json', ArtifactFileType.JSON, 'mera2_dcfg', deploy_cfg_json)
        cwd = self.prj.get_cwd()

        # Parse the model and assign target regions.
        if not skip_fe:
            self._apply_frontend(model, deploy_cfg_json)
            try:
                # Try to reload IO desc
                model._update_input_desc(cwd / 'io_desc.json')
            except:
                pass

        if target == Target.MERAInterpreter:
            # MERA2 Interpreter does not need extra deployment, finish it here
            self.prj.compile_flow = CompilationFlow.MERA_INTERPRETER
            model_ir_loc = cwd / 'model.mir'
            self.prj.add_artifact([(target_str, model_ir_loc)])
            os.chdir(curr_cwd)
            return MeraInterpreterDeployment(model_ir_loc)
        elif target == Target.MCU:
            # MCU Flow
            from .backend.mcu_compile import ccodegen_compile, ethos_compile, has_ethos_regions
            ir_loc = cwd / 'compilation'
            ccodegen_loc = Path(find_tool("ccodegen"))
            __has_ethos = has_ethos_regions(ir_loc)
            __suffix = mcu_config.get('suffix', '') if not __has_ethos else ''
            ccodegen_compile(ir_loc, ccodegen_loc, suffix=__suffix,
                weight_location=mcu_config.get('weight_location', 'flash'),
                use_x86=mcu_config.get('use_x86', True),
                use_ospi=vela_config.get('enable_ospi', False))
            if has_ethos_regions(ir_loc):
                ethos_compile(ir_loc, ccodegen_loc,
                    config=vela_config.get('config', None),
                    enable_ospi=vela_config.get('enable_ospi', False),
                    sys_config=vela_config.get('sys_config', 'RA8P1'),
                    memory_mode=vela_config.get('memory_mode', 'Sram_Only'),
                    accel_config=vela_config.get('accel_config', 'ethos-u55-256'),
                    optimise=vela_config.get('optimise', 'Performance'),
                    verbose_all=vela_config.get('verbose_all', False)
                )
            if bool(kwargs.get('enable_ref_data', False)):
                cmd(f'{ccodegen_loc / "tflite_io_data"} {deploy_cfg_json}')
            os.chdir(curr_cwd)
        else:
            # DNA - Flow
            # Compile for 'CPU' targets.
            from .backend.tvm_compile import apache_tvm_compile
            apache_tvm_compile(cwd / 'compilation', logger, host_arch)

            # Compile for 'DNA' targets.
            cmd(f'{find_tool("mera_dna_compile")} {deploy_cfg_json}')
            # Add mera.plan file to mark deployment for this target completed.
            plan_loc = cwd / 'compilation' / 'mera.plan'
            self.prj.add_artifact([(target_str, plan_loc)])

            tm_end = time.time()
            time_taken = tm_end - tm_start
            logger.info(f'Compilation finished successfully. Took {time.strftime("%Hh%Mm%Ss", time.gmtime(time_taken))}')
            os.chdir(curr_cwd)
            return MeraDeployment(plan_loc, target)


class TVMDeployer(_DeployerBase):
    """Using MERA deployer targetting the TVM compiler stack:"""

    def _get_compile_flow(self):
        return CompilationFlow.TVM

    def _save_compile_metrics(self, compile_time):
        metrics = {}
        metrics['compile_time'] = compile_time
        metrics['compile_date'] = date.today().strftime("%d/%m/%Y")
        # TODO - Add more metrics
        self.prj.save_artifact('compile_metrics.json', ArtifactFileType.JSON, 'metrics', metrics)

    def deploy(self, model : MeraModel, mera_platform : Platform = Platform.DNAF200L0003, build_config = {},
        target : Target = Target.Simulator, host_arch : str = None) -> MeraTvmDeployment:
        """Launches the compilation of a MERA project for a MERA model using the TVM stack.

        :param model: Model object loaded from mera.ModelLoader
        :param mera_platform: MERA platform architecture enum value
        :param build_config: MERA build configuration dict
        :param target: MERA build target
        :param host_arch: Host arch to deploy for. If unset, it will pick the current host platform, 
            provide a value to override the setting
        :return: The object representing the result of a MERA deployment
        """
        target_str, arch_val, host_arch, target = self._validate_args(model, mera_platform, target, host_arch)

        from tvm.relay import mera as _mera
        logger.info(f" *** mera v{__version__} ***")
        logger.info(f"Starting deployment of model '{model.model_name}'...")

        # Change directory to target's build subdir
        self.prj.pushd("build", abs=True)
        self.prj.pushd(target_str)

        # Setup mera logging
        os.environ["GLOG_log_dir"] = self.prj.get_log_dir()

        # Save compile input artifacts
        self.prj.save_artifact('build_config.yaml', ArtifactFileType.YAML, target_str, build_config)
        mera_compiler_cfg = {**build_config, "arch" : arch_val}
        self.prj.save_artifact('mera_cfg.json', ArtifactFileType.JSON, target_str, mera_compiler_cfg)
        mod, params = model._load_model_tvm()
        mera_compiler_cfg['target'] = target_str
        with _mera.build_config(**mera_compiler_cfg):
            logger.info(f'Compiling Mera model...')
            self.prj.pushd('result')
            tm_start = time.time()
            cur_program_dir = os.getcwd()
            os.chdir(self.prj.root_path) # in case of debug dumping
            if target.uses_fp32_flow:
                _mera.build_fp32(mod, params, target_str, host_arch=host_arch, output_dir=self.prj.get_cwd())
            else:
                _mera.build(mod, params, output_dir=self.prj.get_cwd(),
                    host_arch=host_arch, layout='NHWC', aux_config=model._get_mera_aux_config())
            os.chdir(cur_program_dir) # revert back to original program dir
            tm_end = time.time()
            to_target_artifact = lambda a : (target_str, self.prj.get_cwd() / a)
            self.prj.add_artifact([to_target_artifact(x) for x in ['deploy.so', 'deploy.json', 'deploy.params']])

            time_taken = tm_end - tm_start
            logger.info(f'Compilation finished successfully. Took {time.strftime("%Hh%Mm%Ss", time.gmtime(time_taken))}')
            self._save_compile_metrics(time_taken)
            self.prj.popd() # result

        self.prj.popd() # target
        self.prj.popd() # build

        logger.info(f'Deployment completed')
        lib_path = self.prj.get_artifact(target_str, 'deploy.so')
        params_path = self.prj.get_artifact(target_str, 'deploy.params')
        lib_json_path = self.prj.get_artifact(target_str, 'deploy.json')
        return MeraTvmPrjDeployment(lib_path, params_path, lib_json_path, self.prj)

    def save_data_file(self, filename : str, data : np.ndarray):
        """
        Helper function to store a given array into the project to later be used by other applications.

        :param filename: Filename to give to the saved array
        :param data: The data array to save
        """
        self.prj.save_artifact(filename, ArtifactFileType.BIN, 'data', data, 'data')

    def load_data_file(self, filename : str) -> np.ndarray:
        """
        Helper function to load a given array stored in the project with :func:`save_data_file()`

        :param filename: File name of the saved array
        :return: The data array loaded from teh project, or an exception if it could not be found.
        """
        return np.load(self.prj.get_artifact('data', filename))

# Useful alias
Deployer = MERADeployer
